/*
  # Fix Auth Users Access and Add Admin Functions

  1. Changes
    - Create a function to safely get user counts without direct auth.users access
    - Add helper functions for admin operations
    - Fix the get_admin_stats function to use the new helper functions

  2. Benefits
    - Avoids 404 errors when trying to access auth.users directly
    - Provides secure methods for admin operations
    - Improves reliability of admin dashboard statistics
*/

-- Create a function to get user count without direct auth.users access
CREATE OR REPLACE FUNCTION get_user_count()
RETURNS INTEGER AS $$
DECLARE
  user_count INTEGER;
BEGIN
  -- Count users through profiles table instead of auth.users
  SELECT COUNT(*) INTO user_count FROM profiles;
  RETURN user_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a function to check if a tour exists
CREATE OR REPLACE FUNCTION tour_exists(tour_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM tours WHERE id = tour_id
  );
END;
$$ LANGUAGE plpgsql;

-- Create a function to check if an event exists
CREATE OR REPLACE FUNCTION event_exists(event_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM events WHERE id = event_id
  );
END;
$$ LANGUAGE plpgsql;

-- Update the get_admin_stats function to use the new helper function
CREATE OR REPLACE FUNCTION get_admin_stats()
RETURNS JSONB AS $$
DECLARE
  result JSONB;
BEGIN
  SELECT jsonb_build_object(
    'total_tours', (SELECT COUNT(*) FROM tours),
    'total_events', (SELECT COUNT(*) FROM events),
    'total_bookings', (SELECT COUNT(*) FROM bookings),
    'total_users', (SELECT get_user_count()),
    'recent_bookings', (
      SELECT jsonb_agg(row_to_json(b))
      FROM (
        SELECT 
          b.id, 
          b.booking_reference, 
          b.booking_date, 
          b.travel_date,
          COALESCE(b.customer_name, p.first_name || ' ' || p.last_name) as customer_name,
          COALESCE(b.customer_email, p.email) as customer_email,
          b.tour_id, 
          b.event_id, 
          b.total_amount, 
          b.status, 
          b.payment_status,
          t.title as tour_title,
          e.title as event_title
        FROM bookings b
        LEFT JOIN profiles p ON b.user_id = p.id
        LEFT JOIN tours t ON b.tour_id = t.id
        LEFT JOIN events e ON b.event_id = e.id
        ORDER BY b.created_at DESC
        LIMIT 5
      ) b
    ),
    'popular_tours', (
      SELECT jsonb_agg(row_to_json(t))
      FROM (
        SELECT 
          t.id, 
          t.title, 
          t.image_url, 
          t.price, 
          t.rating,
          COUNT(b.id) as booking_count
        FROM tours t
        LEFT JOIN bookings b ON t.id = b.tour_id
        GROUP BY t.id, t.title, t.image_url, t.price, t.rating
        ORDER BY COUNT(b.id) DESC
        LIMIT 5
      ) t
    )
  ) INTO result;

  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a function to log admin actions
CREATE OR REPLACE FUNCTION log_admin_action(
  action_type TEXT,
  table_name TEXT,
  record_id TEXT,
  details JSONB DEFAULT NULL
)
RETURNS VOID AS $$
BEGIN
  INSERT INTO admin_logs (
    user_id,
    action_type,
    table_name,
    record_id,
    details
  ) VALUES (
    auth.uid(),
    action_type,
    table_name,
    record_id,
    details
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;