/*
  # Fix Policy Conflicts and RLS Issues

  1. Changes
    - Drop existing policies that conflict with each other
    - Create new non-conflicting policies with unique names
    - Fix admin check function to avoid recursion
    
  2. Security
    - Maintain proper access control without recursion
    - Ensure users can only access their own data
    - Allow admins to access all profiles
*/

-- First check if policies exist before trying to drop them
DO $$ 
BEGIN
  -- Drop policies with IF EXISTS to avoid errors
  DROP POLICY IF EXISTS "Users can view own profile direct" ON profiles;
  DROP POLICY IF EXISTS "Users can update own profile direct" ON profiles;
  DROP POLICY IF EXISTS "Admins can view all profiles direct" ON profiles;
  DROP POLICY IF EXISTS "Admins can update all profiles direct" ON profiles;
  DROP POLICY IF EXISTS "Admins can delete profiles direct" ON profiles;
  DROP POLICY IF EXISTS "Public read access for profiles" ON profiles;
END $$;

-- Make sure RLS is enabled
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Create a public read access policy for profiles with a unique name
CREATE POLICY "Public read access for profiles v2"
ON profiles
FOR SELECT
TO public
USING (true);

-- Create a direct, non-recursive policy for users to update their own profile
CREATE POLICY "Users can update own profile v2"
ON profiles
FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- Create a direct, non-recursive policy for admins to update all profiles
CREATE POLICY "Admins can update all profiles v2"
ON profiles
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND is_admin = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND is_admin = true
  )
);

-- Create a direct, non-recursive policy for admins to delete profiles
CREATE POLICY "Admins can delete profiles v2"
ON profiles
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND is_admin = true
  )
);

-- Create a safe is_admin function that avoids recursion
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
DECLARE
  is_admin_user BOOLEAN;
BEGIN
  -- Direct query to avoid recursion
  SELECT p.is_admin INTO is_admin_user
  FROM profiles p
  WHERE p.id = auth.uid();
  
  -- Return result (or false if no result)
  RETURN COALESCE(is_admin_user, FALSE);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;