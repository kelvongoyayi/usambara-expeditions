/*
  # Improve Tours and Events Schema

  1. New Tables
    - `tour_categories` - Categories for tours
    - `event_types` - Types of events
  2. Sample Data
    - Inserts sample data for tour categories and event types
  3. RLS Policies
    - Adds permissive policies for these tables
  4. SQL Functions
    - Creates helper functions for querying data
*/

-- Create tour_categories table if it doesn't exist
CREATE TABLE IF NOT EXISTS tour_categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- Enable RLS on tour_categories
ALTER TABLE tour_categories ENABLE ROW LEVEL SECURITY;

-- Add RLS policies to tour_categories
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy 
    WHERE tablename = 'tour_categories' AND policyname = 'Anyone can read tour categories'
  ) THEN
    CREATE POLICY "Anyone can read tour categories" ON tour_categories
      FOR SELECT USING (true);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy 
    WHERE tablename = 'tour_categories' AND policyname = 'Only admins can insert/update/delete tour categories'
  ) THEN
    CREATE POLICY "Only admins can insert/update/delete tour categories" ON tour_categories
      FOR ALL 
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END
$$;

-- Create event_types table if it doesn't exist
CREATE TABLE IF NOT EXISTS event_types (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- Enable RLS on event_types
ALTER TABLE event_types ENABLE ROW LEVEL SECURITY;

-- Add RLS policies to event_types
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy 
    WHERE tablename = 'event_types' AND policyname = 'Anyone can read event types'
  ) THEN
    CREATE POLICY "Anyone can read event types" ON event_types
      FOR SELECT USING (true);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy 
    WHERE tablename = 'event_types' AND policyname = 'Only admins can insert/update/delete event types'
  ) THEN
    CREATE POLICY "Only admins can insert/update/delete event types" ON event_types
      FOR ALL 
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END
$$;

-- Helper function to safely insert tour categories
CREATE OR REPLACE FUNCTION insert_tour_category(
  p_id TEXT, 
  p_name TEXT, 
  p_description TEXT, 
  p_icon TEXT
) RETURNS VOID AS $$
BEGIN
  INSERT INTO tour_categories (id, name, description, icon)
  VALUES (p_id, p_name, p_description, p_icon)
  ON CONFLICT (id) DO UPDATE 
  SET 
    name = p_name,
    description = p_description,
    icon = p_icon;
END;
$$ LANGUAGE plpgsql;

-- Helper function to safely insert event types
CREATE OR REPLACE FUNCTION insert_event_type(
  p_id TEXT, 
  p_name TEXT, 
  p_description TEXT, 
  p_icon TEXT
) RETURNS VOID AS $$
BEGIN
  INSERT INTO event_types (id, name, description, icon)
  VALUES (p_id, p_name, p_description, p_icon)
  ON CONFLICT (id) DO UPDATE 
  SET 
    name = p_name,
    description = p_description,
    icon = p_icon;
END;
$$ LANGUAGE plpgsql;

-- Insert sample tour categories
SELECT insert_tour_category(
  'hiking', 
  'Hiking', 
  'Guided hiking tours through beautiful trails and mountains', 
  'mountain'
);

SELECT insert_tour_category(
  'cycling', 
  'Cycling', 
  'Thrilling cycling expeditions through various terrains', 
  'bike'
);

SELECT insert_tour_category(
  'cultural', 
  'Cultural', 
  'Experience the rich cultural heritage with local guides', 
  'map'
);

SELECT insert_tour_category(
  '4x4', 
  '4x4 Expedition', 
  'Off-road adventures in 4x4 vehicles through challenging terrain', 
  'compass'
);

SELECT insert_tour_category(
  'motocamping', 
  'Motocamping', 
  'Motor biking adventures with camping experiences', 
  'activity'
);

SELECT insert_tour_category(
  'school', 
  'School Tours', 
  'Educational tours for school groups and students', 
  'users'
);

-- Insert sample event types
SELECT insert_event_type(
  'corporate', 
  'Corporate Event', 
  'Team building events, conferences, and retreats designed for businesses', 
  'briefcase'
);

SELECT insert_event_type(
  'adventure', 
  'Adventure Event', 
  'Exciting outdoor activities and challenges for thrill seekers', 
  'mountain'
);

SELECT insert_event_type(
  'education', 
  'Educational Program', 
  'Learning experiences, workshops, and educational tours for schools', 
  'graduation-cap'
);

SELECT insert_event_type(
  'special', 
  'Special Occasion', 
  'Weddings, celebrations, and memorable events for special moments', 
  'gift'
);

-- Make sure the tours table has proper fields and constraints
DO $$
BEGIN
  -- Ensure tours table has the proper columns
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'slug') THEN
    ALTER TABLE tours ADD COLUMN slug TEXT;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'highlights') THEN
    ALTER TABLE tours ADD COLUMN highlights TEXT[];
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'requirements') THEN
    ALTER TABLE tours ADD COLUMN requirements TEXT[];
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'included') THEN
    ALTER TABLE tours ADD COLUMN included TEXT[];
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'excluded') THEN
    ALTER TABLE tours ADD COLUMN excluded TEXT[];
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'gallery') THEN
    ALTER TABLE tours ADD COLUMN gallery TEXT[];
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'itinerary') THEN
    ALTER TABLE tours ADD COLUMN itinerary JSONB;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'faqs') THEN
    ALTER TABLE tours ADD COLUMN faqs JSONB;
  END IF;
END
$$;

-- Make sure the events table has proper fields and constraints
DO $$
BEGIN
  -- Ensure events table has the proper columns
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'slug') THEN
    ALTER TABLE events ADD COLUMN slug TEXT;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'event_type') THEN
    ALTER TABLE events ADD COLUMN event_type TEXT;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'highlights') THEN
    ALTER TABLE events ADD COLUMN highlights TEXT[];
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'included') THEN
    ALTER TABLE events ADD COLUMN included TEXT[];
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'excluded') THEN
    ALTER TABLE events ADD COLUMN excluded TEXT[];
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'gallery') THEN
    ALTER TABLE events ADD COLUMN gallery TEXT[];
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'itinerary') THEN
    ALTER TABLE events ADD COLUMN itinerary JSONB;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'faqs') THEN
    ALTER TABLE events ADD COLUMN faqs JSONB;
  END IF;
  
  -- Add min/max attendees fields if they don't exist
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'min_attendees') THEN
    ALTER TABLE events ADD COLUMN min_attendees INTEGER;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'max_attendees') THEN
    ALTER TABLE events ADD COLUMN max_attendees INTEGER;
  END IF;
END
$$;

-- Create admin logs table if it doesn't exist
CREATE TABLE IF NOT EXISTS admin_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  action_type TEXT NOT NULL,
  table_name TEXT NOT NULL,
  record_id TEXT NOT NULL,
  details JSONB,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  user_id UUID REFERENCES auth.users(id)
);

-- Enable RLS on admin_logs
ALTER TABLE admin_logs ENABLE ROW LEVEL SECURITY;

-- Add RLS policies to admin_logs
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy 
    WHERE tablename = 'admin_logs' AND policyname = 'Only admins can select admin logs'
  ) THEN
    CREATE POLICY "Only admins can select admin logs" ON admin_logs
      FOR SELECT
      TO authenticated
      USING (true);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_policy 
    WHERE tablename = 'admin_logs' AND policyname = 'Only admins can insert admin logs'
  ) THEN
    CREATE POLICY "Only admins can insert admin logs" ON admin_logs
      FOR INSERT
      TO authenticated
      WITH CHECK (true);
  END IF;
END
$$;