/*
  # Update Tours and Events Schema to Match Form Fields

  1. Changes
    - Ensure tours table has all fields needed for the form
    - Ensure events table has all fields needed for the form
    - Add missing columns if needed
    - Update column types to match form field types

  2. Details
    - Adds proper constraints and defaults
    - Ensures consistency between form fields and database schema
*/

-- Update tours table to match form fields
DO $$ 
BEGIN
  -- Make sure slug can be null (will be auto-generated)
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tours' AND column_name = 'slug' AND is_nullable = 'NO'
  ) THEN
    ALTER TABLE tours ALTER COLUMN slug DROP NOT NULL;
  END IF;

  -- Add missing columns if they don't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tours' AND column_name = 'difficulty'
  ) THEN
    ALTER TABLE tours ADD COLUMN difficulty TEXT;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tours' AND column_name = 'min_group_size'
  ) THEN
    ALTER TABLE tours ADD COLUMN min_group_size INTEGER;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tours' AND column_name = 'max_group_size'
  ) THEN
    ALTER TABLE tours ADD COLUMN max_group_size INTEGER;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tours' AND column_name = 'highlights'
  ) THEN
    ALTER TABLE tours ADD COLUMN highlights TEXT[];
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tours' AND column_name = 'requirements'
  ) THEN
    ALTER TABLE tours ADD COLUMN requirements TEXT[];
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tours' AND column_name = 'included'
  ) THEN
    ALTER TABLE tours ADD COLUMN included TEXT[];
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tours' AND column_name = 'excluded'
  ) THEN
    ALTER TABLE tours ADD COLUMN excluded TEXT[];
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tours' AND column_name = 'gallery'
  ) THEN
    ALTER TABLE tours ADD COLUMN gallery TEXT[];
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tours' AND column_name = 'itinerary'
  ) THEN
    ALTER TABLE tours ADD COLUMN itinerary JSONB;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tours' AND column_name = 'faqs'
  ) THEN
    ALTER TABLE tours ADD COLUMN faqs JSONB;
  END IF;

  -- Update events table to match form fields
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'events' AND column_name = 'slug' AND is_nullable = 'NO'
  ) THEN
    ALTER TABLE events ALTER COLUMN slug DROP NOT NULL;
  END IF;

  -- Add missing columns if they don't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'events' AND column_name = 'min_attendees'
  ) THEN
    ALTER TABLE events ADD COLUMN min_attendees INTEGER;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'events' AND column_name = 'max_attendees'
  ) THEN
    ALTER TABLE events ADD COLUMN max_attendees INTEGER;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'events' AND column_name = 'highlights'
  ) THEN
    ALTER TABLE events ADD COLUMN highlights TEXT[];
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'events' AND column_name = 'included'
  ) THEN
    ALTER TABLE events ADD COLUMN included TEXT[];
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'events' AND column_name = 'excluded'
  ) THEN
    ALTER TABLE events ADD COLUMN excluded TEXT[];
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'events' AND column_name = 'gallery'
  ) THEN
    ALTER TABLE events ADD COLUMN gallery TEXT[];
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'events' AND column_name = 'itinerary'
  ) THEN
    ALTER TABLE events ADD COLUMN itinerary JSONB;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'events' AND column_name = 'faqs'
  ) THEN
    ALTER TABLE events ADD COLUMN faqs JSONB;
  END IF;
END $$;

-- Create or update function to generate slugs for tours and events
CREATE OR REPLACE FUNCTION generate_slug(title TEXT)
RETURNS TEXT AS $$
DECLARE
  slug TEXT;
BEGIN
  -- Convert to lowercase, replace spaces with hyphens, remove special characters
  slug := lower(regexp_replace(regexp_replace(title, '[^a-zA-Z0-9\s]', '', 'g'), '\s+', '-', 'g'));
  RETURN slug;
END;
$$ LANGUAGE plpgsql;

-- Create or update trigger function for tours
CREATE OR REPLACE FUNCTION set_tour_slug()
RETURNS TRIGGER AS $$
BEGIN
  -- Only set slug if it's NULL or empty
  IF NEW.slug IS NULL OR NEW.slug = '' THEN
    NEW.slug := generate_slug(NEW.title);
    
    -- Ensure slug is unique by appending a number if needed
    DECLARE
      base_slug TEXT := NEW.slug;
      counter INTEGER := 1;
      slug_exists BOOLEAN;
    BEGIN
      LOOP
        SELECT EXISTS(
          SELECT 1 FROM tours WHERE slug = NEW.slug AND id != NEW.id
        ) INTO slug_exists;
        
        EXIT WHEN NOT slug_exists;
        
        -- Append counter to slug
        NEW.slug := base_slug || '-' || counter;
        counter := counter + 1;
      END LOOP;
    END;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create or update trigger function for events
CREATE OR REPLACE FUNCTION set_event_slug()
RETURNS TRIGGER AS $$
BEGIN
  -- Only set slug if it's NULL or empty
  IF NEW.slug IS NULL OR NEW.slug = '' THEN
    NEW.slug := generate_slug(NEW.title);
    
    -- Ensure slug is unique by appending a number if needed
    DECLARE
      base_slug TEXT := NEW.slug;
      counter INTEGER := 1;
      slug_exists BOOLEAN;
    BEGIN
      LOOP
        SELECT EXISTS(
          SELECT 1 FROM events WHERE slug = NEW.slug AND id != NEW.id
        ) INTO slug_exists;
        
        EXIT WHEN NOT slug_exists;
        
        -- Append counter to slug
        NEW.slug := base_slug || '-' || counter;
        counter := counter + 1;
      END LOOP;
    END;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create or replace triggers
DROP TRIGGER IF EXISTS set_tour_slug_trigger ON tours;
CREATE TRIGGER set_tour_slug_trigger
BEFORE INSERT OR UPDATE ON tours
FOR EACH ROW
EXECUTE FUNCTION set_tour_slug();

DROP TRIGGER IF EXISTS set_event_slug_trigger ON events;
CREATE TRIGGER set_event_slug_trigger
BEFORE INSERT OR UPDATE ON events
FOR EACH ROW
EXECUTE FUNCTION set_event_slug();

-- Create or update function to set updated_at timestamp
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create or replace updated_at triggers
DROP TRIGGER IF EXISTS set_tours_updated_at ON tours;
CREATE TRIGGER set_tours_updated_at
BEFORE UPDATE ON tours
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS set_events_updated_at ON events;
CREATE TRIGGER set_events_updated_at
BEFORE UPDATE ON events
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();