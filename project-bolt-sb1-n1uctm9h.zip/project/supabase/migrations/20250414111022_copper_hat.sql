/*
  # Fix Booking System to Allow Anonymous Bookings
  
  1. Changes
    - Fixes policy conflicts by dropping existing policies
    - Creates new policy for public booking creation
    - Ensures user_id can be null for anonymous bookings
    - Creates proper policies for viewing and managing bookings
  
  2. Security
    - Maintains security by properly handling both anonymous and authenticated bookings
    - Ensures admins can manage all bookings
    - Allows guests to create bookings without authentication
*/

-- Drop all existing bookings policies to ensure clean slate
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Allow public booking creation" ON bookings;
  DROP POLICY IF EXISTS "Users can view their own bookings" ON bookings;
  DROP POLICY IF EXISTS "Admins can manage all bookings" ON bookings;
  DROP POLICY IF EXISTS "Users can create their own bookings" ON bookings;
  DROP POLICY IF EXISTS "Users can insert own bookings" ON bookings;
  DROP POLICY IF EXISTS "Authenticated users can create bookings" ON bookings;
  DROP POLICY IF EXISTS "bookings_insert_public_20250414" ON bookings;
  DROP POLICY IF EXISTS "bookings_select_authenticated_20250414" ON bookings;
  DROP POLICY IF EXISTS "bookings_admin_access_20250414" ON bookings;
  DROP POLICY IF EXISTS "bookings_public_insert_20250414" ON bookings;
  DROP POLICY IF EXISTS "bookings_user_select_20250414" ON bookings;
  DROP POLICY IF EXISTS "bookings_admin_all_20250414" ON bookings;
EXCEPTION
  WHEN undefined_object THEN
    -- Ignore errors for non-existing policies
END $$;

-- First check if user_id is required and make it optional if so
DO $$ 
BEGIN
  -- Check if the column is not null
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'bookings' 
    AND column_name = 'user_id' 
    AND is_nullable = 'NO'
  ) THEN
    -- Alter column to allow NULL values
    ALTER TABLE bookings ALTER COLUMN user_id DROP NOT NULL;
  END IF;
END $$;

-- Add any missing columns for storing customer information
DO $$ 
BEGIN
  -- Add customer_name column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'bookings' 
    AND column_name = 'customer_name'
  ) THEN
    ALTER TABLE bookings ADD COLUMN customer_name TEXT NOT NULL;
  END IF;

  -- Add customer_email column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'bookings' 
    AND column_name = 'customer_email'
  ) THEN
    ALTER TABLE bookings ADD COLUMN customer_email TEXT NOT NULL;
  END IF;

  -- Add special_requests column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'bookings' 
    AND column_name = 'special_requests'
  ) THEN
    ALTER TABLE bookings ADD COLUMN special_requests TEXT;
  END IF;

  -- Add adults column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'bookings' 
    AND column_name = 'adults'
  ) THEN
    ALTER TABLE bookings ADD COLUMN adults INTEGER NOT NULL DEFAULT 1;
  END IF;

  -- Add children column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'bookings' 
    AND column_name = 'children'
  ) THEN
    ALTER TABLE bookings ADD COLUMN children INTEGER NOT NULL DEFAULT 0;
  END IF;
END $$;

-- Enable RLS on bookings table
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Create policies with unique names to avoid conflicts
-- Policy for anyone to insert bookings (both authenticated and anonymous users)
CREATE POLICY "bookings_public_insert_20250414"
  ON bookings
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Policy for users to view their own bookings when authenticated
CREATE POLICY "bookings_user_select_20250414"
  ON bookings
  FOR SELECT
  TO authenticated
  USING (
    -- Authenticated users can see their own bookings
    user_id = auth.uid() OR
    -- Admins can see all bookings
    (SELECT is_admin FROM profiles WHERE id = auth.uid())
  );

-- Policy for admins to have full access to all bookings
CREATE POLICY "bookings_admin_all_20250414"
  ON bookings
  FOR ALL
  TO authenticated
  USING (
    (SELECT is_admin FROM profiles WHERE id = auth.uid())
  );

-- Log that this migration was executed
DO $$
BEGIN
  -- Only try to log if admin_logs table exists
  IF EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'admin_logs'
  ) THEN
    -- Insert log entry if possible
    BEGIN
      INSERT INTO admin_logs (
        action_type,
        table_name,
        record_id,
        details
      ) VALUES (
        'migration',
        'bookings',
        'fix_booking_system',
        jsonb_build_object(
          'description', 'Fixed booking system to allow anonymous bookings',
          'timestamp', now()
        )
      );
    EXCEPTION
      -- Ignore errors if insert fails due to schema mismatches
      WHEN OTHERS THEN NULL;
    END;
  END IF;
END $$;