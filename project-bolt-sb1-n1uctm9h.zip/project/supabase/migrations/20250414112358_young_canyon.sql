/*
  # Fix Admin Bookings Access
  
  1. Changes
    - Ensure admin users can view all bookings
    - Create a specific policy for admin dashboard access
    - Fix the issue with bookings not appearing in admin dashboard
  
  2. Security
    - Maintain proper access control
    - Allow admins to view and manage all bookings
*/

-- Drop existing policies that might conflict
DROP POLICY IF EXISTS "bookings_admin_all_new" ON bookings;
DROP POLICY IF EXISTS "bookings_admin_dashboard_access" ON bookings;

-- Create a specific policy for admin dashboard access
CREATE POLICY "bookings_admin_dashboard_access"
  ON bookings
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

-- Create a function to check database connection
CREATE OR REPLACE FUNCTION check_admin_bookings_access()
RETURNS JSONB AS $$
DECLARE
  result JSONB;
  booking_count INTEGER;
BEGIN
  -- Count bookings accessible to the current user
  SELECT COUNT(*) INTO booking_count FROM bookings;
  
  SELECT jsonb_build_object(
    'success', true,
    'booking_count', booking_count,
    'timestamp', now()
  ) INTO result;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;