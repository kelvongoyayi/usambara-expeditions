/*
  # Fix Tours Duration Field Type
  
  1. Changes
    - Change the duration column in the tours table to TEXT type
  
  2. Rationale
    - The duration needs to store values like "3 days" which requires a text field
    - Current integer type is causing insert errors
*/

-- Alter duration column type to TEXT
DO $$ 
BEGIN 
  -- Only change the type if it's not already TEXT
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'tours' 
      AND column_name = 'duration' 
      AND data_type != 'text'
  ) THEN
    ALTER TABLE tours ALTER COLUMN duration TYPE TEXT;
  END IF;
END $$;