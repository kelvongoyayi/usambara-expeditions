/*
  # Add slugs to events and tours

  1. Updates
    - Add slugs to existing events and tours
    - Updates existing records with URL-friendly slugs based on titles

  2. Changes
    - Generates slugs for events table
    - Generates slugs for tours table
    - Uses proper URL-friendly formatting
*/

-- Function to create URL-friendly slugs
CREATE OR REPLACE FUNCTION slugify("value" TEXT)
RETURNS TEXT AS $$
  -- Remove special characters and convert to lowercase
  SELECT lower(
    regexp_replace(
      regexp_replace(
        regexp_replace("value", '[^a-zA-Z0-9\s-]', '', 'g'),
        '\s+', '-', 'g'
      ),
      '-+', '-', 'g'
    )
  );
$$ LANGUAGE SQL IMMUTABLE;

-- Update events table
UPDATE events
SET slug = slugify(title)
WHERE slug IS NULL;

-- Update tours table
UPDATE tours
SET slug = slugify(title)
WHERE slug IS NULL;