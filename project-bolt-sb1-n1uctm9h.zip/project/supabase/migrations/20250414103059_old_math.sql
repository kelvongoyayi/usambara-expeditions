/*
  # Fix Bookings RLS Policy

  1. Changes
    - Add more permissive RLS policy for bookings table
    - Ensure authenticated users can create bookings
    
  2. Security
    - Still maintain some level of security by restricting access to authenticated users
*/

-- Enable RLS on bookings table
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Drop existing policies that may be causing issues
DROP POLICY IF EXISTS "Users can create their own bookings" ON bookings;
DROP POLICY IF EXISTS "Users can insert own bookings" ON bookings;

-- Create a policy for authenticated users to create bookings
CREATE POLICY "Authenticated users can create bookings"
  ON bookings
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Create a policy for users to view their own bookings
CREATE POLICY "Users can view their own bookings"
  ON bookings
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR auth.uid() IN (SELECT id FROM profiles WHERE is_admin = true));