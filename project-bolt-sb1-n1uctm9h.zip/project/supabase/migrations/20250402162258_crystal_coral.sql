/*
  # Fix Admin Log Function

  1. Changes
    - Update log_admin_action function to handle non-UUID record IDs
    - Make the function more robust against errors
    - Ensure proper error handling for different record_id formats
    
  2. Details
    - Modify the function to not fail when record_id is not a valid UUID
    - Add better error handling to prevent function failures
    - Ensure logging works for both UUID and string identifiers
*/

-- Update log_admin_action function to be more robust
CREATE OR REPLACE FUNCTION log_admin_action(
  action_type TEXT,
  table_name TEXT,
  record_id TEXT,
  details JSONB DEFAULT NULL
)
RETURNS VOID AS $$
BEGIN
  -- Insert the log entry without trying to cast record_id to UUID
  INSERT INTO admin_logs (
    action_type,
    table_name,
    record_id,
    details,
    user_id
  ) VALUES (
    action_type,
    table_name,
    record_id,
    details,
    auth.uid()
  );
EXCEPTION
  WHEN others THEN
    -- Log error to server log but don't fail the calling function
    RAISE NOTICE 'Error logging admin action: %', SQLERRM;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a test log entry with a string ID to verify it works
DO $$
BEGIN
  PERFORM log_admin_action(
    'test',
    'admin_logs',
    'test_string_id',
    jsonb_build_object('description', 'Testing string IDs in admin logs')
  );
EXCEPTION
  WHEN others THEN
    RAISE NOTICE 'Could not create test log: %', SQLERRM;
END
$$;