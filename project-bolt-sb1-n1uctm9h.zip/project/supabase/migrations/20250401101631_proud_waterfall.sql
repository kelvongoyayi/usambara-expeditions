/*
  # Fix admin stats function

  1. Changes
    - Drop existing get_admin_stats function
    - Recreate function with correct column references
    - Fix email column reference from profiles table
  
  2. Details
    - Properly drops function before recreating
    - Uses correct table aliases and joins
    - Maintains existing security and language settings
*/

-- First drop the existing function
DROP FUNCTION IF EXISTS get_admin_stats();

-- Recreate the function with correct column references
CREATE OR REPLACE FUNCTION get_admin_stats()
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    result json;
BEGIN
    WITH booking_stats AS (
        SELECT 
            COUNT(*) as total_bookings,
            COALESCE(SUM(CASE WHEN b.status = 'confirmed' AND b.payment_status = 'paid' THEN b.total_amount ELSE 0 END), 0) as total_revenue,
            json_agg(
                json_build_object(
                    'id', b.id,
                    'booking_reference', b.booking_reference,
                    'customer_name', p.first_name || ' ' || p.last_name,
                    'customer_email', p.email,
                    'total_amount', b.total_amount,
                    'status', b.status,
                    'created_at', b.created_at
                ) ORDER BY b.created_at DESC LIMIT 5
            ) as recent_bookings
        FROM bookings b
        LEFT JOIN auth.users u ON b.user_id = u.id
        LEFT JOIN profiles p ON u.id = p.id
    ),
    tour_stats AS (
        SELECT 
            COUNT(*) as total_tours,
            json_agg(
                json_build_object(
                    'id', t.id,
                    'title', t.title,
                    'bookings_count', (
                        SELECT COUNT(*) 
                        FROM bookings b 
                        WHERE b.tour_id = t.id
                    )
                ) ORDER BY t.created_at DESC LIMIT 5
            ) as popular_tours
        FROM tours t
    ),
    event_stats AS (
        SELECT COUNT(*) as total_events
        FROM events
    ),
    user_stats AS (
        SELECT COUNT(*) as total_users
        FROM auth.users
    )
    SELECT 
        json_build_object(
            'total_bookings', bs.total_bookings,
            'total_revenue', bs.total_revenue,
            'total_tours', ts.total_tours,
            'total_events', es.total_events,
            'total_users', us.total_users,
            'recent_bookings', COALESCE(bs.recent_bookings, '[]'::json),
            'popular_tours', COALESCE(ts.popular_tours, '[]'::json)
        ) INTO result
    FROM booking_stats bs
    CROSS JOIN tour_stats ts
    CROSS JOIN event_stats es
    CROSS JOIN user_stats us;

    RETURN result;
END;
$$;