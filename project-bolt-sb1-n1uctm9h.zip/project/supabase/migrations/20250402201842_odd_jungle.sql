/*
  # Fix Storage RLS Policies for File Uploads

  1. Changes
    - Fix the error with "operator does not exist: text = uuid"
    - Update RLS policies for storage.objects table
    - Ensure proper type casting for auth.uid() in policies
  
  2. Security
    - Maintain security by restricting access to authenticated users
    - Allow file uploads for authenticated users
    - Ensure proper access control for storage objects
*/

-- Enable RLS on storage.objects if not already enabled
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Allow public read access" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated users to upload files" ON storage.objects;
DROP POLICY IF EXISTS "Allow users to update their own files" ON storage.objects;
DROP POLICY IF EXISTS "Allow users to delete their own files" ON storage.objects;
DROP POLICY IF EXISTS "Allow admins full access" ON storage.objects;

-- Create policy for public read access
CREATE POLICY "Allow public read access"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id IN ('tours', 'events', 'destinations', 'profiles'));

-- Create policy for authenticated users to upload files
CREATE POLICY "Allow authenticated users to upload files"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id IN ('tours', 'events', 'destinations', 'profiles'));

-- Create policy for users to update their own files
-- Fix the type mismatch by explicitly casting auth.uid() to text
CREATE POLICY "Allow users to update their own files"
ON storage.objects
FOR UPDATE
TO authenticated
USING (owner = auth.uid()::text);

-- Create policy for users to delete their own files
-- Fix the type mismatch by explicitly casting auth.uid() to text
CREATE POLICY "Allow users to delete their own files"
ON storage.objects
FOR DELETE
TO authenticated
USING (owner = auth.uid()::text);

-- Create policy for admins to have full access
CREATE POLICY "Allow admins full access"
ON storage.objects
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND is_admin = true
  )
);

-- Create buckets if they don't exist
DO $$
BEGIN
  -- Create tours bucket if it doesn't exist
  BEGIN
    INSERT INTO storage.buckets (id, name, public)
    VALUES ('tours', 'tours', true);
  EXCEPTION
    WHEN unique_violation THEN
      -- Bucket already exists, do nothing
  END;

  -- Create events bucket if it doesn't exist
  BEGIN
    INSERT INTO storage.buckets (id, name, public)
    VALUES ('events', 'events', true);
  EXCEPTION
    WHEN unique_violation THEN
      -- Bucket already exists, do nothing
  END;

  -- Create destinations bucket if it doesn't exist
  BEGIN
    INSERT INTO storage.buckets (id, name, public)
    VALUES ('destinations', 'destinations', true);
  EXCEPTION
    WHEN unique_violation THEN
      -- Bucket already exists, do nothing
  END;

  -- Create profiles bucket if it doesn't exist
  BEGIN
    INSERT INTO storage.buckets (id, name, public)
    VALUES ('profiles', 'profiles', true);
  EXCEPTION
    WHEN unique_violation THEN
      -- Bucket already exists, do nothing
  END;
END $$;