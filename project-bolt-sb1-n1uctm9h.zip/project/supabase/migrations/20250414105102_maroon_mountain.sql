/*
  # Allow Anonymous Bookings

  1. Changes
    - Update bookings table to make user_id nullable
    - Create more permissive RLS policies for bookings table
    - Allow public insert access for anonymous bookings
    - Ensure admin can see all bookings
  
  2. Security
    - Maintain admin controls over all bookings
    - Allow bookings without authentication
    - Track bookings with customer information even without accounts
*/

-- First check if user_id is required and make it optional if so
DO $$ 
BEGIN
  -- Check if the column is not null
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'bookings' 
    AND column_name = 'user_id' 
    AND is_nullable = 'NO'
  ) THEN
    -- Alter column to allow NULL values
    ALTER TABLE bookings ALTER COLUMN user_id DROP NOT NULL;
  END IF;
END $$;

-- Enable RLS on bookings table
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Drop existing policies that may be limiting access
DROP POLICY IF EXISTS "Users can create their own bookings" ON bookings;
DROP POLICY IF EXISTS "Users can insert own bookings" ON bookings;
DROP POLICY IF EXISTS "Authenticated users can create bookings" ON bookings;
DROP POLICY IF EXISTS "Users can view their own bookings" ON bookings;

-- Create a new policy to allow anyone to create bookings
CREATE POLICY "Allow public booking creation"
  ON bookings
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Create a policy to allow users to view their own bookings when authenticated
CREATE POLICY "Users can view their own bookings"
  ON bookings
  FOR SELECT
  TO authenticated
  USING (
    -- Either no user_id (anonymous booking) with matching email
    (user_id IS NULL AND customer_email = auth.jwt() ->> 'email') 
    OR 
    -- Or matching user_id for authenticated users
    (user_id = auth.uid())
    OR 
    -- Or admin can see all
    (auth.uid() IN (SELECT id FROM profiles WHERE is_admin = true))
  );

-- Create a policy to allow admins to manage all bookings
CREATE POLICY "Admins can manage all bookings"
  ON bookings
  FOR ALL
  TO authenticated
  USING (
    auth.uid() IN (SELECT id FROM profiles WHERE is_admin = true)
  );