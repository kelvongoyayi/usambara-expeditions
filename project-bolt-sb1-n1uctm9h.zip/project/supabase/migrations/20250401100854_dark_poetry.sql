/*
  # Create tour categories table

  1. New Tables
    - `tour_categories`
      - `id` (uuid, primary key)
      - `name` (text, required)
      - `slug` (text, unique)
      - `description` (text)
      - `icon` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Functions
    - `generate_clean_slug`: Creates URL-friendly slugs from text
    - `generate_category_slug`: Trigger function for automatic slug generation

  3. Security
    - Enable RLS
    - Add policies for read/write access
*/

-- Create extension for text unaccent if not exists
CREATE EXTENSION IF NOT EXISTS unaccent;

-- Create tour categories table if not exists
CREATE TABLE IF NOT EXISTS tour_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  icon text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE tour_categories ENABLE ROW LEVEL SECURITY;

-- Function to generate clean slugs
CREATE OR REPLACE FUNCTION generate_clean_slug(input_text TEXT)
RETURNS TEXT AS $$
BEGIN
  RETURN LOWER(
    REGEXP_REPLACE(
      REGEXP_REPLACE(
        UNACCENT(input_text),
        '[^a-zA-Z0-9\s-]',
        '',
        'g'
      ),
      '\s+',
      '-',
      'g'
    )
  );
END;
$$ LANGUAGE plpgsql;

-- Create trigger function to generate slug
CREATE OR REPLACE FUNCTION generate_category_slug()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.slug IS NULL OR NEW.slug = '' THEN
    NEW.slug := generate_clean_slug(NEW.name);
  END IF;
  
  -- Ensure slug is unique by appending number if needed
  WHILE EXISTS (
    SELECT 1 FROM tour_categories WHERE slug = NEW.slug AND id != NEW.id
  ) LOOP
    NEW.slug := NEW.slug || '-' || floor(random() * 1000)::text;
  END LOOP;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
DROP TRIGGER IF EXISTS generate_category_slug_trigger ON tour_categories;
CREATE TRIGGER generate_category_slug_trigger
BEFORE INSERT OR UPDATE ON tour_categories
FOR EACH ROW
EXECUTE FUNCTION generate_category_slug();

-- Add RLS policies
CREATE POLICY "Enable read access for all users" ON tour_categories
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable write access for admins" ON tour_categories
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_admin = true
    )
  );