/*
  # Fix event_types table structure
  
  1. Changes
    - Create event_types table with proper structure
    - Add initial event type data
    - Add RLS policies
  
  2. Security
    - Enable RLS on event_types table
    - Add policies for authenticated users to read event types
*/

-- Create event_types table
CREATE TABLE IF NOT EXISTS public.event_types (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.event_types ENABLE ROW LEVEL SECURITY;

-- Add RLS policies for event_types
CREATE POLICY "Allow public read access to event_types"
  ON public.event_types
  FOR SELECT
  TO public
  USING (true);

-- Insert initial event types
INSERT INTO public.event_types (id, name, description) VALUES
  ('corporate', 'Corporate Event', 'Team building events and corporate retreats'),
  ('adventure', 'Adventure Event', 'Exciting outdoor activities and challenges'),
  ('education', 'Educational Program', 'Learning experiences and workshops'),
  ('special', 'Special Occasion', 'Celebrations and memorable events')
ON CONFLICT (id) DO UPDATE
SET name = EXCLUDED.name,
    description = EXCLUDED.description;