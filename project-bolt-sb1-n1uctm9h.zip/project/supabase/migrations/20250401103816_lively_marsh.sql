/*
  # Add Sample Tour Categories
  
  1. New Data
    - Adds 6 sample tour categories:
      - Hiking Adventures
      - Cycling Tours
      - Cultural Experiences
      - 4x4 Expeditions
      - Motocamping Tours
      - School Tours
  
  2. Data Structure
    - Each category has:
      - name (display name)
      - slug (URL-friendly version)
      - description (longer text description)
      - icon (optional name of Lucide icon)
*/

-- Insert sample tour categories
INSERT INTO tour_categories (id, name, slug, description, icon, created_at) 
VALUES
  (
    gen_random_uuid(),
    'Hiking',
    'hiking',
    'Explore Tanzania''s breathtaking landscapes on foot with our guided hiking adventures. From gentle nature walks to challenging summit treks.',
    'mountain',
    NOW()
  ),
  (
    gen_random_uuid(),
    'Cycling',
    'cycling',
    'Experience Tanzania''s diverse terrain on two wheels. Our cycling tours cater to all levels from beginner-friendly routes to challenging mountain trails.',
    'bike',
    NOW()
  ),
  (
    gen_random_uuid(),
    'Cultural',
    'cultural',
    'Immerse yourself in the rich tapestry of Tanzanian cultures and traditions. Visit authentic villages, participate in local activities, and learn about indigenous practices.',
    'users',
    NOW()
  ),
  (
    gen_random_uuid(),
    '4x4 Expedition',
    '4x4',
    'Venture into Tanzania''s most remote and spectacular regions in our specially equipped 4x4 vehicles. Perfect for photography and wilderness exploration.',
    'jeep',
    NOW()
  ),
  (
    gen_random_uuid(),
    'Motocamping',
    'motocamping',
    'Combine motorcycle adventure with wilderness camping in this unique experience. Travel off the beaten path and camp under the stars.',
    'tent',
    NOW()
  ),
  (
    gen_random_uuid(),
    'School Tours',
    'school',
    'Educational expeditions designed for school groups with a focus on learning, team building, and experiencing Tanzania''s natural and cultural heritage.',
    'graduation-cap',
    NOW()
  );