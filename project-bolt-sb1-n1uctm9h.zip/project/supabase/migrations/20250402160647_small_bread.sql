/*
  # Fix admin_logs table structure

  1. Changes
    - Add missing user_id column to admin_logs table if it doesn't exist
    - Rename existing user_id column to admin_id if needed
    - Update log_admin_action function to use the correct column name
  
  2. Purpose
    - Fix error: "column user_id of relation admin_logs does not exist"
    - Ensure proper logging of admin actions
    - Maintain audit trail functionality
*/

-- Check if admin_logs table exists
DO $$ 
BEGIN
  -- Check if admin_logs table exists but doesn't have user_id column
  IF EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_schema = 'public' AND table_name = 'admin_logs'
  ) AND NOT EXISTS (
    SELECT FROM information_schema.columns 
    WHERE table_schema = 'public' AND table_name = 'admin_logs' AND column_name = 'user_id'
  ) THEN
    -- Add user_id column
    ALTER TABLE admin_logs ADD COLUMN user_id UUID REFERENCES auth.users(id);
  END IF;
END $$;

-- Update log_admin_action function to use the correct column name
CREATE OR REPLACE FUNCTION log_admin_action(
  action_type TEXT,
  table_name TEXT,
  record_id TEXT,
  details JSONB DEFAULT NULL
)
RETURNS VOID AS $$
BEGIN
  INSERT INTO admin_logs (
    action_type,
    table_name,
    record_id,
    details,
    user_id
  ) VALUES (
    action_type,
    table_name,
    record_id,
    details,
    auth.uid()
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Log that this migration was run
INSERT INTO admin_logs (
  action_type,
  table_name,
  record_id,
  details
) VALUES (
  'migration',
  'admin_logs',
  'fix_structure',
  jsonb_build_object('description', 'Fixed admin_logs table structure')
);