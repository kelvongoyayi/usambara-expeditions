/*
  # Fix RLS policies and add event_types table
  
  1. Changes
    - Create event_types table with proper structure
    - Add initial event type data
    - Fix RLS policies on profiles table to prevent recursion
    - Add proper RLS policies for event_types table
  
  2. Security
    - Enable RLS on event_types table
    - Add policies for authenticated users to read event types
    - Fix profiles table RLS to avoid recursion by using auth.uid() directly
*/

-- Create event_types table
CREATE TABLE IF NOT EXISTS public.event_types (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.event_types ENABLE ROW LEVEL SECURITY;

-- Add RLS policies for event_types
CREATE POLICY "Allow public read access to event_types"
  ON public.event_types
  FOR SELECT
  TO public
  USING (true);

-- Insert initial event types
INSERT INTO public.event_types (id, name, description) VALUES
  ('corporate', 'Corporate Event', 'Team building events and corporate retreats'),
  ('adventure', 'Adventure Event', 'Exciting outdoor activities and challenges'),
  ('education', 'Educational Program', 'Learning experiences and workshops'),
  ('special', 'Special Occasion', 'Celebrations and memorable events')
ON CONFLICT (id) DO UPDATE
SET name = EXCLUDED.name,
    description = EXCLUDED.description,
    updated_at = now();

-- Fix profiles table RLS to prevent recursion
DO $$ 
BEGIN
  -- Drop existing policies that might cause recursion
  DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
  DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
  
  -- Create new, simplified policies that don't cause recursion
  CREATE POLICY "Users can view own profile"
    ON public.profiles
    FOR SELECT
    TO authenticated
    USING (auth.uid() = id);
    
  CREATE POLICY "Users can update own profile"
    ON public.profiles
    FOR UPDATE
    TO authenticated
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);
    
  -- Add policy for admins to view all profiles
  CREATE POLICY "Admins can view all profiles"
    ON public.profiles
    FOR SELECT
    TO authenticated
    USING (
      coalesce(
        (auth.jwt() ->> 'role') = 'admin',
        false
      )
    );
    
  -- Add policy for admins to update all profiles
  CREATE POLICY "Admins can update all profiles"
    ON public.profiles
    FOR UPDATE
    TO authenticated
    USING (
      coalesce(
        (auth.jwt() ->> 'role') = 'admin',
        false
      )
    )
    WITH CHECK (
      coalesce(
        (auth.jwt() ->> 'role') = 'admin',
        false
      )
    );
END $$;