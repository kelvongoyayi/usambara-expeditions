/*
  # Fix admin stats function

  1. Changes
    - Update get_admin_stats function to properly handle customer name fields
    - Add proper joins to get customer information
    - Fix column references in recent bookings query
    - Optimize popular tours query

  2. Details
    - Use profiles table to get customer names
    - Join bookings with profiles and tours/events tables
    - Return properly formatted customer information
*/

CREATE OR REPLACE FUNCTION get_admin_stats()
RETURNS JSONB AS $$
DECLARE
  result JSONB;
BEGIN
  SELECT jsonb_build_object(
    'total_tours', (SELECT COUNT(*) FROM tours),
    'total_events', (SELECT COUNT(*) FROM events),
    'total_bookings', (SELECT COUNT(*) FROM bookings),
    'total_users', (SELECT COUNT(*) FROM profiles),
    'recent_bookings', (
      SELECT jsonb_agg(
        jsonb_build_object(
          'id', b.id,
          'booking_reference', b.booking_reference,
          'booking_date', b.booking_date,
          'travel_date', b.travel_date,
          'customer_name', COALESCE(p.first_name || ' ' || p.last_name, 'Anonymous'),
          'customer_email', COALESCE(p.email, b.email),
          'tour_id', b.tour_id,
          'event_id', b.event_id,
          'total_amount', b.total_amount,
          'status', b.status,
          'payment_status', b.payment_status,
          'created_at', b.created_at,
          'updated_at', b.updated_at,
          'tourTitle', t.title,
          'eventTitle', e.title
        )
      )
      FROM bookings b
      LEFT JOIN profiles p ON b.user_id = p.id
      LEFT JOIN tours t ON b.tour_id = t.id
      LEFT JOIN events e ON b.event_id = e.id
      ORDER BY b.created_at DESC
      LIMIT 5
    ),
    'popular_tours', (
      SELECT jsonb_agg(t)
      FROM (
        SELECT t.*,
               COUNT(b.id) as booking_count
        FROM tours t
        LEFT JOIN bookings b ON b.tour_id = t.id
        GROUP BY t.id
        ORDER BY COUNT(b.id) DESC
        LIMIT 5
      ) t
    )
  ) INTO result;

  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;