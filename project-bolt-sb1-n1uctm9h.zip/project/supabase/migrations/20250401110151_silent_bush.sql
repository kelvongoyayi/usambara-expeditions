/*
  # Add slugs to events and tours tables

  1. Changes
    - Creates functions to generate URL-friendly slugs
    - Updates existing events and tours with slugs based on their titles
    - Ensures all new records will have slugs

  2. Details
    - Handles special characters and spaces
    - Converts to lowercase
    - Replaces spaces with hyphens
    - Removes invalid characters
    - Ensures unique slugs by appending numbers if needed
    
  3. Order of Operations
    - Create helper functions first
    - Create trigger function
    - Update existing records
    - Create triggers
*/

-- Function to create URL-friendly slugs
CREATE OR REPLACE FUNCTION slugify("value" TEXT)
RETURNS TEXT AS $$
  -- Remove special characters and convert to lowercase
  SELECT lower(
    regexp_replace(
      regexp_replace(
        regexp_replace("value", '[^a-zA-Z0-9\s-]', '', 'g'),
        '\s+', '-', 'g'
      ),
      '-+', '-', 'g'
    )
  );
$$ LANGUAGE SQL IMMUTABLE;

-- Function to generate a unique slug
CREATE OR REPLACE FUNCTION generate_unique_slug(base_slug TEXT, table_name TEXT)
RETURNS TEXT AS $$
DECLARE
  new_slug TEXT;
  counter INTEGER := 1;
  slug_exists BOOLEAN;
BEGIN
  -- Start with the base slug
  new_slug := base_slug;
  
  -- Keep checking until we find a unique slug
  LOOP
    EXECUTE format('SELECT EXISTS(SELECT 1 FROM %I WHERE slug = $1)', table_name)
    INTO slug_exists
    USING new_slug;
    
    EXIT WHEN NOT slug_exists;
    
    -- Append counter to the slug
    new_slug := base_slug || '-' || counter;
    counter := counter + 1;
  END LOOP;
  
  RETURN new_slug;
END;
$$ LANGUAGE plpgsql;

-- Create trigger function for automatically setting slugs
CREATE OR REPLACE FUNCTION set_slug()
RETURNS TRIGGER AS $$
BEGIN
  NEW.slug := (
    SELECT generate_unique_slug(slugify(NEW.title), TG_TABLE_NAME)
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Update events table
DO $$ 
BEGIN
  -- Update existing records
  UPDATE events
  SET slug = (
    SELECT generate_unique_slug(slugify(title), 'events')
  )
  WHERE slug IS NULL;
  
  -- Add trigger for new records
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'set_event_slug') THEN
    CREATE TRIGGER set_event_slug
      BEFORE INSERT ON events
      FOR EACH ROW
      WHEN (NEW.slug IS NULL)
      EXECUTE FUNCTION set_slug();
  END IF;
END $$;

-- Update tours table
DO $$ 
BEGIN
  -- Update existing records
  UPDATE tours
  SET slug = (
    SELECT generate_unique_slug(slugify(title), 'tours')
  )
  WHERE slug IS NULL;
  
  -- Add trigger for new records
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'set_tour_slug') THEN
    CREATE TRIGGER set_tour_slug
      BEFORE INSERT ON tours
      FOR EACH ROW
      WHEN (NEW.slug IS NULL)
      EXECUTE FUNCTION set_slug();
  END IF;
END $$;