/*
  # Add Additional Columns to Tours Table
  
  1. Changes
    - Add gallery column to store multiple images as text array
    - Add difficulty column for storing tour difficulty level
    - Add columns for itinerary, faqs, included/excluded items
    - Add min/max group size columns
  
  2. Rationale
    - These columns are needed to support the rich tour data model
    - Enables storing comprehensive tour information including galleries, itineraries, and FAQs
*/

-- Add gallery column as text array to store multiple image URLs
ALTER TABLE IF EXISTS tours
ADD COLUMN IF NOT EXISTS gallery TEXT[];

-- Add difficulty column for storing tour difficulty level (easy, moderate, challenging)
ALTER TABLE IF EXISTS tours
ADD COLUMN IF NOT EXISTS difficulty TEXT;

-- Add columns for group size limits
ALTER TABLE IF EXISTS tours
ADD COLUMN IF NOT EXISTS min_group_size INTEGER;

ALTER TABLE IF EXISTS tours
ADD COLUMN IF NOT EXISTS max_group_size INTEGER;

-- Add columns for additional location information
ALTER TABLE IF EXISTS tours
ADD COLUMN IF NOT EXISTS start_location TEXT;

ALTER TABLE IF EXISTS tours
ADD COLUMN IF NOT EXISTS end_location TEXT;

-- Add columns for tour highlights, requirements as text arrays
ALTER TABLE IF EXISTS tours
ADD COLUMN IF NOT EXISTS highlights TEXT[];

ALTER TABLE IF EXISTS tours
ADD COLUMN IF NOT EXISTS requirements TEXT[];

-- Add columns for included/excluded items
ALTER TABLE IF EXISTS tours
ADD COLUMN IF NOT EXISTS included TEXT[];

ALTER TABLE IF EXISTS tours
ADD COLUMN IF NOT EXISTS excluded TEXT[];

-- Add column for itinerary as JSONB to store structured itinerary data
ALTER TABLE IF EXISTS tours
ADD COLUMN IF NOT EXISTS itinerary JSONB;

-- Add column for FAQs as JSONB to store question/answer pairs
ALTER TABLE IF EXISTS tours
ADD COLUMN IF NOT EXISTS faqs JSONB;