/*
  # Add Sample Tour Categories and Tours

  1. New Data
    - Tour categories for different adventure types
    - Sample tours with detailed information
    - RLS policies for public access
  
  2. Categories Added:
    - Hiking
    - Cycling
    - Cultural
    - 4x4 Expedition
    - Motocamping
    - School Tours

  3. Sample Tours Added:
    - Multiple tours per category
    - Complete with descriptions, prices, durations
    - Includes itineraries and requirements
*/

-- Insert tour categories
INSERT INTO tour_categories (name, slug, description, icon) VALUES
('Hiking', 'hiking', 'Guided hiking adventures through Tanzania''s most beautiful trails', 'mountain'),
('Cycling', 'cycling', 'Mountain biking and cycling tours for all skill levels', 'bike'),
('Cultural', 'cultural', 'Immersive experiences in local communities and traditions', 'users'),
('4x4 Expedition', '4x4', 'Off-road adventures exploring remote locations', 'truck'),
('Motocamping', 'motocamping', 'Motorcycle touring combined with camping experiences', 'tent'),
('School Tours', 'school', 'Educational tours designed for school groups', 'school')
ON CONFLICT (slug) DO NOTHING;

-- Insert sample tours
INSERT INTO tours (
  title,
  description,
  category,
  duration,
  price,
  location,
  image_url,
  rating,
  difficulty,
  min_group_size,
  max_group_size,
  featured,
  highlights,
  requirements,
  included,
  excluded,
  itinerary
) VALUES
(
  'Usambara Mountains Trek',
  'Experience the breathtaking beauty of the Usambara Mountains on this guided hiking adventure. Trek through ancient forests, visit traditional villages, and enjoy panoramic views of the surrounding landscapes.',
  'hiking',
  '3 days',
  299,
  'Usambara Mountains',
  'https://images.unsplash.com/photo-1516426122078-c23e76319801?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
  4.8,
  'moderate',
  4,
  12,
  true,
  ARRAY[
    'Summit hike with panoramic views',
    'Visit to traditional villages',
    'Ancient rainforest exploration',
    'Local guide interpretation',
    'Cultural interactions'
  ],
  ARRAY[
    'Good physical fitness level',
    'Comfortable hiking shoes',
    'Day pack for essentials',
    'Weather-appropriate clothing'
  ],
  ARRAY[
    'Professional mountain guide',
    'All meals during trek',
    'Camping equipment',
    'Park entrance fees',
    'Emergency first aid kit'
  ],
  ARRAY[
    'International flights',
    'Personal hiking gear',
    'Travel insurance',
    'Personal expenses',
    'Tips for guides'
  ],
  jsonb_build_array(
    jsonb_build_object(
      'day', 1,
      'title', 'Arrival and Forest Trek',
      'description', 'Begin your journey with a morning briefing before heading into the ancient forests. Trek through diverse vegetation while learning about local flora and fauna.',
      'activities', ARRAY['Morning briefing and gear check', 'Forest trek introduction', 'Botanical exploration', 'Evening campfire'],
      'meals', ARRAY['lunch', 'dinner'],
      'accommodation', 'Forest Camp',
      'distance', '8 km',
      'elevation', '500m gain'
    ),
    jsonb_build_object(
      'day', 2,
      'title', 'Summit Day',
      'description', 'Early start for the summit attempt. Reach the highest point for spectacular views across Tanzania.',
      'activities', ARRAY['Summit hike', 'Photography session', 'Village visit', 'Cultural dinner'],
      'meals', ARRAY['breakfast', 'lunch', 'dinner'],
      'accommodation', 'Mountain Lodge',
      'distance', '12 km',
      'elevation', '800m gain'
    ),
    jsonb_build_object(
      'day', 3,
      'title', 'Village Tour and Departure',
      'description', 'Explore local villages and learn about traditional life before descending.',
      'activities', ARRAY['Village tour', 'Traditional craft demonstration', 'Farewell ceremony'],
      'meals', ARRAY['breakfast', 'lunch'],
      'accommodation', 'N/A',
      'distance', '6 km',
      'elevation', '400m descent'
    )
  )
),
(
  'Tea Plantation Cycling Tour',
  'Cycle through the lush tea plantations of the Usambara region. Experience the beauty of rolling hills covered in tea bushes while learning about tea production and local agriculture.',
  'cycling',
  '1 day',
  89,
  'Amani Nature Reserve',
  'https://images.unsplash.com/photo-1591184510259-b6f1be3d7aff?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80',
  4.7,
  'easy',
  2,
  8,
  true,
  ARRAY[
    'Scenic cycling routes',
    'Tea plantation visit',
    'Local tea tasting',
    'Photography opportunities',
    'Cultural experience'
  ],
  ARRAY[
    'Basic cycling ability',
    'Comfortable clothing',
    'Sun protection',
    'Water bottle'
  ],
  ARRAY[
    'Professional cycling guide',
    'Mountain bike rental',
    'Safety equipment',
    'Tea tasting session',
    'Light refreshments'
  ],
  ARRAY[
    'Personal cycling gear',
    'Travel insurance',
    'Personal expenses',
    'Additional beverages'
  ],
  jsonb_build_array(
    jsonb_build_object(
      'day', 1,
      'title', 'Tea Plantation Cycle Tour',
      'description', 'Full day of cycling through scenic tea plantations with various stops for learning and photography.',
      'activities', ARRAY['Bike fitting and safety briefing', 'Plantation cycling tour', 'Tea processing demonstration', 'Tea tasting ceremony'],
      'meals', ARRAY['lunch'],
      'accommodation', 'N/A',
      'distance', '25 km',
      'elevation', '300m total'
    )
  )
),
(
  'Cultural Village Experience',
  'Immerse yourself in the rich culture of the Usambara region with this authentic village experience. Learn about traditional customs, participate in local activities, and connect with community members.',
  'cultural',
  '2 days',
  199,
  'Lushoto',
  'https://images.unsplash.com/photo-1567942089878-d844f4561d57?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
  4.9,
  'easy',
  4,
  10,
  false,
  ARRAY[
    'Traditional cooking class',
    'Cultural performances',
    'Craft workshops',
    'Local market visit',
    'Home stay experience'
  ],
  ARRAY[
    'Open mind and respect for local customs',
    'Comfortable walking shoes',
    'Conservative dress',
    'Basic camping gear'
  ],
  ARRAY[
    'Local guide and interpreter',
    'All meals',
    'Cultural activities',
    'Home stay accommodation',
    'Traditional craft materials'
  ],
  ARRAY[
    'Transport to village',
    'Personal items',
    'Tips for hosts',
    'Souvenirs'
  ],
  jsonb_build_array(
    jsonb_build_object(
      'day', 1,
      'title', 'Village Welcome and Cultural Activities',
      'description', 'Arrive at the village for a traditional welcome ceremony followed by cultural activities and workshops.',
      'activities', ARRAY['Welcome ceremony', 'Traditional dance lesson', 'Cooking workshop', 'Evening storytelling'],
      'meals', ARRAY['lunch', 'dinner'],
      'accommodation', 'Local Home Stay'
    ),
    jsonb_build_object(
      'day', 2,
      'title', 'Market Day and Crafts',
      'description', 'Experience local market life and participate in traditional craft making before departure.',
      'activities', ARRAY['Market visit', 'Craft workshop', 'Farewell ceremony'],
      'meals', ARRAY['breakfast', 'lunch'],
      'accommodation', 'N/A'
    )
  )
);

-- Add RLS Policies for public access to tours
ALTER TABLE tours ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access to tours"
  ON tours
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow authenticated users to create tours"
  ON tours
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() IN (
    SELECT id FROM profiles WHERE is_admin = true
  ));

CREATE POLICY "Allow admins to update tours"
  ON tours
  FOR UPDATE
  TO authenticated
  USING (auth.uid() IN (
    SELECT id FROM profiles WHERE is_admin = true
  ))
  WITH CHECK (auth.uid() IN (
    SELECT id FROM profiles WHERE is_admin = true
  ));

CREATE POLICY "Allow admins to delete tours"
  ON tours
  FOR DELETE
  TO authenticated
  USING (auth.uid() IN (
    SELECT id FROM profiles WHERE is_admin = true
  ));