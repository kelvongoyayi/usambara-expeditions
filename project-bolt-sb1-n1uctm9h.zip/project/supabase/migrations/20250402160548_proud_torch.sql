/*
  # Drop Sample Tours and Events

  1. Changes
    - Delete all existing tours from the tours table
    - Delete all existing events from the events table
    
  2. Purpose
    - Clean up sample data
    - Prepare for production data
    - Start with a clean slate
*/

-- Delete all tours
DELETE FROM tours;

-- Delete all events
DELETE FROM events;

-- Log the action
INSERT INTO admin_logs (
  action_type,
  table_name,
  record_id,
  details,
  user_id
)
VALUES
  (
    'delete_all',
    'tours',
    'all',
    jsonb_build_object('reason', 'Removed sample data'),
    auth.uid()
  ),
  (
    'delete_all',
    'events',
    'all',
    jsonb_build_object('reason', 'Removed sample data'),
    auth.uid()
  );