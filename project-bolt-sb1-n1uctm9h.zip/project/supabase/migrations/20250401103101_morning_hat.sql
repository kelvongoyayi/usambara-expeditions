/*
  # Add Sample Tours
  
  1. New Data
    - Adds 10 sample tours across different categories:
      - Hiking tours (3)
      - Cycling tours (2)
      - Cultural tours (2)
      - 4x4 Expedition tours (1)
      - Motocamping tours (1)
      - School tour (1)
  
  2. Data Structure
    - Each tour includes:
      - Basic info (title, description, price, location, etc.)
      - Rich details (highlights, requirements, included/excluded items)
      - Full itineraries with daily activities
      - FAQs
      - Images from Unsplash
*/

-- Insert sample tours
INSERT INTO tours (
  id, title, duration, price, location, image_url, gallery, rating, description, category,
  difficulty, min_group_size, max_group_size, highlights, requirements, included, excluded,
  itinerary, faqs, featured, created_at, updated_at
)
VALUES
  -- HIKING TOURS
  (
    '1',
    'Usambara Mountains 3-Day Trek',
    '3 days',
    299,
    'Usambara Mountains, Tanzania',
    'https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    ARRAY[
      'https://images.unsplash.com/photo-1565109662910-74709eedc8e5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2069&q=80',
      'https://images.unsplash.com/photo-1615286505008-cbca9896192f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
      'https://images.unsplash.com/photo-1532339142463-fd0a8979791a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
    ],
    4.8,
    'Explore the lush rainforests and panoramic viewpoints of the Usambara Mountains on this immersive 3-day guided trek. Walk through indigenous forests, visit traditional villages, and experience Tanzania's "Galapagos" of biodiversity.',
    'hiking',
    'moderate',
    4,
    12,
    ARRAY[
      'Panoramic views from Irente viewpoint overlooking the plains',
      'Guided forest walks with expert local naturalists',
      'Cultural exchange at Mambo Viewpoint village',
      'Diverse birdwatching opportunities',
      'Stay in comfortable mountain lodges'
    ],
    ARRAY[
      'Good physical fitness - able to hike 5-7 hours daily',
      'Sturdy hiking boots with ankle support',
      'Weather-appropriate clothing (layers recommended)',
      'Backpack for daily necessities',
      'Refillable water bottle'
    ],
    ARRAY[
      'Professional English-speaking guide',
      'All accommodation during the trek',
      'All meals as specified in the itinerary',
      'Water during activities',
      'All entry and trekking permits',
      'Porters to carry equipment'
    ],
    ARRAY[
      'International flights',
      'Personal trekking gear',
      'Travel insurance',
      'Personal expenses',
      'Tips for guides and porters',
      'Alcoholic and specialty beverages'
    ],
    '[
      {
        "day": 1,
        "title": "Lushoto and Irente Forest",
        "description": "Begin your adventure in Lushoto town before embarking on a trek through the verdant Irente Forest. Visit the stunning Irente viewpoint for panoramic vistas of the plains below.",
        "activities": [
          "Morning pickup from Tanga and transfer to Lushoto town",
          "Visit local market and cultural orientation",
          "Guided trek through Irente Forest to viewpoint",
          "Visit local cheese factory and organic farm",
          "Evening relaxation at mountain lodge"
        ],
        "meals": ["lunch", "dinner"],
        "accommodation": "Irente View Cliff Lodge",
        "distance": "7 km",
        "elevation": "350m gain"
      },
      {
        "day": 2,
        "title": "Mambo Viewpoint and Village Experience",
        "description": "Trek to the spectacular Mambo Viewpoint, known for its breathtaking 360-degree views. Spend time in a traditional village learning about local culture and agricultural practices.",
        "activities": [
          "Morning bird watching walk",
          "Trek through mountain forests to Mambo Viewpoint",
          "Traditional lunch with a local family",
          "Afternoon cultural activities in Mambo village",
          "Evening campfire with local stories and music"
        ],
        "meals": ["breakfast", "lunch", "dinner"],
        "accommodation": "Mambo Viewpoint Eco-Lodge",
        "distance": "12 km",
        "elevation": "450m gain, 200m loss"
      },
      {
        "day": 3,
        "title": "Mtae Viewpoint and Descent",
        "description": "Visit Mtae, one of the most dramatic viewpoints in the Usambaras. After soaking in the breathtaking views, descend through terraced farms and forest patches back to Lushoto.",
        "activities": [
          "Sunrise viewing at Mambo Viewpoint",
          "Trek to Mtae village and viewpoint",
          "Visit butterfly conservation project",
          "Descent through terraced farmland",
          "Farewell lunch and transfer to Tanga"
        ],
        "meals": ["breakfast", "lunch"],
        "accommodation": "",
        "distance": "9 km",
        "elevation": "150m gain, 600m loss"
      }
    ]',
    '[
      {
        "question": "How difficult is the hiking?",
        "answer": "The trek is rated as moderate. Participants should be able to walk 5-7 hours per day on mountain trails with moderate elevation changes. No technical climbing skills are required, but good physical fitness is necessary."
      },
      {
        "question": "What is the best time to do this trek?",
        "answer": "The best months are June to October (dry season) and December to February (short dry season). We avoid the long rainy season (March-May) when trails can be slippery and views often obscured by clouds."
      },
      {
        "question": "What type of accommodation can I expect?",
        "answer": "You'll stay in comfortable mountain lodges with private or shared facilities. All accommodations are clean and well-maintained with authentic local character, offering the perfect balance between comfort and a genuine mountain experience."
      },
      {
        "question": "Is there access to electricity and mobile reception?",
        "answer": "Most lodges have electricity, though occasional outages are possible. Solar backup is usually available for charging basic devices. Mobile reception varies throughout the mountains - expect coverage at viewpoints and villages, but limited connectivity in valleys and forests."
      },
      {
        "question": "What wildlife might we see?",
        "answer": "The Usambaras are known for their exceptional biodiversity. You may spot endemic birds like the Usambara Eagle Owl, various chameleon species, colorful butterflies, and unique plant life. This is more of a nature and culture trek than a traditional wildlife safari."
      }
    ]',
    true,
    NOW(),
    NOW()
  ),
  (
    '2',
    'Summit Trek: Mount Mulanje Adventure',
    '4 days',
    399,
    'Mount Mulanje, Tanzania',
    'https://images.unsplash.com/photo-1589182373726-e4f658ab50f0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2187&q=80',
    ARRAY[
      'https://images.unsplash.com/photo-1501554728187-ce583db33af7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2187&q=80',
      'https://images.unsplash.com/photo-1496545672447-f699b503d270?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2071&q=80',
      'https://images.unsplash.com/photo-1682686581580-d99b0230064e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2187&q=80'
    ],
    4.9,
    'Challenge yourself with this four-day summit trek to the peak of Mount Mulanje. This adventure combines challenging hiking with incredible scenery, diverse ecosystems, and the ultimate achievement of reaching the summit at 2,720 meters.',
    'hiking',
    'challenging',
    4,
    10,
    ARRAY[
      'Summit achievement with certificate',
      'Diverse ecosystems from forests to alpine zones',
      'Spectacular sunrise views from the peak',
      'Expert mountain guides with safety training',
      'Wildlife sightings including endemic species'
    ],
    ARRAY[
      'High level of fitness required',
      'Previous hiking experience recommended',
      'Proper hiking boots and warm clothing',
      'Sleeping bag rated for cold temperatures',
      'Headlamp or flashlight for summit night'
    ],
    ARRAY[
      'Professional mountain guides',
      'Porters for group equipment',
      'All meals during the trek',
      'Camping equipment (tents, mattresses)',
      'Park and trekking permits',
      'Summit certificate'
    ],
    ARRAY[
      'Personal hiking gear',
      'Sleeping bags',
      'Travel insurance',
      'Personal expenses',
      'Tips for guides and porters',
      'Pre and post trek accommodation'
    ],
    '[
      {
        "day": 1,
        "title": "Forest Base Camp",
        "description": "Begin your adventure with a drive to the mountain base where you''ll meet your guides and porters. Trek through lush forest trails to reach the first camp.",
        "activities": [
          "Morning briefing and equipment check",
          "Transfer to mountain trailhead",
          "Trek through montane forest to base camp",
          "Bird and wildlife spotting along the trail",
          "Evening briefing about summit strategy"
        ],
        "meals": ["lunch", "dinner"],
        "accommodation": "Forest Camp (tented)",
        "distance": "6 km",
        "elevation": "450m gain"
      },
      {
        "day": 2,
        "title": "Alpine Zone Trek",
        "description": "Trek from the forest zone into the alpine environment, with changing vegetation and expanding views. Acclimatize at mid-mountain camp.",
        "activities": [
          "Morning warm-up exercises",
          "Trek through changing ecological zones",
          "Lunch at scenic viewpoint",
          "Acclimatization walks around camp",
          "Sunset viewing from rocky outcrop"
        ],
        "meals": ["breakfast", "lunch", "dinner"],
        "accommodation": "Alpine Camp (tented)",
        "distance": "8 km",
        "elevation": "650m gain"
      },
      {
        "day": 3,
        "title": "Summit Day",
        "description": "Early pre-dawn start for the summit push. Reach the peak for sunrise then descend to celebration camp for rest and recovery.",
        "activities": [
          "Pre-dawn wake-up and light breakfast",
          "Summit push by headlamp",
          "Sunrise at the summit with panoramic views",
          "Summit photos and celebration",
          "Descent to recovery camp",
          "Afternoon rest and celebration dinner"
        ],
        "meals": ["breakfast", "lunch", "dinner"],
        "accommodation": "Celebration Camp (tented)",
        "distance": "10 km",
        "elevation": "620m gain, 450m loss"
      },
      {
        "day": 4,
        "title": "Descent and Transfer",
        "description": "Complete the mountain adventure with a descent through beautiful valleys. Transfer back to Tanga with certificate ceremony.",
        "activities": [
          "Morning reflection circle",
          "Descent through scenic valley route",
          "Picnic lunch by mountain stream",
          "Final trail section to park exit",
          "Certificate ceremony and celebrations",
          "Transfer back to Tanga"
        ],
        "meals": ["breakfast", "lunch"],
        "accommodation": "",
        "distance": "12 km",
        "elevation": "1270m loss"
      }
    ]',
    '[
      {
        "question": "How challenging is the summit trek?",
        "answer": "This is our most challenging trek, rated as difficult. You''ll be hiking 6-10 hours daily with significant elevation gains. The summit day starts pre-dawn and involves 10-12 hours of hiking. Previous mountain hiking experience is strongly recommended."
      },
      {
        "question": "What temperatures should I expect?",
        "answer": "Temperatures vary dramatically with altitude. During the day, lower elevations can be 20-25°C, while at night at higher camps temperatures can drop to 0-5°C. The summit can be below freezing, especially before sunrise."
      },
      {
        "question": "Is altitude sickness a concern?",
        "answer": "At 2,720 meters, altitude effects are possible but severe altitude sickness is rare. Our 4-day itinerary is designed for proper acclimatization. Guides are trained to monitor for symptoms and respond appropriately."
      },
      {
        "question": "What toilet facilities are available during the trek?",
        "answer": "We provide portable private toilet tents at each campsite. During the hiking day, toilet facilities are limited to nature, and guides will advise on appropriate environmental practices."
      },
      {
        "question": "What if I can''t make it to the summit?",
        "answer": "Safety is our priority. If you''re unable to continue to the summit, a guide will accompany you back to the nearest camp while the rest of the group continues. There''s no shame in turning back - the journey itself is the adventure."
      }
    ]',
    false,
    NOW(),
    NOW()
  ),
  (
    '3',
    'Waterfall Valley Day Hike',
    '1 day',
    79,
    'Lushoto, Tanzania',
    'https://images.unsplash.com/photo-1513415564515-4f6037e17467?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2068&q=80',
    ARRAY[
      'https://images.unsplash.com/photo-1520637102912-2df6bb2aec6d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2189&q=80',
      'https://images.unsplash.com/photo-1650668300370-25df148ab554?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2126&q=80'
    ],
    4.7,
    'Perfect for nature lovers with limited time, this day hike explores the beautiful waterfalls near Lushoto. Trek through lush valleys, cool off in natural pools, and enjoy spectacular views on this accessible adventure.',
    'hiking',
    'easy',
    2,
    15,
    ARRAY[
      'Visit to three distinct waterfalls',
      'Swimming opportunity in natural pools',
      'Local fruit tasting along the trail',
      'Birdwatching in diverse habitats',
      'Picnic lunch at scenic viewpoint'
    ],
    ARRAY[
      'Basic fitness level - able to walk 5-6 km',
      'Swimwear (optional for waterfall swimming)',
      'Sun protection (hat, sunscreen)',
      'Comfortable walking shoes that can get wet',
      'Camera for capturing scenery'
    ],
    ARRAY[
      'Professional local guide',
      'Picnic lunch and snacks',
      'Bottled water',
      'Walking sticks if needed',
      'All permits and entry fees'
    ],
    ARRAY[
      'Transportation to/from Lushoto (can be arranged)',
      'Personal expenses',
      'Additional beverages',
      'Gratuities for guides'
    ],
    '[
      {
        "day": 1,
        "title": "Waterfall Valley Circuit",
        "description": "Embark on a circular route visiting three of the region''s most beautiful waterfalls. Trek through verdant valleys, cool off in natural pools, and enjoy a picnic lunch with spectacular views.",
        "activities": [
          "Morning meetup and briefing in Lushoto town",
          "Trek to Mkuzu Waterfall through forest trails",
          "Swimming opportunity at natural pools",
          "Picnic lunch at scenic viewpoint",
          "Visit to Soni Falls and its legends",
          "Return via traditional villages and farmlands",
          "Fresh fruit tasting at local orchard"
        ],
        "meals": ["lunch"],
        "accommodation": "",
        "distance": "10 km",
        "elevation": "250m gain, 250m loss"
      }
    ]',
    '[
      {
        "question": "Is this hike suitable for children?",
        "answer": "Yes, this is our most family-friendly hike, suitable for children aged 7 and above who are comfortable walking for a few hours. The trail has some uneven sections but no dangerous areas. Guides are experienced with families."
      },
      {
        "question": "Is swimming safe at the waterfalls?",
        "answer": "Yes, we visit specific pools that are safe for swimming. Your guide will advise which areas are appropriate. Swimming is optional, and life jackets are available for less confident swimmers."
      },
      {
        "question": "What happens if it rains?",
        "answer": "The tour runs rain or shine, as the forests are beautiful in all weather. During heavy rains, we may adjust the route for safety. Waterproof clothing is recommended during rainy season (March-May)."
      },
      {
        "question": "What kind of footwear is recommended?",
        "answer": "We recommend sturdy walking shoes or hiking sandals with good grip that you don''t mind getting wet, as some stream crossings may be necessary. The trail can be muddy after rain."
      }
    ]',
    false,
    NOW(),
    NOW()
  ),
  
  -- CYCLING TOURS
  (
    '4',
    'Tea Plantations Cycling Tour',
    '1 day',
    89,
    'Amani Nature Reserve, Tanzania',
    'https://images.unsplash.com/photo-1591184510259-b6f1be3d7aff?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80',
    ARRAY[
      'https://images.unsplash.com/photo-1503149779833-1de50ebe5f8a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
      'https://images.unsplash.com/photo-1582401656496-9d75f95f9018?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2192&q=80'
    ],
    4.7,
    'Pedal through the lush tea plantations of the Amani Nature Reserve on this refreshing day tour. Enjoy panoramic views, learn about tea production, and experience the perfect blend of exercise and culture.',
    'cycling',
    'moderate',
    2,
    12,
    ARRAY[
      'Scenic cycling through verdant tea plantations',
      'Tea factory visit with tasting experience',
      'Lunch at panoramic viewpoint',
      'Interaction with tea pickers and farmers',
      'Support vehicle throughout the journey'
    ],
    ARRAY[
      'Basic cycling proficiency',
      'Comfortable cycling attire',
      'Enclosed shoes',
      'Sun protection',
      'Water bottle'
    ],
    ARRAY[
      'Mountain bike and helmet rental',
      'Professional cycling guide',
      'Support vehicle',
      'Tea plantation and factory tour',
      'Lunch and refreshments',
      'Water and energy snacks'
    ],
    ARRAY[
      'Personal cycling gear',
      'Gratuities',
      'Personal expenses',
      'Transportation to/from start point'
    ],
    '[
      {
        "day": 1,
        "title": "Tea Plantation Cycling Circuit",
        "description": "Explore the lush tea plantations of Amani on this scenic cycling tour. Visit a working tea factory, interact with local farmers, and enjoy stunning views throughout this immersive day trip.",
        "activities": [
          "Morning meet-up and bike fitting",
          "Safety briefing and route orientation",
          "Cycle through tea plantation landscapes",
          "Visit working tea factory with processing demonstration",
          "Tea tasting session with expert guide",
          "Lunch at panoramic restaurant overlooking plantations",
          "Afternoon cycling loop through rural villages",
          "Refreshment stop at mountain viewpoint",
          "Return ride with sunset views"
        ],
        "meals": ["lunch"],
        "accommodation": "",
        "distance": "30 km",
        "elevation": "350m gain, 350m loss"
      }
    ]',
    '[
      {
        "question": "What level of cycling experience is needed?",
        "answer": "This tour is rated as moderate. Participants should be comfortable riding a bike for 3-4 hours with breaks and have some experience with gentle hills. The route is primarily on dirt roads and plantation tracks with no technical sections."
      },
      {
        "question": "What kind of bikes do you provide?",
        "answer": "We provide well-maintained mountain bikes with front suspension, appropriate for the terrain. Bikes come in various sizes to ensure proper fit. Each bike is equipped with a water bottle holder and basic repair kit."
      },
      {
        "question": "Is there vehicle support during the cycling?",
        "answer": "Yes, a support vehicle follows the group throughout the tour. If you get tired or experience any issues, you can take a break in the vehicle. The vehicle also carries water, snacks, and first aid supplies."
      },
      {
        "question": "What happens in case of rain?",
        "answer": "The tour operates in light rain with ponchos provided. In case of heavy rain, we may modify the route or, if necessary, offer an alternative activity or rescheduling. The area is generally drier in the morning, so early starts are recommended during rainy season."
      }
    ]',
    true,
    NOW(),
    NOW()
  ),
  (
    '5',
    'Mountain Biking Adventure Weekend',
    '2 days',
    199,
    'Lushoto Valley, Tanzania',
    'https://images.unsplash.com/photo-1541625602330-2277a4c46182?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    ARRAY[
      'https://images.unsplash.com/photo-1556159992-e9c397ea9be1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
      'https://images.unsplash.com/photo-1544191696-102b28546a33?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
    ],
    4.8,
    'Experience the thrill of mountain biking in the diverse terrain of the Lushoto Valley. This 2-day adventure covers challenging single tracks, forest paths, and village routes with overnight accommodation in a comfortable mountain lodge.',
    'cycling',
    'challenging',
    4,
    10,
    ARRAY[
      'Varied terrain from flowing single tracks to forest trails',
      'Overnight stay in scenic mountain lodge',
      'Experienced MTB guides with local knowledge',
      'Technical riding skills development',
      'Vehicle support and bike maintenance'
    ],
    ARRAY[
      'Intermediate to advanced mountain biking experience',
      'Good physical fitness level',
      'Personal cycling accessories (gloves, padded shorts recommended)',
      'Daypack for personal items',
      'Weather-appropriate clothing'
    ],
    ARRAY[
      'Professional mountain biking guide',
      'Quality mountain bike and helmet rental',
      'One night accommodation with breakfast',
      'All meals during the tour',
      'Support vehicle',
      'Trail snacks and water refills'
    ],
    ARRAY[
      'Personal biking gear beyond bikes and helmets',
      'Alcoholic beverages',
      'Travel insurance',
      'Transportation to/from Lushoto',
      'Personal expenses'
    ],
    '[
      {
        "day": 1,
        "title": "Forest Trails and Ridge Riding",
        "description": "Begin your mountain biking adventure with technical forest sections and rewarding ridge rides offering spectacular views of the Lushoto Valley.",
        "activities": [
          "Morning briefing, bike fitting and safety check",
          "Skills assessment and warm-up ride",
          "Technical forest single track section",
          "Lunch at forest picnic site",
          "Afternoon ridge ride with valley views",
          "Coffee break at local farm",
          "Final descent to mountain lodge",
          "Evening bike maintenance workshop"
        ],
        "meals": ["lunch", "dinner"],
        "accommodation": "Irente View Mountain Lodge",
        "distance": "35 km",
        "elevation": "650m gain, 450m loss"
      },
      {
        "day": 2,
        "title": "Village Trails and Valley Descent",
        "description": "Experience the cultural side of the region as you ride through traditional villages before tackling an exhilarating descent through the valley.",
        "activities": [
          "Sunrise yoga and stretching (optional)",
          "Breakfast at panoramic terrace",
          "Morning ride through traditional villages",
          "Visit to local bike mechanic and cycling club",
          "Lunch at community restaurant",
          "Challenging valley descent with technical sections",
          "Final ride through eucalyptus forests",
          "Celebration refreshments and tour conclusion"
        ],
        "meals": ["breakfast", "lunch"],
        "accommodation": "",
        "distance": "40 km",
        "elevation": "400m gain, 850m loss"
      }
    ]',
    '[
      {
        "question": "How technical is the riding?",
        "answer": "This tour includes technical sections rated as intermediate to advanced (comparable to blue/red trails in international trail systems). Features include rooty forest sections, some rock gardens, moderately steep descents, and occasional exposure on ridges. Alternative routes are available for particularly challenging sections."
      },
      {
        "question": "Can I bring my own bike?",
        "answer": "Absolutely! While we provide quality mountain bikes, experienced riders are welcome to bring their own bikes. We recommend full-suspension mountain bikes with at least 120mm travel for the terrain. Our support vehicle can transport your bike from/to Tanga or other major cities for an additional fee."
      },
      {
        "question": "What mechanical support is available?",
        "answer": "Our guides are trained in trail-side repairs. The support vehicle carries a comprehensive tool kit, pump, essential spare parts (tubes, cables, chain links), and a basic bike stand. For significant mechanical issues, we have partnerships with local bike shops."
      },
      {
        "question": "What is the group size?",
        "answer": "To ensure quality, safety and a smooth riding experience, we limit groups to 10 riders maximum with a ratio of 1 guide per 5 riders. For technical sections, we ride in smaller pods based on skill level."
      }
    ]',
    false,
    NOW(),
    NOW()
  ),
  
  -- CULTURAL TOURS
  (
    '6',
    'Traditional Village Immersion Experience',
    '2 days',
    199,
    'Lushoto, Tanzania',
    'https://images.unsplash.com/photo-1567942089878-d844f4561d57?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    ARRAY[
      'https://images.unsplash.com/photo-1621476318242-2be67f9560e1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
      'https://images.unsplash.com/photo-1581185595464-408f508350fb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
    ],
    4.9,
    'Immerse yourself in the authentic daily life of Tanzanian villages in the Usambara region. Learn traditional crafts, participate in local activities, enjoy home-cooked meals, and forge meaningful connections with your welcoming host community.',
    'cultural',
    'easy',
    2,
    8,
    ARRAY[
      'Homestay with local family',
      'Traditional cooking workshop',
      'Craft making with local artisans',
      'Agricultural activities on family farms',
      'Community music and dance evening',
      'Traditional healing plants walk'
    ],
    ARRAY[
      'Open mind and respectful attitude',
      'Modest clothing covering shoulders and knees',
      'Small gift for host family (optional)',
      'Basic toiletries and personal items',
      'Willingness to try new experiences and foods'
    ],
    ARRAY[
      'Local English-speaking cultural guide',
      'Homestay accommodation with local family',
      'All meals prepared by host family',
      'Cultural activities and workshops',
      'Community contribution fee',
      'Translation assistance'
    ],
    ARRAY[
      'Transportation to/from Lushoto',
      'Alcoholic beverages',
      'Personal expenses',
      'Tips for guides and host families',
      'Travel insurance'
    ],
    '[
      {
        "day": 1,
        "title": "Village Welcome and Cultural Immersion",
        "description": "Begin your cultural journey with a warm welcome into a traditional Usambara village. Meet your host family, participate in daily activities, and learn about local traditions and customs.",
        "activities": [
          "Traditional welcome ceremony with village elders",
          "Home-cooked lunch with host family",
          "Tour of the village and important community sites",
          "Participation in seasonal agricultural activities",
          "Traditional cooking lesson for dinner preparation",
          "Evening storytelling session around the fire"
        ],
        "meals": ["lunch", "dinner"],
        "accommodation": "Family Homestay",
        "distance": "",
        "elevation": ""
      },
      {
        "day": 2,
        "title": "Crafts, Markets and Community Celebration",
        "description": "Deepen your cultural experience with hands-on craft workshops, market visits, and community celebrations that showcase the richness of local traditions.",
        "activities": [
          "Morning routines with host family",
          "Traditional craft workshop (basketry, wood carving, or textile)",
          "Visit to weekly village market",
          "Lunch at community restaurant",
          "Medicinal plant walk with local healer",
          "Community music and dance session",
          "Farewell ceremony"
        ],
        "meals": ["breakfast", "lunch", "dinner"],
        "accommodation": "",
        "distance": "",
        "elevation": ""
      }
    ]',
    '[
      {
        "question": "What are the accommodation conditions like?",
        "answer": "Accommodations are in traditional family homes that have been adapted to receive guests. You''ll have a private or shared room within the family home with basic amenities. Bathrooms are typically shared and may have simple facilities with bucket showers and pit toilets. This authentic experience prioritizes cultural immersion over luxury."
      },
      {
        "question": "What kind of food will be served?",
        "answer": "Meals are authentic, home-cooked Tanzanian dishes primarily using ingredients from the family farm or local market. Typical foods include ugali (cornmeal porridge), rice, beans, local vegetables, fruits, and occasionally chicken or fish. Vegetarian options are easily accommodated, but specific dietary restrictions should be communicated in advance."
      },
      {
        "question": "Is there any language barrier?",
        "answer": "While family members may have limited English, your cultural guide provides translation throughout the experience. You''ll also learn basic Swahili greetings and phrases to enhance your interaction with the community. The language exchange is often a cherished part of the experience."
      },
      {
        "question": "How does the tour benefit the local community?",
        "answer": "This tour follows fair trade tourism principles. Host families receive direct payment for accommodations and meals. A community fund contribution is included in your tour price, supporting local education and healthcare initiatives. Additionally, craft purchases provide income directly to artisans."
      }
    ]',
    true,
    NOW(),
    NOW()
  ),
  (
    '7',
    'Traditional Cooking Workshop',
    '1 day',
    65,
    'Mombo Village, Tanzania',
    'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    ARRAY[
      'https://images.unsplash.com/photo-1590301157890-4810ed352733?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2187&q=80',
      'https://images.unsplash.com/photo-1505576633757-0ac1084f63cd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2188&q=80'
    ],
    4.8,
    'Learn the art of traditional Tanzanian cooking in this immersive one-day culinary workshop. Visit local markets, harvest ingredients from organic gardens, and master authentic recipes under the guidance of expert local cooks.',
    'cultural',
    'easy',
    4,
    12,
    ARRAY[
      'Market tour with ingredient selection',
      'Hands-on cooking with traditional methods',
      'Recipe booklet to take home',
      'Meal sharing with local community members',
      'Traditional spice preparation techniques'
    ],
    ARRAY[
      'No prior cooking experience necessary',
      'Openness to new flavors and techniques',
      'Closed-toe shoes for kitchen safety',
      'Long pants recommended for cooking',
      'Bring containers if you wish to take leftovers'
    ],
    ARRAY[
      'Local market tour',
      'All ingredients and cooking materials',
      'Recipe booklet in English',
      'Full meal of prepared dishes',
      'English-speaking culinary guide',
      'Traditional cooking certificate'
    ],
    ARRAY[
      'Transportation to/from Mombo Village',
      'Alcoholic beverages',
      'Personal expenses',
      'Additional food beyond the prepared dishes'
    ],
    '[
      {
        "day": 1,
        "title": "From Market to Table: Tanzanian Cooking Journey",
        "description": "Immerse yourself in the vibrant culinary traditions of Tanzania through this hands-on cooking workshop. From market shopping to traditional cooking techniques and a communal feast, experience the full journey of Tanzanian cuisine.",
        "activities": [
          "Morning visit to local market with ingredient lessons",
          "Herb and vegetable harvesting from community garden",
          "Traditional fire starting and cooking method demonstration",
          "Hands-on preparation of 5-6 authentic dishes",
          "Spice grinding and blending workshop",
          "Communal lunch enjoying prepared dishes",
          "Recipe discussion and technique review",
          "Certificate presentation and farewell"
        ],
        "meals": ["lunch"],
        "accommodation": "",
        "distance": "",
        "elevation": ""
      }
    ]',
    '[
      {
        "question": "What dishes will we learn to cook?",
        "answer": "The workshop includes 5-6 traditional dishes that may include: Pilau (spiced rice), Mchuzi wa Nyama (beef stew), Maharage (bean stew), Ndizi Kaanga (fried plantains), Kachumbari (fresh tomato and onion salad), and Chapati (flatbread). Seasonal variations may occur based on available ingredients."
      },
      {
        "question": "Can dietary restrictions be accommodated?",
        "answer": "Yes, vegetarian, vegan, and gluten-free options can be accommodated with advance notice. Please inform us of any allergies or dietary restrictions when booking so we can adapt recipes accordingly."
      },
      {
        "question": "What cooking facilities are used?",
        "answer": "You'll experience both traditional and modern cooking methods. This includes cooking over an open fire, using clay pots, traditional wooden tools, and stone grinding techniques. The kitchen is a covered outdoor setting in a traditional compound."
      },
      {
        "question": "Will I be able to recreate these dishes at home?",
        "answer": "Absolutely! We focus on techniques and ingredients that can be replicated or substituted in various international settings. Your take-home recipe booklet includes tips for finding or substituting authentic ingredients wherever you live."
      }
    ]',
    false,
    NOW(),
    NOW()
  ),
  
  -- 4X4 EXPEDITION
  (
    '8',
    'Usambara 4x4 Photography Expedition',
    '3 days',
    499,
    'Usambara Mountains, Tanzania',
    'https://images.unsplash.com/photo-1605282003441-52a7a3c74c3a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2187&q=80',
    ARRAY[
      'https://images.unsplash.com/photo-1546183997-a0139b4ebed7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
      'https://images.unsplash.com/photo-1518633642646-cbe3719685c8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
      'https://images.unsplash.com/photo-1587547127473-a09bae18d077?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2073&q=80'
    ],
    4.9,
    'Explore the remote corners of the Usambara Mountains in specially equipped 4x4 vehicles on this photography-focused expedition. Access hard-to-reach viewpoints, chase the perfect light, and capture the incredible diversity of landscapes and cultures.',
    '4x4',
    'moderate',
    3,
    8,
    ARRAY[
      'Access to remote photography locations',
      'Professional photography guidance',
      'Sunrise and sunset shoots at prime locations',
      'Small group size for personalized attention',
      'Comfortable lodges with charging facilities'
    ],
    ARRAY[
      'Basic photography experience recommended',
      'Camera equipment (DSLR/mirrorless recommended)',
      'Extra batteries and memory cards',
      'Laptop for optional evening editing sessions',
      'Comfortable clothing for various weather conditions'
    ],
    ARRAY[
      '4x4 vehicle transportation throughout',
      'Professional driver-guide',
      'Photography guide and instructor',
      'All accommodation as specified',
      'All meals and bottled water',
      'Park and community fees'
    ],
    ARRAY[
      'Alcoholic beverages',
      'Photography equipment',
      'Travel insurance',
      'Personal expenses',
      'Tips for guides and staff'
    ],
    '[
      {
        "day": 1,
        "title": "Mountain Vistas and Forest Light",
        "description": "Begin your photography adventure capturing the stunning mountain panoramas and magical forest light of the Usambara highlands.",
        "activities": [
          "Early morning departure from Tanga",
          "Ascent into the mountains with photo stops",
          "Golden hour shoot at Irente Viewpoint",
          "High-altitude forest photography session",
          "Lunch at scenic mountain restaurant",
          "Afternoon light and shadow study in ancient forests",
          "Evening photography review session at lodge"
        ],
        "meals": ["lunch", "dinner"],
        "accommodation": "Mountain Forest Lodge",
        "distance": "120 km driving, short walks to viewpoints",
        "elevation": "Various elevations up to 2,000m"
      },
      {
        "day": 2,
        "title": "Culture and Rural Landscapes",
        "description": "Focus your lens on the cultural aspects and rural landscapes of the Usambara region, from traditional villages to patterns of terraced farms.",
        "activities": [
          "Pre-dawn departure for sunrise shoot",
          "Morning mist and valleys photography",
          "Traditional village documentary session",
          "Portrait photography workshop (with permissions)",
          "Lunch with local family",
          "Afternoon drive to remote viewpoints",
          "Sunset shoot at panoramic location",
          "Evening photo editing workshop"
        ],
        "meals": ["breakfast", "lunch", "dinner"],
        "accommodation": "Mambo Viewpoint Eco-Lodge",
        "distance": "80 km driving, various walking opportunities",
        "elevation": "Various elevations"
      },
      {
        "day": 3,
        "title": "Waterfalls and Return Journey",
        "description": "Capture the dynamic movement of water and complete your visual story of the Usambaras before returning with a full portfolio of diverse images.",
        "activities": [
          "Optional sunrise shoot from lodge",
          "Long-exposure waterfall photography techniques",
          "Stream and forest detail photography workshop",
          "Picnic lunch at secluded location",
          "Final shooting opportunity at tea plantations",
          "Photography review and feedback session",
          "Return journey to Tanga with sunset stops"
        ],
        "meals": ["breakfast", "lunch"],
        "accommodation": "",
        "distance": "150 km driving, short walks to photo locations",
        "elevation": "Descending from mountains to lowlands"
      }
    ]',
    '[
      {
        "question": "What photography skill level is this tour designed for?",
        "answer": "This expedition caters to intermediate photographers who are familiar with their equipment and basic photography principles. We focus on creative techniques, composition, and capturing the unique light and landscapes rather than basic camera operation. Beginners with a strong interest are welcome but should be comfortable with their camera's manual settings."
      },
      {
        "question": "What camera equipment should I bring?",
        "answer": "We recommend a DSLR or mirrorless camera with interchangeable lenses. Suggested lenses include: wide-angle (for landscapes), standard zoom, and telephoto lens (for wildlife opportunities and compression effects in landscapes). A tripod is essential for low-light and long-exposure photography. Bring plenty of batteries, memory cards, and cleaning equipment."
      },
      {
        "question": "How physically demanding is this tour?",
        "answer": "This tour is rated moderate. While we access many locations by vehicle, the best photos often require short walks (15-30 minutes) to viewpoints, sometimes on uneven terrain or moderate inclines. You should be comfortable walking on unpaved paths while carrying your camera gear."
      },
      {
        "question": "Is there electricity for charging camera equipment?",
        "answer": "Yes, all our accommodations have electricity for charging batteries and laptops. However, occasional power outages are possible in rural Tanzania, so we recommend bringing extra batteries. Our vehicles also have inverters for emergency charging during the day."
      }
    ]',
    true,
    NOW(),
    NOW()
  ),
  
  -- MOTOCAMPING
  (
    '9',
    'Usambara Motocamping Adventure',
    '4 days',
    599,
    'Usambara Region, Tanzania',
    'https://images.unsplash.com/photo-1558981359-219d6364c9c8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    ARRAY[
      'https://images.unsplash.com/photo-1473181488821-2d23949a045a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
      'https://images.unsplash.com/photo-1471115853179-bb1d604434e0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
    ],
    4.7,
    'Discover the freedom of motorcycle adventure camping in the beautiful Usambara region. This tour combines the thrill of off-road riding with the serenity of wilderness camping in some of Tanzania\'s most spectacular locations.',
    'motocamping',
    'challenging',
    4,
    8,
    ARRAY[
      'Guided motorcycle adventure through diverse terrain',
      'Wild camping in stunning remote locations',
      'Campfire dinners under the stars',
      'Off-road riding skills development',
      'Support vehicle for camping equipment'
    ],
    ARRAY[
      'Motorcycle license and previous riding experience',
      'Appropriate riding gear (helmet, jacket, boots)',
      'Sleeping bag and personal camping items',
      'All-weather clothing',
      'Basic camping comfort tolerance'
    ],
    ARRAY[
      'Motorcycle rental (Royal Enfield Himalayan)',
      'Fuel throughout the journey',
      'Camping equipment (tents, mats, cooking gear)',
      'All meals while on tour',
      'Professional motorcycle guide',
      'Support vehicle for luggage and equipment',
      'Basic motorcycle maintenance and repairs'
    ],
    ARRAY[
      'Personal riding gear',
      'Sleeping bag and pillow',
      'Alcoholic beverages',
      'Motorcycle insurance excess',
      'Personal travel insurance',
      'Tips for guides and support crew'
    ],
    '[
      {
        "day": 1,
        "title": "Orientation and Mountain Ascent",
        "description": "Begin your motocamping adventure with motorcycle orientation, safety briefing, and an exciting ascent into the Usambara Mountains to your first wilderness campsite.",
        "activities": [
          "Morning motorcycle assignment and familiarization",
          "Safety and group riding briefing",
          "Practice session in controlled environment",
          "Departure from Tanga with scenic coastal road",
          "Lunch at roadside local restaurant",
          "Afternoon ascent into Usambara foothills",
          "Off-road tracks to remote camping location",
          "Camp setup demonstration",
          "Campfire dinner under the stars"
        ],
        "meals": ["lunch", "dinner"],
        "accommodation": "Riverside Wilderness Camp (tents)",
        "distance": "120 km (70% paved, 30% dirt roads)",
        "elevation": "900m gain"
      },
      {
        "day": 2,
        "title": "Forest Tracks and Highland Routes",
        "description": "Explore deeper into the mountains via forest tracks and highland routes, improving your off-road skills while discovering remote villages and viewpoints.",
        "activities": [
          "Early morning coffee by the campfire",
          "Camp breakdown instruction",
          "Forest track riding with technical instruction",
          "Visit to hidden waterfall accessible only by trail",
          "Picnic lunch at scenic viewpoint",
          "Afternoon ride through remote villages",
          "Tea plantation exploration",
          "Arrival at mountain viewpoint camp",
          "Sunset photography session",
          "Night sky observation after dinner"
        ],
        "meals": ["breakfast", "lunch", "dinner"],
        "accommodation": "Eagle Viewpoint Camp (tents)",
        "distance": "90 km (20% paved, 80% off-road)",
        "elevation": "600m gain, 300m loss"
      },
      {
        "day": 3,
        "title": "Ridge Riding and Valley Descent",
        "description": "Experience the exhilaration of ridge riding with spectacular views followed by a technical descent into a lush valley for your final wilderness camping experience.",
        "activities": [
          "Morning yoga stretching session (optional)",
          "Ridge route with panoramic valley views",
          "Advanced off-road techniques practice",
          "Lunch at local mountain restaurant",
          "Afternoon technical descent into valley",
          "River crossing techniques (seasonal)",
          "Wild camping near ancient forest",
          "Traditional barbecue dinner preparation",
          "Campfire stories and experiences sharing"
        ],
        "meals": ["breakfast", "lunch", "dinner"],
        "accommodation": "Ancient Forest Camp (tents)",
        "distance": "110 km (10% paved, 90% off-road)",
        "elevation": "400m gain, 950m loss"
      },
      {
        "day": 4,
        "title": "Local Trails and Return Journey",
        "description": "Complete your motocamping adventure with morning exploration of local trails before returning to civilization with newfound skills and unforgettable memories.",
        "activities": [
          "Dawn wildlife spotting walk (optional)",
          "Final camp breakfast preparation",
          "Local village trails exploration",
          "Coffee plantation visit and tasting",
          "Lunch at family-owned restaurant",
          "Afternoon return journey on mixed terrain",
          "Final viewpoint photo opportunity",
          "Return to Tanga",
          "Motorcycle return and debriefing",
          "Farewell ceremony and certificate presentation"
        ],
        "meals": ["breakfast", "lunch"],
        "accommodation": "",
        "distance": "135 km (60% paved, 40% off-road)",
        "elevation": "200m gain, 850m loss"
      }
    ]',
    '[
      {
        "question": "What type of motorcycles are used for this tour?",
        "answer": "We use Royal Enfield Himalayan motorcycles (411cc), which are perfectly suited for the mixed terrain of this adventure. These bikes offer a good balance of on-road comfort and off-road capability, with enough power for the terrain without being overwhelming. They have a comfortable upright riding position and good ground clearance."
      },
      {
        "question": "What riding experience is required?",
        "answer": "Participants should have at least 2 years of motorcycle riding experience and some exposure to unpaved/gravel roads. This tour is not suitable for beginner riders. You should be comfortable with your motorcycle tipping over and have the strength to help right a fallen motorcycle. Basic off-road skills will be taught during the tour."
      },
      {
        "question": "What is the camping experience like?",
        "answer": "We practice ''leave no trace'' wilderness camping in carefully selected locations. Tents are modern 3-season quality with sleeping mats provided. Bathroom facilities are basic (portable camping toilets and privacy shelter). Washing is via biodegradable soap and water. Meals are prepared over campfires or portable stoves by our camp chef."
      },
      {
        "question": "What happens in case of motorcycle breakdown or if I cannot continue riding?",
        "answer": "Our support vehicle follows the group with spare parts and tools for common repairs. In case of serious breakdown, we provide an alternative motorcycle when possible. If you''re unable to ride due to fatigue or minor injury, you can travel in the support vehicle for part or all of a day while we transport your motorcycle."
      }
    ]',
    false,
    NOW(),
    NOW()
  ),
  
  -- SCHOOL TOUR
  (
    '10',
    'Educational Biodiversity Expedition',
    '3 days',
    249,
    'Amani Nature Reserve, Tanzania',
    'https://images.unsplash.com/photo-1544531585-9847b68c8c86?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    ARRAY[
      'https://images.unsplash.com/photo-1454166155302-ef4863c27e70?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
      'https://images.unsplash.com/photo-1503751071777-d2918b21bbd9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
    ],
    4.9,
    'A specialized educational tour for school groups, combining hands-on learning with adventure in the biodiversity hotspot of Amani Nature Reserve. Students engage in field research, conservation activities, and cultural exchange while developing teamwork skills.',
    'school',
    'easy',
    10,
    30,
    ARRAY[
      'Guided biodiversity surveys and research activities',
      'Butterfly farming conservation project visit',
      'Night forest walk for nocturnal species observation',
      'Cultural exchange with local school',
      'Conservation workshop with reserve scientists'
    ],
    ARRAY[
      'School group with supervising teachers (1:10 ratio)',
      'Preparation through provided pre-trip educational materials',
      'Field clothes, hiking shoes and rain gear',
      'Notebooks and writing materials',
      'Flashlight for night activities'
    ],
    ARRAY[
      'Qualified educational guides and naturalists',
      'All accommodation in student-friendly facilities',
      'All meals with options for dietary requirements',
      'Transportation during the program',
      'Educational materials and field equipment',
      'First aid kit and basic medical support'
    ],
    ARRAY[
      'Transportation to/from the starting point',
      'Personal expenses',
      'Additional snacks and beverages',
      'Travel insurance',
      'Personal field or research equipment'
    ],
    '[
      {
        "day": 1,
        "title": "Forest Ecosystem Introduction",
        "description": "Begin the educational journey with an immersive introduction to the forest ecosystem, biodiversity concepts, and research techniques in the Amani Nature Reserve.",
        "activities": [
          "Arrival and welcome briefing on conservation history",
          "Interactive introduction to biodiversity concepts",
          "Forest ecosystem scavenger hunt",
          "Field research techniques workshop",
          "Lunch at research center",
          "Afternoon biodiversity survey in groups",
          "Data collection and preliminary analysis",
          "Evening presentation by reserve scientists",
          "Night insect observation (optional)"
        ],
        "meals": ["lunch", "dinner"],
        "accommodation": "Amani Research Center Dormitories",
        "distance": "Various short walking excursions",
        "elevation": "Minimal elevation changes"
      },
      {
        "day": 2,
        "title": "Conservation in Practice",
        "description": "Experience conservation in action through hands-on activities, project visits, and meaningful cultural exchange with local students working on environmental initiatives.",
        "activities": [
          "Morning bird watching and identification",
          "Visit to butterfly farming conservation project",
          "Participation in tree nursery activities",
          "Cultural exchange with local school students",
          "Joint lunch and conservation games",
          "Afternoon water quality testing at forest streams",
          "Collaborative conservation challenge",
          "Evening presentation preparation by student groups",
          "Night forest walk to observe nocturnal species"
        ],
        "meals": ["breakfast", "lunch", "dinner"],
        "accommodation": "Amani Research Center Dormitories",
        "distance": "3-4 km of walking throughout the day",
        "elevation": "Moderate elevation changes"
      },
      {
        "day": 3,
        "title": "From Learning to Action",
        "description": "Synthesize the educational experience through project completion, presentation of findings, and development of action plans to continue conservation efforts after returning home.",
        "activities": [
          "Final data collection for research projects",
          "Group analysis and presentation preparation",
          "Research project presentations to scientists",
          "Lunch with feedback session",
          "Conservation action planning workshop",
          "Tree planting ceremony",
          "Certificate award and closing reflection",
          "Departure with take-home materials and resources"
        ],
        "meals": ["breakfast", "lunch"],
        "accommodation": "",
        "distance": "Various short walking excursions",
        "elevation": "Minimal elevation changes"
      }
    ]',
    '[
      {
        "question": "How is this tour educational rather than just recreational?",
        "answer": "This expedition follows a structured curriculum aligned with science education standards. Students engage in actual scientific data collection using established protocols, with data contributing to ongoing research. Activities build scientific inquiry skills, critical thinking, and conservation understanding. Pre and post-trip materials help teachers integrate the experience into their curriculum."
      },
      {
        "question": "What age group is this tour designed for?",
        "answer": "This program is designed for students aged 12-18 (secondary school level). Activities are adaptable based on age group, with more advanced research protocols for older students and more guided discovery for younger groups. We require a pre-trip consultation with teachers to tailor the program to curriculum needs and student abilities."
      },
      {
        "question": "What safety measures are in place for student groups?",
        "answer": "Safety is our highest priority. Our measures include: qualified guides trained in first aid and youth management; thorough risk assessments for all activities; 24-hour staff presence; secure accommodations with student-appropriate room assignments; clear boundaries and supervision protocols; communication systems for emergencies; and vetted transportation providers."
      },
      {
        "question": "Is there a teacher preparation package available?",
        "answer": "Yes, booking includes a comprehensive teacher package with pre-trip classroom activities, subject-specific content materials, student preparation checklists, risk assessment documentation for school administration, parent information sheets, and post-trip assessment tools. We also offer a teacher planning call to customize the experience for your specific educational objectives."
      }
    ]',
    false,
    NOW(),
    NOW()
  )
ON CONFLICT (id) DO NOTHING;