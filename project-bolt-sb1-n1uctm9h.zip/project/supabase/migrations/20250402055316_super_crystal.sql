/*
  # Create admin stats function

  1. New Functions
    - `get_admin_stats`
      - Returns statistics for the admin dashboard including:
        - Total tours count
        - Total events count
        - Total bookings count
        - Total users count
        - Recent bookings
        - Popular tours
*/

-- Create function to get admin dashboard statistics
CREATE OR REPLACE FUNCTION get_admin_stats()
RETURNS JSONB AS $$
DECLARE
  result JSONB;
BEGIN
  -- Only allow admins to access this function
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Access denied: User is not an admin';
  END IF;

  SELECT jsonb_build_object(
    'total_tours', (SELECT COUNT(*) FROM tours),
    'total_events', (SELECT COUNT(*) FROM events),
    'total_bookings', (SELECT COUNT(*) FROM bookings),
    'total_users', (SELECT COUNT(*) FROM profiles),
    'recent_bookings', (
      SELECT jsonb_agg(b)
      FROM (
        SELECT 
          b.id,
          b.booking_reference,
          b.booking_date,
          b.travel_date,
          b.customer_name,
          b.customer_email,
          b.total_amount,
          b.status,
          b.payment_status,
          t.title as tour_title,
          e.title as event_title
        FROM bookings b
        LEFT JOIN tours t ON b.tour_id = t.id
        LEFT JOIN events e ON b.event_id = e.id
        ORDER BY b.booking_date DESC
        LIMIT 10
      ) b
    ),
    'popular_tours', (
      SELECT jsonb_agg(t)
      FROM (
        SELECT 
          t.id,
          t.title,
          t.image_url,
          t.price,
          t.rating,
          COUNT(b.id) as booking_count
        FROM tours t
        LEFT JOIN bookings b ON t.id = b.tour_id
        GROUP BY t.id
        ORDER BY booking_count DESC
        LIMIT 5
      ) t
    )
  ) INTO result;

  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;