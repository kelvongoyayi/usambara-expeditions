/*
  # Add is_admin column to profiles table

  1. Changes
    - Add is_admin column to profiles table
    - Add RLS policies for admin access
*/

-- Add is_admin column to profiles table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'is_admin'
  ) THEN
    ALTER TABLE profiles ADD COLUMN is_admin BOOLEAN DEFAULT false;
  END IF;
END $$;

-- Policy for admins to read all profiles
CREATE POLICY IF NOT EXISTS "Admins can read all profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (is_admin = true);

-- Policy for admins to update all profiles
CREATE POLICY IF NOT EXISTS "Admins can update all profiles"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (is_admin = true);

-- Policy for admins to delete profiles
CREATE POLICY IF NOT EXISTS "Admins can delete profiles"
  ON profiles
  FOR DELETE
  TO authenticated
  USING (is_admin = true);