/*
  # Fix Tours and Events Schema

  1. Tables
    - Ensures tour_categories and event_types tables exist with proper structure
    - Updates tours and events tables with required fields if missing
    - Creates admin_logs table for tracking admin actions
  
  2. Sample Data
    - Adds default tour categories and event types
  
  3. RLS Policies
    - Sets up appropriate security policies for all tables
    
  4. Procedures
    - Adds helper functions for safely inserting data without duplicates
*/

-- ============================================================================
-- TOUR CATEGORIES
-- ============================================================================

-- Create tour_categories table if it doesn't exist
CREATE TABLE IF NOT EXISTS tour_categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- Enable RLS on tour_categories
ALTER TABLE tour_categories ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for tour_categories
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies WHERE tablename = 'tour_categories' AND policyname = 'Allow public read access'
  ) THEN
    CREATE POLICY "Allow public read access" ON tour_categories
      FOR SELECT USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT FROM pg_policies WHERE tablename = 'tour_categories' AND policyname = 'Allow authenticated users full access'
  ) THEN
    CREATE POLICY "Allow authenticated users full access" ON tour_categories
      FOR ALL
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END
$$;

-- ============================================================================
-- EVENT TYPES
-- ============================================================================

-- Create event_types table if it doesn't exist
CREATE TABLE IF NOT EXISTS event_types (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- Enable RLS on event_types
ALTER TABLE event_types ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for event_types
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies WHERE tablename = 'event_types' AND policyname = 'Allow public read access'
  ) THEN
    CREATE POLICY "Allow public read access" ON event_types
      FOR SELECT USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT FROM pg_policies WHERE tablename = 'event_types' AND policyname = 'Allow authenticated users full access'
  ) THEN
    CREATE POLICY "Allow authenticated users full access" ON event_types
      FOR ALL
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END
$$;

-- ============================================================================
-- TOURS TABLE
-- ============================================================================

-- Check if tours table exists, if not create it
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'tours'
  ) THEN
    CREATE TABLE tours (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      title TEXT NOT NULL,
      slug TEXT,
      description TEXT NOT NULL,
      category TEXT,
      location TEXT NOT NULL,
      duration TEXT NOT NULL,
      price DECIMAL NOT NULL,
      image_url TEXT,
      rating DECIMAL DEFAULT 4.5,
      featured BOOLEAN DEFAULT false,
      difficulty TEXT DEFAULT 'moderate',
      min_group_size INTEGER,
      max_group_size INTEGER,
      start_location TEXT,
      end_location TEXT,
      highlights TEXT[],
      requirements TEXT[],
      included TEXT[],
      excluded TEXT[],
      gallery TEXT[],
      itinerary JSONB,
      faqs JSONB,
      created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
      updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
    );

    -- Enable RLS on tours
    ALTER TABLE tours ENABLE ROW LEVEL SECURITY;
  ELSE
    -- Add missing columns if the table already exists
    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'slug') THEN
      ALTER TABLE tours ADD COLUMN slug TEXT;
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'highlights') THEN
      ALTER TABLE tours ADD COLUMN highlights TEXT[];
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'requirements') THEN
      ALTER TABLE tours ADD COLUMN requirements TEXT[];
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'included') THEN
      ALTER TABLE tours ADD COLUMN included TEXT[];
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'excluded') THEN
      ALTER TABLE tours ADD COLUMN excluded TEXT[];
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'gallery') THEN
      ALTER TABLE tours ADD COLUMN gallery TEXT[];
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'itinerary') THEN
      ALTER TABLE tours ADD COLUMN itinerary JSONB;
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'faqs') THEN
      ALTER TABLE tours ADD COLUMN faqs JSONB;
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'tours' AND column_name = 'updated_at') THEN
      ALTER TABLE tours ADD COLUMN updated_at TIMESTAMPTZ DEFAULT now() NOT NULL;
    END IF;
  END IF;
END
$$;

-- Create RLS policies for tours
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies WHERE tablename = 'tours' AND policyname = 'Allow public read access'
  ) THEN
    CREATE POLICY "Allow public read access" ON tours
      FOR SELECT USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT FROM pg_policies WHERE tablename = 'tours' AND policyname = 'Allow authenticated users full access'
  ) THEN
    CREATE POLICY "Allow authenticated users full access" ON tours
      FOR ALL
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END
$$;

-- ============================================================================
-- EVENTS TABLE
-- ============================================================================

-- Check if events table exists, if not create it
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'events'
  ) THEN
    CREATE TABLE events (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      title TEXT NOT NULL,
      slug TEXT,
      description TEXT NOT NULL,
      event_type TEXT,
      location TEXT NOT NULL,
      start_date TIMESTAMPTZ NOT NULL,
      end_date TIMESTAMPTZ NOT NULL,
      duration TEXT NOT NULL,
      price DECIMAL NOT NULL,
      image_url TEXT,
      rating DECIMAL DEFAULT 4.5,
      featured BOOLEAN DEFAULT false,
      min_attendees INTEGER,
      max_attendees INTEGER,
      highlights TEXT[],
      included TEXT[],
      excluded TEXT[],
      gallery TEXT[],
      itinerary JSONB,
      faqs JSONB,
      created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
      updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
    );

    -- Enable RLS on events
    ALTER TABLE events ENABLE ROW LEVEL SECURITY;
  ELSE
    -- Add missing columns if the table already exists
    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'slug') THEN
      ALTER TABLE events ADD COLUMN slug TEXT;
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'event_type') THEN
      ALTER TABLE events ADD COLUMN event_type TEXT;
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'highlights') THEN
      ALTER TABLE events ADD COLUMN highlights TEXT[];
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'included') THEN
      ALTER TABLE events ADD COLUMN included TEXT[];
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'excluded') THEN
      ALTER TABLE events ADD COLUMN excluded TEXT[];
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'gallery') THEN
      ALTER TABLE events ADD COLUMN gallery TEXT[];
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'itinerary') THEN
      ALTER TABLE events ADD COLUMN itinerary JSONB;
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'faqs') THEN
      ALTER TABLE events ADD COLUMN faqs JSONB;
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'min_attendees') THEN
      ALTER TABLE events ADD COLUMN min_attendees INTEGER;
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'max_attendees') THEN
      ALTER TABLE events ADD COLUMN max_attendees INTEGER;
    END IF;

    IF NOT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'events' AND column_name = 'updated_at') THEN
      ALTER TABLE events ADD COLUMN updated_at TIMESTAMPTZ DEFAULT now() NOT NULL;
    END IF;
  END IF;
END
$$;

-- Create RLS policies for events
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies WHERE tablename = 'events' AND policyname = 'Allow public read access'
  ) THEN
    CREATE POLICY "Allow public read access" ON events
      FOR SELECT USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT FROM pg_policies WHERE tablename = 'events' AND policyname = 'Allow authenticated users full access'
  ) THEN
    CREATE POLICY "Allow authenticated users full access" ON events
      FOR ALL
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END
$$;

-- ============================================================================
-- ADMIN LOGS
-- ============================================================================

-- Create admin logs table for tracking admin actions
CREATE TABLE IF NOT EXISTS admin_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  action_type TEXT NOT NULL,
  table_name TEXT NOT NULL,
  record_id TEXT NOT NULL,
  details JSONB,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  user_id UUID REFERENCES auth.users(id)
);

-- Enable RLS on admin_logs
ALTER TABLE admin_logs ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for admin_logs
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies WHERE tablename = 'admin_logs' AND policyname = 'Allow authenticated users to read logs'
  ) THEN
    CREATE POLICY "Allow authenticated users to read logs" ON admin_logs
      FOR SELECT
      TO authenticated
      USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT FROM pg_policies WHERE tablename = 'admin_logs' AND policyname = 'Allow authenticated users to insert logs'
  ) THEN
    CREATE POLICY "Allow authenticated users to insert logs" ON admin_logs
      FOR INSERT
      TO authenticated
      WITH CHECK (true);
  END IF;
END
$$;

-- ============================================================================
-- HELPER FUNCTIONS
-- ============================================================================

-- Create a helper function to safely insert a tour category
CREATE OR REPLACE FUNCTION insert_tour_category(
  category_id TEXT,
  category_name TEXT,
  category_description TEXT DEFAULT NULL,
  category_icon TEXT DEFAULT NULL
) RETURNS VOID AS $$
BEGIN
  INSERT INTO tour_categories (id, name, description, icon)
  VALUES (category_id, category_name, category_description, category_icon)
  ON CONFLICT (id) DO UPDATE
  SET
    name = category_name,
    description = category_description,
    icon = category_icon;
END;
$$ LANGUAGE plpgsql;

-- Create a helper function to safely insert an event type
CREATE OR REPLACE FUNCTION insert_event_type(
  type_id TEXT,
  type_name TEXT,
  type_description TEXT DEFAULT NULL,
  type_icon TEXT DEFAULT NULL
) RETURNS VOID AS $$
BEGIN
  INSERT INTO event_types (id, name, description, icon)
  VALUES (type_id, type_name, type_description, type_icon)
  ON CONFLICT (id) DO UPDATE
  SET
    name = type_name,
    description = type_description,
    icon = type_icon;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- SEED DATA
-- ============================================================================

-- Insert tour categories
SELECT insert_tour_category(
  'hiking',
  'Hiking',
  'Guided hiking tours through beautiful trails and mountains',
  'mountain'
);

SELECT insert_tour_category(
  'cycling',
  'Cycling',
  'Thrilling cycling expeditions through various terrains',
  'bike'
);

SELECT insert_tour_category(
  'cultural',
  'Cultural',
  'Experience the rich cultural heritage with local guides',
  'map'
);

SELECT insert_tour_category(
  '4x4',
  '4x4 Expedition',
  'Off-road adventures in 4x4 vehicles through challenging terrain',
  'compass'
);

SELECT insert_tour_category(
  'motocamping',
  'Motocamping',
  'Motor biking adventures with camping experiences',
  'activity'
);

SELECT insert_tour_category(
  'school',
  'School Tours',
  'Educational tours for school groups and students',
  'users'
);

-- Insert event types
SELECT insert_event_type(
  'corporate',
  'Corporate Event',
  'Team building events, conferences, and retreats designed for businesses',
  'briefcase'
);

SELECT insert_event_type(
  'adventure',
  'Adventure Event',
  'Exciting outdoor activities and challenges for thrill seekers',
  'mountain'
);

SELECT insert_event_type(
  'education',
  'Educational Program',
  'Learning experiences, workshops, and educational tours for schools',
  'graduation-cap'
);

SELECT insert_event_type(
  'special',
  'Special Occasion',
  'Weddings, celebrations, and memorable events for special moments',
  'gift'
);

-- ============================================================================
-- HELPER TRIGGERS
-- ============================================================================

-- Create trigger to automatically update updated_at timestamp for tours
DROP TRIGGER IF EXISTS tours_updated_at_trigger ON tours;
CREATE TRIGGER tours_updated_at_trigger
BEFORE UPDATE ON tours
FOR EACH ROW
EXECUTE FUNCTION set_updated_at_column();

-- Create trigger to automatically update updated_at timestamp for events
DROP TRIGGER IF EXISTS events_updated_at_trigger ON events;
CREATE TRIGGER events_updated_at_trigger
BEFORE UPDATE ON events
FOR EACH ROW
EXECUTE FUNCTION set_updated_at_column();

-- Create the set_updated_at_column function if it doesn't exist
CREATE OR REPLACE FUNCTION set_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- ============================================================================
-- BOOKINGS TABLE
-- ============================================================================

-- Check if bookings table exists, if not create it
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'bookings'
  ) THEN
    CREATE TABLE bookings (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id UUID REFERENCES auth.users(id),
      booking_reference TEXT NOT NULL UNIQUE,
      booking_date TIMESTAMPTZ DEFAULT now() NOT NULL,
      travel_date TIMESTAMPTZ,
      customer_name TEXT NOT NULL,
      customer_email TEXT NOT NULL,
      tour_id UUID REFERENCES tours(id) ON DELETE SET NULL,
      event_id UUID REFERENCES events(id) ON DELETE SET NULL,
      total_amount DECIMAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      payment_status TEXT NOT NULL DEFAULT 'pending',
      created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
      updated_at TIMESTAMPTZ DEFAULT now() NOT NULL,
      
      -- At least one of tour_id or event_id must be specified
      CONSTRAINT booking_has_tour_or_event CHECK (
        (tour_id IS NOT NULL) OR (event_id IS NOT NULL)
      )
    );

    -- Enable RLS on bookings
    ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
  END IF;
END
$$;

-- Create RLS policies for bookings
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies WHERE tablename = 'bookings' AND policyname = 'Users can view their own bookings'
  ) THEN
    CREATE POLICY "Users can view their own bookings" ON bookings
      FOR SELECT
      TO authenticated
      USING (user_id = auth.uid());
  END IF;

  IF NOT EXISTS (
    SELECT FROM pg_policies WHERE tablename = 'bookings' AND policyname = 'Users can create their own bookings'
  ) THEN
    CREATE POLICY "Users can create their own bookings" ON bookings
      FOR INSERT
      TO authenticated
      WITH CHECK (user_id = auth.uid());
  END IF;

  IF NOT EXISTS (
    SELECT FROM pg_policies WHERE tablename = 'bookings' AND policyname = 'Users can update their own bookings'
  ) THEN
    CREATE POLICY "Users can update their own bookings" ON bookings
      FOR UPDATE
      TO authenticated
      USING (user_id = auth.uid());
  END IF;
  
  IF NOT EXISTS (
    SELECT FROM pg_policies WHERE tablename = 'bookings' AND policyname = 'Allow admins full access to bookings'
  ) THEN
    CREATE POLICY "Allow admins full access to bookings" ON bookings
      FOR ALL
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END
$$;

-- Create trigger to automatically update updated_at timestamp for bookings
DROP TRIGGER IF EXISTS bookings_updated_at_trigger ON bookings;
CREATE TRIGGER bookings_updated_at_trigger
BEFORE UPDATE ON bookings
FOR EACH ROW
EXECUTE FUNCTION set_updated_at_column();

-- Sample query function to get all bookings with tour and event info
CREATE OR REPLACE FUNCTION get_bookings()
RETURNS TABLE (
  id UUID,
  user_id UUID,
  booking_reference TEXT,
  booking_date TIMESTAMPTZ,
  travel_date TIMESTAMPTZ,
  customer_name TEXT,
  customer_email TEXT,
  tour_id UUID,
  tour_title TEXT,
  event_id UUID,
  event_title TEXT,
  total_amount DECIMAL,
  status TEXT,
  payment_status TEXT,
  created_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    b.id,
    b.user_id,
    b.booking_reference,
    b.booking_date,
    b.travel_date,
    b.customer_name,
    b.customer_email,
    b.tour_id,
    t.title AS tour_title,
    b.event_id,
    e.title AS event_title,
    b.total_amount,
    b.status,
    b.payment_status,
    b.created_at,
    b.updated_at
  FROM bookings b
  LEFT JOIN tours t ON b.tour_id = t.id
  LEFT JOIN events e ON b.event_id = e.id
  WHERE 
    -- For regular users, show only their bookings
    -- For admins (or in development), show all bookings
    (b.user_id = auth.uid() OR true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;