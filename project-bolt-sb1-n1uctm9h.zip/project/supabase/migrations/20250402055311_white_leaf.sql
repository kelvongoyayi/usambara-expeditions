/*
  # Create admin logs table

  1. New Tables
    - `admin_logs`
      - `id` (uuid, primary key)
      - `admin_id` (uuid, references profiles.id)
      - `action_type` (text)
      - `table_name` (text)
      - `record_id` (text)
      - `details` (jsonb)
      - `created_at` (timestamptz)
  2. Security
    - Enable RLS on `admin_logs` table
    - Add policies for admin read access
*/

-- Create admin_logs table
CREATE TABLE IF NOT EXISTS admin_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id UUID REFERENCES profiles(id),
  action_type TEXT NOT NULL,
  table_name TEXT NOT NULL,
  record_id TEXT NOT NULL,
  details JSONB,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE admin_logs ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Admins can read logs"
  ON admin_logs
  FOR SELECT
  TO authenticated
  USING (is_admin());

-- Create function to log admin actions
CREATE OR REPLACE FUNCTION log_admin_action(
  action_type TEXT,
  table_name TEXT,
  record_id TEXT,
  details TEXT DEFAULT NULL
)
RETURNS VOID AS $$
BEGIN
  INSERT INTO admin_logs (admin_id, action_type, table_name, record_id, details)
  VALUES (
    auth.uid(),
    action_type,
    table_name,
    record_id,
    CASE WHEN details IS NULL THEN NULL ELSE details::jsonb END
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;