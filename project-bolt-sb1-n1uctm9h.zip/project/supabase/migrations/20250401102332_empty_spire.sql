/*
  # Add Itinerary Column to Tours Table

  1. Changes
    - Add itinerary column as JSONB array
    - Add validation check for itinerary structure
    
  2. Details
    - Uses JSONB type to store structured itinerary data
    - Each itinerary item contains:
      - day (integer)
      - title (string)
      - description (string)
      - activities (string array)
      - meals (string array)
      - accommodation (string)
      - distance (string, optional)
      - elevation (string, optional)
    - Includes check constraint to validate JSON structure
*/

-- Add itinerary column
ALTER TABLE tours 
ADD COLUMN IF NOT EXISTS itinerary jsonb[];

-- Add check constraint to validate itinerary structure
ALTER TABLE tours
ADD CONSTRAINT itinerary_check CHECK (
  itinerary IS NULL OR (
    jsonb_array_length(itinerary) > 0 AND
    (
      SELECT bool_and(
        jsonb_typeof(elem->>'day') = 'number' AND
        jsonb_typeof(elem->>'title') = 'string' AND
        jsonb_typeof(elem->>'description') = 'string' AND
        jsonb_typeof(elem->'activities') = 'array' AND
        jsonb_typeof(elem->'meals') = 'array' AND
        jsonb_typeof(elem->>'accommodation') = 'string'
      )
      FROM jsonb_array_elements(itinerary) elem
    )
  )
);

-- Add comment for documentation
COMMENT ON COLUMN tours.itinerary IS 'Array of daily itinerary items including activities, meals, and accommodation';