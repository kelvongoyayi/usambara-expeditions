/*
  # Fix: Make slug field allow nulls temporarily

  1. Changes
    - Modifies tours and events tables to allow slug to be NULL temporarily
    - This lets us insert new records without requiring a slug
    
  2. Purpose
    - Fix issue with current INSERT operations failing due to NOT NULL constraint
    - Later slugs will be auto-generated via triggers
*/

-- Update the tours table to allow null slugs temporarily
ALTER TABLE tours
ALTER COLUMN slug DROP NOT NULL;

-- Update the events table to allow null slugs temporarily
ALTER TABLE events
ALTER COLUMN slug DROP NOT NULL;