/*
  # Delete All Sample Tours and Events

  1. Changes
    - Removes all sample tours from the tours table
    - Removes all sample events from the events table
    - Logs the deletion actions in admin_logs
  
  2. Purpose
    - Clean up the database by removing all sample data
    - Prepare for fresh data entry
    - Maintain audit trail of the deletion
*/

-- Delete all tours
DELETE FROM tours;

-- Delete all events
DELETE FROM events;

-- Log the actions
DO $$
BEGIN
  -- Log tour deletion
  PERFORM log_admin_action(
    'delete_all',
    'tours',
    'all_tours',
    jsonb_build_object(
      'description', 'Removed all sample tours',
      'timestamp', now()
    )
  );
  
  -- Log event deletion
  PERFORM log_admin_action(
    'delete_all',
    'events',
    'all_events',
    jsonb_build_object(
      'description', 'Removed all sample events',
      'timestamp', now()
    )
  );
EXCEPTION
  WHEN others THEN
    RAISE NOTICE 'Error logging deletion: %', SQLERRM;
END
$$;