/*
  # Fix Tour Categories
  
  1. Changes
    - Create a function to check if categories exist before inserting
    - Insert sample tour categories if they don't exist already
  
  2. Rationale
    - Prevents duplicate category entries when running migrations multiple times
    - Ensures all necessary tour categories are available for tour filtering
*/

-- First create a function to check if categories exist
CREATE OR REPLACE FUNCTION category_exists(category_slug TEXT) 
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM tour_categories WHERE slug = category_slug
  );
END;
$$ LANGUAGE plpgsql;

-- Insert sample tour categories if they don't exist
DO $$ 
BEGIN
  -- Hiking category
  IF NOT category_exists('hiking') THEN
    INSERT INTO tour_categories (id, name, slug, description, icon)
    VALUES (
      gen_random_uuid(),
      'Hiking',
      'hiking',
      'Explore the breathtaking landscapes of Tanzania on foot with our guided hiking tours.',
      'mountain'
    );
  END IF;

  -- Cycling category
  IF NOT category_exists('cycling') THEN
    INSERT INTO tour_categories (id, name, slug, description, icon)
    VALUES (
      gen_random_uuid(),
      'Cycling',
      'cycling',
      'Experience Tanzania on two wheels with our guided cycling adventures through diverse terrains.',
      'bike'
    );
  END IF;

  -- Cultural category
  IF NOT category_exists('cultural') THEN
    INSERT INTO tour_categories (id, name, slug, description, icon)
    VALUES (
      gen_random_uuid(),
      'Cultural',
      'cultural',
      'Immerse yourself in the rich cultural heritage of Tanzania with our village and community experiences.',
      'users'
    );
  END IF;

  -- 4x4 Expedition category
  IF NOT category_exists('4x4') THEN
    INSERT INTO tour_categories (id, name, slug, description, icon)
    VALUES (
      gen_random_uuid(),
      '4x4 Expedition',
      '4x4',
      'Venture off the beaten path with our 4x4 expeditions through Tanzania''s rugged landscapes.',
      'truck'
    );
  END IF;

  -- Motocamping category
  IF NOT category_exists('motocamping') THEN
    INSERT INTO tour_categories (id, name, slug, description, icon)
    VALUES (
      gen_random_uuid(),
      'Motocamping',
      'motocamping',
      'Explore Tanzania on motorcycles with our guided motocamping adventures, combining riding and camping.',
      'bike'
    );
  END IF;

  -- School Tours category
  IF NOT category_exists('school') THEN
    INSERT INTO tour_categories (id, name, slug, description, icon)
    VALUES (
      gen_random_uuid(),
      'School Tours',
      'school',
      'Educational tours designed specifically for school groups, combining learning with adventure.',
      'school'
    );
  END IF;
END $$;