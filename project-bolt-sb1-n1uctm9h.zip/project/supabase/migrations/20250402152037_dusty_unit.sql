/*
  # Add Connection Check Function

  1. New Functions
    - `check_database_connection` - Verifies database connectivity
    - `get_database_stats` - Returns statistics about database tables
    - `verify_sample_data` - Checks if sample data exists and is accessible

  2. Benefits
    - Provides easy way to verify database connection
    - Helps diagnose issues with sample data
    - Gives overview of database state
*/

-- Function to check database connection
CREATE OR REPLACE FUNCTION check_database_connection()
RETURNS JSONB AS $$
DECLARE
  result JSONB;
BEGIN
  SELECT jsonb_build_object(
    'connected', true,
    'timestamp', now(),
    'database_version', current_setting('server_version')
  ) INTO result;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get database statistics
CREATE OR REPLACE FUNCTION get_database_stats()
RETURNS JSONB AS $$
DECLARE
  result JSONB;
BEGIN
  SELECT jsonb_build_object(
    'tours_count', (SELECT COUNT(*) FROM tours),
    'events_count', (SELECT COUNT(*) FROM events),
    'bookings_count', (SELECT COUNT(*) FROM bookings),
    'profiles_count', (SELECT COUNT(*) FROM profiles),
    'tour_categories_count', (SELECT COUNT(*) FROM tour_categories),
    'event_types_count', (SELECT COUNT(*) FROM event_types),
    'admin_logs_count', (SELECT COUNT(*) FROM admin_logs),
    'tables', (
      SELECT jsonb_agg(jsonb_build_object(
        'table_name', table_name,
        'row_count', (SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public' AND table_name = t.table_name)
      ))
      FROM (
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_type = 'BASE TABLE'
        ORDER BY table_name
      ) t
    )
  ) INTO result;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to verify sample data exists
CREATE OR REPLACE FUNCTION verify_sample_data()
RETURNS JSONB AS $$
DECLARE
  result JSONB;
  tour_categories_exist BOOLEAN;
  event_types_exist BOOLEAN;
  sample_tours_exist BOOLEAN;
  sample_events_exist BOOLEAN;
BEGIN
  -- Check if tour categories exist
  SELECT EXISTS (SELECT 1 FROM tour_categories LIMIT 1) INTO tour_categories_exist;
  
  -- Check if event types exist
  SELECT EXISTS (SELECT 1 FROM event_types LIMIT 1) INTO event_types_exist;
  
  -- Check if sample tours exist
  SELECT EXISTS (SELECT 1 FROM tours LIMIT 1) INTO sample_tours_exist;
  
  -- Check if sample events exist
  SELECT EXISTS (SELECT 1 FROM events LIMIT 1) INTO sample_events_exist;
  
  -- Build result
  SELECT jsonb_build_object(
    'tour_categories_exist', tour_categories_exist,
    'event_types_exist', event_types_exist,
    'sample_tours_exist', sample_tours_exist,
    'sample_events_exist', sample_events_exist,
    'tour_categories', (
      SELECT jsonb_agg(jsonb_build_object('id', id, 'name', name))
      FROM tour_categories
      LIMIT 10
    ),
    'event_types', (
      SELECT jsonb_agg(jsonb_build_object('id', id, 'name', name))
      FROM event_types
      LIMIT 10
    ),
    'sample_tours', (
      SELECT jsonb_agg(jsonb_build_object('id', id, 'title', title))
      FROM tours
      LIMIT 5
    ),
    'sample_events', (
      SELECT jsonb_agg(jsonb_build_object('id', id, 'title', title))
      FROM events
      LIMIT 5
    )
  ) INTO result;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;