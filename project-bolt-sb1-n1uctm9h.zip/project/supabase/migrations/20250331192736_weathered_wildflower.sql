/*
  # Admin Helper Functions

  1. New Functions
    - check_admin_access() - Verify admin access for operations
    - log_admin_action() - Log admin actions for auditing
    - get_admin_stats() - Get dashboard statistics
*/

-- Function to check admin access
CREATE OR REPLACE FUNCTION check_admin_access()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid()
    AND is_admin = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to log admin actions
CREATE OR REPLACE FUNCTION log_admin_action(
  action_type TEXT,
  table_name TEXT,
  record_id UUID,
  details JSONB DEFAULT NULL
) RETURNS VOID AS $$
BEGIN
  INSERT INTO admin_logs (
    admin_id,
    action_type,
    table_name,
    record_id,
    details
  ) VALUES (
    auth.uid(),
    action_type,
    table_name,
    record_id,
    details
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get admin dashboard stats
CREATE OR REPLACE FUNCTION get_admin_stats()
RETURNS JSONB AS $$
DECLARE
  result JSONB;
BEGIN
  SELECT jsonb_build_object(
    'total_tours', (SELECT COUNT(*) FROM tours),
    'total_events', (SELECT COUNT(*) FROM events),
    'total_bookings', (SELECT COUNT(*) FROM bookings),
    'total_users', (SELECT COUNT(*) FROM profiles),
    'recent_bookings', (
      SELECT jsonb_agg(b.*)
      FROM bookings b
      ORDER BY b.created_at DESC
      LIMIT 5
    ),
    'popular_tours', (
      SELECT jsonb_agg(t.*)
      FROM tours t
      LEFT JOIN bookings b ON b.tour_id = t.id
      GROUP BY t.id
      ORDER BY COUNT(b.id) DESC
      LIMIT 5
    )
  ) INTO result;

  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create admin logs table
CREATE TABLE IF NOT EXISTS admin_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id UUID REFERENCES auth.users(id),
  action_type TEXT NOT NULL,
  table_name TEXT NOT NULL,
  record_id UUID NOT NULL,
  details JSONB,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS on admin_logs
ALTER TABLE admin_logs ENABLE ROW LEVEL SECURITY;

-- Only admins can read logs
CREATE POLICY "Admins can read logs"
  ON admin_logs
  FOR SELECT
  TO authenticated
  USING (check_admin_access());