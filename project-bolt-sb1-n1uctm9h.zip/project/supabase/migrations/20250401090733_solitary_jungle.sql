/*
  # Fix get_admin_stats function

  1. Updates
    - Fix the SQL GROUP BY error in get_admin_stats function
    - Properly handle columns in the recent_bookings and popular_tours queries
  2. Changes
    - Replace existing function with corrected version that explicitly selects columns
*/

-- Drop existing function if it exists
DROP FUNCTION IF EXISTS get_admin_stats();

-- Create updated function with fixed query
CREATE OR REPLACE FUNCTION get_admin_stats()
RETURNS JSONB AS $$
DECLARE
  result JSONB;
BEGIN
  SELECT jsonb_build_object(
    'total_tours', (SELECT COUNT(*) FROM tours),
    'total_events', (SELECT COUNT(*) FROM events),
    'total_bookings', (SELECT COUNT(*) FROM bookings),
    'total_users', (SELECT COUNT(*) FROM profiles),
    'recent_bookings', (
      SELECT jsonb_agg(row_to_json(b))
      FROM (
        SELECT id, user_id, booking_reference, booking_date, customer_name, customer_email, tour_id, event_id, total_amount, status, payment_status, created_at, updated_at
        FROM bookings
        ORDER BY created_at DESC
        LIMIT 5
      ) b
    ),
    'popular_tours', (
      SELECT jsonb_agg(row_to_json(t))
      FROM (
        SELECT t.id, t.title, t.duration, t.price, t.location, t.image_url, t.rating, t.description, t.category, t.featured
        FROM tours t
        LEFT JOIN bookings b ON b.tour_id = t.id
        GROUP BY t.id, t.title, t.duration, t.price, t.location, t.image_url, t.rating, t.description, t.category, t.featured
        ORDER BY COUNT(b.id) DESC
        LIMIT 5
      ) t
    )
  ) INTO result;

  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;