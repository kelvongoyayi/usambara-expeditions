/*
  # Create events table

  1. New Tables
    - `events`
      - `id` (uuid, primary key)
      - `title` (text)
      - `slug` (text, unique)
      - `event_type` (text)
      - `description` (text)
      - `start_date` (timestamptz)
      - `end_date` (timestamptz)
      - `location` (text)
      - `image_url` (text)
      - `price` (numeric)
      - `rating` (numeric)
      - `duration` (text)
      - `featured` (boolean)
      - `min_attendees` (integer)
      - `max_attendees` (integer)
      - `highlights` (text array)
      - `included` (text array)
      - `excluded` (text array)
      - `gallery` (text array)
      - `itinerary` (jsonb)
      - `faqs` (jsonb)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
  2. Security
    - Enable RLS on `events` table
    - Add policies for public read access
    - Add policies for admin write access
*/

-- Create events table
CREATE TABLE IF NOT EXISTS events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  event_type TEXT NOT NULL,
  description TEXT NOT NULL,
  start_date TIMESTAMPTZ NOT NULL,
  end_date TIMESTAMPTZ NOT NULL,
  location TEXT NOT NULL,
  image_url TEXT NOT NULL,
  price NUMERIC NOT NULL,
  rating NUMERIC DEFAULT 4.5,
  duration TEXT NOT NULL,
  featured BOOLEAN DEFAULT false,
  min_attendees INTEGER,
  max_attendees INTEGER,
  highlights TEXT[],
  included TEXT[],
  excluded TEXT[],
  gallery TEXT[],
  itinerary JSONB,
  faqs JSONB,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE events ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Public read access for events"
  ON events
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Admin insert access for events"
  ON events
  FOR INSERT
  TO authenticated
  WITH CHECK (is_admin());

CREATE POLICY "Admin update access for events"
  ON events
  FOR UPDATE
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admin delete access for events"
  ON events
  FOR DELETE
  TO authenticated
  USING (is_admin());