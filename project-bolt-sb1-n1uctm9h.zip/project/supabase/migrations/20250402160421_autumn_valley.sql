/*
  # Fix RLS Policies for Profiles Table

  1. Changes
    - Drop all existing policies on profiles table
    - Create new policies with unique names to avoid conflicts
    - Fix is_admin function to avoid recursion
    
  2. Security
    - Maintain proper access control
    - Ensure users can only access their own data
    - Allow admins to access all profiles
*/

-- First drop all existing policies on profiles table
DO $$ 
BEGIN
  -- Get all policy names for the profiles table
  FOR policy_name IN 
    SELECT policyname FROM pg_policies WHERE tablename = 'profiles'
  LOOP
    -- Drop each policy
    EXECUTE format('DROP POLICY IF EXISTS %I ON profiles', policy_name);
  END LOOP;
END $$;

-- Make sure RLS is enabled
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Create a public read access policy for profiles
CREATE POLICY "profiles_read_public_20250402"
ON profiles
FOR SELECT
TO public
USING (true);

-- Create a policy for users to update their own profile
CREATE POLICY "profiles_update_own_20250402"
ON profiles
FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- Create a policy for admins to update all profiles
CREATE POLICY "profiles_admin_update_20250402"
ON profiles
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND is_admin = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND is_admin = true
  )
);

-- Create a policy for admins to delete profiles
CREATE POLICY "profiles_admin_delete_20250402"
ON profiles
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND is_admin = true
  )
);

-- Create a safe is_admin function that avoids recursion
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
DECLARE
  is_admin_user BOOLEAN;
BEGIN
  -- Direct query to avoid recursion
  SELECT p.is_admin INTO is_admin_user
  FROM profiles p
  WHERE p.id = auth.uid();
  
  -- Return result (or false if no result)
  RETURN COALESCE(is_admin_user, FALSE);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a function to check database connection
CREATE OR REPLACE FUNCTION check_database_connection()
RETURNS JSONB AS $$
DECLARE
  result JSONB;
BEGIN
  SELECT jsonb_build_object(
    'connected', true,
    'timestamp', now(),
    'database_version', current_setting('server_version')
  ) INTO result;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;