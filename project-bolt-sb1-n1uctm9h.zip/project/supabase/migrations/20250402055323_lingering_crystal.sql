/*
  # Create exec_sql function

  1. New Functions
    - `exec_sql`
      - Allows executing arbitrary SQL for migrations
      - Only accessible to admins
*/

-- Create function to execute SQL (for migrations)
CREATE OR REPLACE FUNCTION exec_sql(sql_query TEXT)
RETURNS VOID AS $$
BEGIN
  -- Only allow admins to execute SQL
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Access denied: User is not an admin';
  END IF;

  EXECUTE sql_query;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;