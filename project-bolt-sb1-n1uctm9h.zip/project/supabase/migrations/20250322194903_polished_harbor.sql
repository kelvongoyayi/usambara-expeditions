/*
  # Admin Profiles Setup and Security

  1. Changes
    - Create admin_users table to track admin status
    - Add RLS policies for admin access
    - Add functions for admin checks and management
    - Fix profile policies to work with admin status

  2. Security
    - Enable RLS on all tables
    - Add policies for admin access
    - Add policies for user access
    - Ensure proper data isolation
*/

-- Create admin_users table if it doesn't exist
CREATE TABLE IF NOT EXISTS admin_users (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Create admin check function
CREATE OR REPLACE FUNCTION is_admin(user_id uuid)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM admin_users WHERE user_id = $1
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create current user admin check function
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM admin_users WHERE user_id = auth.uid()
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to make a user an admin
CREATE OR REPLACE FUNCTION make_admin(target_user_id uuid)
RETURNS BOOLEAN AS $$
BEGIN
  -- Check if the current user is an admin
  IF NOT is_admin() THEN
    RETURN false;
  END IF;

  -- Add user to admin_users if not already there
  INSERT INTO admin_users (user_id)
  VALUES (target_user_id)
  ON CONFLICT (user_id) DO NOTHING;

  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Admin users policies
CREATE POLICY "Admins can view all admin users"
  ON admin_users
  FOR SELECT
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admins can insert admin users"
  ON admin_users
  FOR INSERT
  TO authenticated
  WITH CHECK (is_admin());

CREATE POLICY "Admins can update admin users"
  ON admin_users
  FOR UPDATE
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admins can delete admin users"
  ON admin_users
  FOR DELETE
  TO authenticated
  USING (is_admin());

-- Update profiles policies
DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Users can insert their own profile" ON profiles;

-- Allow users to view their own profile or admins to view all profiles
CREATE POLICY "Users can view own profile or admins can view all"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = id OR is_admin()
  );

-- Allow users to update their own profile or admins to update any profile
CREATE POLICY "Users can update own profile or admins can update any"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = id OR is_admin()
  );

-- Allow users to insert their own profile
CREATE POLICY "Users can insert their own profile"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Create first admin function
CREATE OR REPLACE FUNCTION create_first_admin(admin_email text)
RETURNS BOOLEAN AS $$
DECLARE
  admin_user_id uuid;
BEGIN
  -- Check if any admins exist
  IF EXISTS (SELECT 1 FROM admin_users) THEN
    RETURN false;
  END IF;

  -- Get user id from auth.users
  SELECT id INTO admin_user_id
  FROM auth.users
  WHERE email = admin_email;

  IF admin_user_id IS NULL THEN
    RETURN false;
  END IF;

  -- Make user an admin
  INSERT INTO admin_users (user_id)
  VALUES (admin_user_id);

  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;