/*
  # Create admin_logs table

  1. New Tables
    - `admin_logs`
      - `id` (uuid, primary key)
      - `user_id` (uuid)
      - `action_type` (text)
      - `table_name` (text)
      - `record_id` (text)
      - `details` (jsonb)
      - `created_at` (timestamp with timezone, default: now())

  2. Security
    - Enable RLS on `admin_logs` table
    - Add policies for authenticated users
*/

CREATE TABLE IF NOT EXISTS admin_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) DEFAULT auth.uid(),
  action_type text NOT NULL,
  table_name text NOT NULL,
  record_id text NOT NULL,
  details jsonb,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE admin_logs ENABLE ROW LEVEL SECURITY;

-- Policy for reading logs (admins only)
CREATE POLICY "Admins can read all logs" 
  ON admin_logs
  FOR SELECT 
  TO authenticated
  USING (true); -- For development, allow all authenticated users

-- Policy for inserting logs (authenticated users)
CREATE POLICY "Authenticated users can log their actions" 
  ON admin_logs
  FOR INSERT 
  TO authenticated
  WITH CHECK (true);