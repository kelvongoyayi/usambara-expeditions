/*
  # Sample Tours Data
  
  1. New Data
    - Adds sample tours with complete details including descriptions, images, and itineraries
    
  2. Purpose
    - Provides initial data for the tours section of the website
    - Includes various tour categories and complete tour details
*/

-- Insert sample tours
INSERT INTO tours (
  id, title, duration, price, location, image_url, rating, description, category,
  difficulty, min_group_size, max_group_size, highlights,
  requirements, included, excluded, 
  itinerary, faqs, gallery, featured
) VALUES (
  gen_random_uuid(),
  'Usambara Mountains Hiking Adventure',
  '3 days',
  299,
  'Usambara Mountains',
  'https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
  4.8,
  'Explore the lush rainforests and panoramic viewpoints of the Usambara Mountains on this immersive 3-day guided trek. Walk through indigenous forests, visit traditional villages, and experience Tanzania''s "Galapagos" of biodiversity.',
  'hiking',
  'moderate',
  4,
  12,
  ARRAY[
    'Panoramic views of the Usambara Mountains',
    'Traditional village visits and cultural experiences',
    'Diverse flora and fauna in the rainforest ecosystem',
    'Professional local guides with expert knowledge'
  ],
  ARRAY[
    'Moderate fitness level required for daily hikes',
    'Comfortable hiking shoes or boots',
    'Weather-appropriate clothing (including rain gear)',
    'Personal medications and toiletries'
  ],
  ARRAY[
    'Professional hiking guide',
    'All meals during the trek',
    'Accommodation in mountain lodges',
    'Entrance fees to protected areas',
    'Local community fees'
  ],
  ARRAY[
    'International flights',
    'Personal travel insurance',
    'Additional snacks and beverages',
    'Tips for guides and porters',
    'Personal hiking equipment'
  ],
  '[
    {
      "day": 1,
      "title": "Arrival and Forest Trek",
      "description": "Begin your adventure with a trek through the lush rainforest of the Usambara Mountains. Follow ancient trails used by local communities for generations as you climb through diverse vegetation zones.",
      "activities": ["Morning briefing and equipment check", "Forest trek through indigenous trees", "Lunch at a scenic viewpoint", "Afternoon hike to the lodge"],
      "meals": ["lunch", "dinner"],
      "accommodation": "Muller Mountain Lodge",
      "distance": "8 km",
      "elevation": "400m gain"
    },
    {
      "day": 2,
      "title": "Village Visit and Ridge Hike",
      "description": "Experience local culture with visits to traditional villages and farms. Hike along ridges offering spectacular views of the surrounding mountains and valleys.",
      "activities": ["Morning ridge hike", "Traditional village visit", "Local market exploration", "Sunset viewpoint trek"],
      "meals": ["breakfast", "lunch", "dinner"],
      "accommodation": "Irente Farm Lodge",
      "distance": "12 km",
      "elevation": "300m gain, 200m loss"
    },
    {
      "day": 3,
      "title": "Panoramic Viewpoints and Departure",
      "description": "Summit one of the highest accessible peaks in the Usambaras for breathtaking panoramic views. After lunch, begin your descent and journey back with unforgettable memories.",
      "activities": ["Summit hike to panoramic viewpoint", "Picnic lunch at the peak", "Descent through valley trail", "Farewell ceremony with guides"],
      "meals": ["breakfast", "lunch"],
      "accommodation": "",
      "distance": "9 km",
      "elevation": "350m gain, 650m loss"
    }
  ]'::jsonb,
  '[
    {
      "question": "What is the best time of year for this trek?",
      "answer": "The dry seasons from June to October and December to February offer the best hiking conditions with clear views and minimal rainfall."
    },
    {
      "question": "How difficult is the hiking?",
      "answer": "This trek is rated as moderate difficulty. Participants should be able to hike 5-7 hours per day over varied terrain with moderate elevation changes."
    },
    {
      "question": "What type of accommodation can I expect?",
      "answer": "Accommodation is in comfortable mountain lodges with basic amenities. Rooms are typically shared with 2-4 people per room, and hot showers may be limited."
    },
    {
      "question": "Is it possible to customize this tour?",
      "answer": "Yes, we can customize aspects of this tour to accommodate different fitness levels, interests, or time constraints. Please contact us for personalized options."
    }
  ]'::jsonb,
  ARRAY[
    'https://images.unsplash.com/photo-1533468949404-6535e305c077?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2066&q=80',
    'https://images.unsplash.com/photo-1532274402911-5a369e4c4bb5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    'https://images.unsplash.com/photo-1669123547602-c539b8d93a4a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
  ],
  true
),
(
  gen_random_uuid(),
  'Cycling Through Tea Plantations',
  '1 day',
  89,
  'Amani Nature Reserve',
  'https://images.unsplash.com/photo-1591184510259-b6f1be3d7aff?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80',
  4.7,
  'Experience the beauty of the Usambara tea plantations on this guided cycling tour. Wind your way through verdant tea fields, enjoy stunning mountain views, and connect with the rich agricultural heritage of the region.',
  'cycling',
  'easy',
  2,
  10,
  ARRAY[
    'Cycle through lush tea plantations with mountain backdrops',
    'Visit a tea processing facility and learn about production',
    'Experience local hospitality with a farm-to-table lunch',
    'Support sustainable tourism practices'
  ],
  ARRAY[
    'Basic cycling ability required',
    'Comfortable clothes suitable for cycling',
    'Sunscreen and hat',
    'Water bottle'
  ],
  ARRAY[
    'Professional cycling guide',
    'Mountain bike rental and helmet',
    'Tea plantation tour',
    'Lunch and refreshments',
    'Water and snacks'
  ],
  ARRAY[
    'Transportation to starting point',
    'Personal travel insurance',
    'Additional beverages',
    'Gratuities for guides'
  ],
  '[
    {
      "day": 1,
      "title": "Tea Plantation Cycling Tour",
      "description": "Embark on a full-day cycling adventure through the picturesque tea plantations of the Usambara Mountains. Enjoy moderate cycling on mixed terrain with frequent stops for photos, refreshments, and cultural interactions.",
      "activities": [
        "Morning briefing and bike fitting",
        "Cycle through tea plantations with scenic stops",
        "Tea factory visit and production demonstration",
        "Farm-to-table lunch at a local homestead",
        "Afternoon cycling loop with mountain views",
        "Return to starting point for farewell refreshments"
      ],
      "meals": ["lunch"],
      "accommodation": "",
      "distance": "25 km",
      "elevation": "200m gain and loss"
    }
  ]'::jsonb,
  '[
    {
      "question": "Is this tour suitable for beginners?",
      "answer": "Yes, this tour is designed for cyclists of all experience levels. The pace is relaxed with frequent stops, and the terrain is mostly gentle with a few moderate hills."
    },
    {
      "question": "What kind of bikes do you provide?",
      "answer": "We provide quality mountain bikes with front suspension that are suitable for the terrain. Bikes come in various sizes to ensure a comfortable fit."
    },
    {
      "question": "What should I wear?",
      "answer": "Comfortable athletic clothing, closed-toe shoes, and sun protection are recommended. Avoid very loose pants that might get caught in the bike chain."
    }
  ]'::jsonb,
  ARRAY[
    'https://images.unsplash.com/photo-1588714477688-cf28a50e8abe?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2069&q=80',
    'https://images.unsplash.com/photo-1621857426350-ddab819cf0ce?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2071&q=80'
  ],
  true
),
(
  gen_random_uuid(),
  'Cultural Village Experience',
  '2 days',
  199,
  'Lushoto',
  'https://images.unsplash.com/photo-1567942089878-d844f4561d57?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
  4.9,
  'Immerse yourself in the rich cultural heritage of the Usambara Mountains with this 2-day village experience. Stay with local families, learn traditional crafts and cooking, and participate in community activities while supporting sustainable tourism.',
  'cultural',
  'easy',
  2,
  8,
  ARRAY[
    'Authentic homestay with local families',
    'Traditional cooking classes using local ingredients',
    'Cultural performances and storytelling sessions',
    'Handicraft workshops with local artisans',
    'Sustainable community tourism initiative'
  ],
  ARRAY[
    'Openness to cultural experiences',
    'Respect for local customs and traditions',
    'Willingness to try new foods and activities',
    'Basic overnight items and toiletries'
  ],
  ARRAY[
    'Village homestay accommodation',
    'All meals prepared with local families',
    'Cultural activity participation',
    'Local guide and translator',
    'Community contribution fee'
  ],
  ARRAY[
    'Transportation to village',
    'Personal travel insurance',
    'Alcoholic beverages',
    'Personal souvenirs and crafts'
  ],
  '[
    {
      "day": 1,
      "title": "Village Welcome and Cultural Immersion",
      "description": "Begin your cultural journey with a traditional welcome ceremony followed by integration into daily village life. Learn about local customs, participate in household activities, and enjoy authentic cultural exchanges.",
      "activities": [
        "Traditional welcome ceremony with local elders",
        "Village tour and introduction to host family",
        "Participation in seasonal agricultural activities",
        "Afternoon handicraft workshop",
        "Evening cultural performances and storytelling"
      ],
      "meals": ["lunch", "dinner"],
      "accommodation": "Family Homestay"
    },
    {
      "day": 2,
      "title": "Traditional Skills and Farewell",
      "description": "Deepen your cultural experience by learning traditional cooking methods and medicinal plant knowledge. Participate in community projects before a heartfelt farewell ceremony.",
      "activities": [
        "Morning traditional cooking class",
        "Medicinal plant walk with local healer",
        "Community development project participation",
        "Shared lunch with host families",
        "Farewell ceremony and cultural exchange"
      ],
      "meals": ["breakfast", "lunch"],
      "accommodation": ""
    }
  ]'::jsonb,
  '[
    {
      "question": "What are the sleeping arrangements in the homestay?",
      "answer": "Accommodations are simple but comfortable, typically with private rooms in family homes. Bathroom facilities are usually shared, and amenities are basic but clean."
    },
    {
      "question": "What kind of food will be served?",
      "answer": "Meals are authentic Tanzanian cuisine prepared by your host family, typically including dishes like ugali (maize porridge), rice, beans, vegetables, and occasionally meat or fish. Special dietary requirements can usually be accommodated with advance notice."
    },
    {
      "question": "Is there electricity and running water?",
      "answer": "Most villages have limited electricity (sometimes solar-powered) and basic running water. Expect simple conditions that reflect authentic rural life in Tanzania."
    },
    {
      "question": "How does this tour benefit the local community?",
      "answer": "Host families receive fair compensation for accommodations and meals. Additionally, a portion of your tour fee goes directly to community development projects chosen by village leadership."
    }
  ]'::jsonb,
  ARRAY[
    'https://images.unsplash.com/photo-1541411438265-4cb4687110f2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1964&q=80',
    'https://images.unsplash.com/photo-1489493512598-d08130f49bea?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2071&q=80',
    'https://images.unsplash.com/photo-1605192554106-d549b1b975ff?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
  ],
  false
),
(
  gen_random_uuid(),
  '4x4 Mountain Expedition',
  '4 days',
  549,
  'Usambara Range',
  'https://images.unsplash.com/photo-1504173010664-32509aeebb62?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80',
  4.9,
  'Experience the thrill of off-road driving through the rugged terrain of the Usambara Mountains in our specially equipped 4x4 vehicles. This expedition combines adventure driving with stunning landscapes, wildlife viewing, and camping under the stars.',
  '4x4',
  'moderate',
  4,
  16,
  ARRAY[
    'Off-road 4x4 driving through diverse mountain terrain',
    'Camping at exclusive wilderness sites with spectacular views',
    'Wildlife spotting in remote forest areas',
    'River crossings and challenging mountain passes',
    'Professional driving guides and mechanics'
  ],
  ARRAY[
    'Previous 4x4 driving experience recommended',
    'Valid driving license for participants who wish to drive',
    'Comfortable outdoor clothing and sturdy footwear',
    'Personal camping items (sleeping bag, pillow)',
    'Willingness to participate in camp setup and activities'
  ],
  ARRAY[
    'Fully equipped 4x4 vehicles',
    'Camping equipment (tents, mattresses, camp chairs)',
    'All meals and non-alcoholic beverages',
    'Professional expedition leader and support crew',
    'Emergency satellite communication',
    'Wildlife and nature guides'
  ],
  ARRAY[
    'Personal travel insurance',
    'Alcoholic beverages',
    'Personal camping accessories (sleeping bags, pillows)',
    'Gratuities for guides and crew'
  ],
  '[
    {
      "day": 1,
      "title": "Expedition Briefing and First Camp",
      "description": "Meet your expedition team, receive a comprehensive briefing on 4x4 techniques, and begin your adventure with an introductory off-road section to our first spectacular campsite.",
      "activities": [
        "Morning briefing and vehicle familiarization",
        "Basic off-road driving instruction",
        "First off-road track through forest and hills",
        "Evening camp setup and welcome dinner",
        "Night sky observation session"
      ],
      "meals": ["lunch", "dinner"],
      "accommodation": "Wilderness Camp - Forest Edge",
      "distance": "45 km off-road"
    },
    {
      "day": 2,
      "title": "Mountain Passes and River Valleys",
      "description": "Challenge yourself with more technical driving as we navigate mountain passes, river crossings, and steep terrain to reach our exclusive river valley campsite.",
      "activities": [
        "Technical driving through mountain passes",
        "River crossing techniques and practice",
        "Wildlife spotting throughout the journey",
        "Afternoon hike from camp to nearby waterfall",
        "Evening campfire stories and experiences"
      ],
      "meals": ["breakfast", "lunch", "dinner"],
      "accommodation": "Wilderness Camp - River Valley",
      "distance": "60 km off-road"
    },
    {
      "day": 3,
      "title": "Remote Plateaus and Villages",
      "description": "Venture into more remote regions, accessing high plateaus with breathtaking views and visiting isolated villages rarely seen by outsiders.",
      "activities": [
        "Technical ascent to mountain plateau",
        "Panoramic photography opportunities",
        "Visit to remote village and cultural exchange",
        "Challenging descent tracks",
        "Evening stargazing and night sounds"
      ],
      "meals": ["breakfast", "lunch", "dinner"],
      "accommodation": "Wilderness Camp - Mountain Plateau",
      "distance": "55 km off-road"
    },
    {
      "day": 4,
      "title": "Final Challenge and Return",
      "description": "Face the expedition\"s most challenging terrain before descending through changing landscapes back to civilization, with a final celebration lunch.",
      "activities": [
        "Early morning wildlife drive",
        "Technical descent section - optional challenge route",
        "Final river crossing and forest tracks",
        "Return to base camp",
        "Celebration lunch and expedition certificates"
      ],
      "meals": ["breakfast", "lunch"],
      "accommodation": "",
      "distance": "70 km off-road"
    }
  ]'::jsonb,
  '[
    {
      "question": "Do I need previous 4x4 driving experience?",
      "answer": "While previous experience is beneficial, it\"s not mandatory. Our expert guides provide thorough instruction and can take over driving on more technical sections if needed. Participants who wish to drive must have a valid driving license."
    },
    {
      "question": "What type of vehicles are used?",
      "answer": "We use well-maintained Toyota Land Cruisers or similar 4x4 vehicles, specially equipped for expedition use with enhanced suspension, recovery equipment, and satellite communication."
    },
    {
      "question": "How comfortable is the camping?",
      "answer": "We provide spacious expedition tents, thick camping mattresses, and camp chairs. Camps include a dining area, basic washing facilities, and chemical toilets. This is comfortable wilderness camping, not luxury glamping."
    },
    {
      "question": "What happens in case of vehicle breakdown or emergency?",
      "answer": "Our team includes experienced mechanics who can handle most repairs in the field. All vehicles carry extensive spare parts and tools. We maintain satellite communication for emergencies and have comprehensive evacuation protocols."
    }
  ]'::jsonb,
  ARRAY[
    'https://images.unsplash.com/photo-1621335223658-0ebd89004d51?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80',
    'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    'https://images.unsplash.com/photo-1626513755327-9a8cb7f00e7c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2123&q=80'
  ],
  false
),
(
  gen_random_uuid(),
  'School Educational Tour',
  '3 days',
  149,
  'Usambara Mountains',
  'https://images.unsplash.com/photo-1544531585-9847b68c8c86?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
  4.8,
  'A specially designed educational experience for school groups that combines learning and adventure in the Usambara Mountains. Students will engage with environmental conservation, local culture, and team-building activities in a safe and enriching environment.',
  'school',
  'easy',
  15,
  40,
  ARRAY[
    'Curriculum-aligned educational activities',
    'Hands-on conservation projects',
    'Cultural exchange with local schools',
    'Team-building adventures and challenges',
    'Safe and controlled environment with experienced youth educators'
  ],
  ARRAY[
    'School group with appropriate supervision ratio',
    'Parental consent forms',
    'Basic health and fitness for light activities',
    'Appropriate clothing for outdoor activities'
  ],
  ARRAY[
    'All accommodation in student-friendly facilities',
    'All meals and safe drinking water',
    'Educational materials and activity equipment',
    'Experienced education guides and facilitators',
    'First aid and safety equipment',
    'Activity certifications'
  ],
  ARRAY[
    'Transportation to starting point',
    'Personal items and toiletries',
    'Additional snacks or specialty food items',
    'Optional craft purchases or souvenirs'
  ],
  '[
    {
      "day": 1,
      "title": "Arrival and Environmental Education",
      "description": "Begin the educational journey with team-building activities and an introduction to the unique ecology of the Usambara Mountains, followed by hands-on conservation activities.",
      "activities": [
        "Morning arrival and welcome briefing",
        "Ice-breaker activities and team formation",
        "Interactive session on Usambara biodiversity",
        "Hands-on tree nursery project",
        "Evening reflection and journal activities"
      ],
      "meals": ["lunch", "dinner"],
      "accommodation": "Education Center Dormitories",
      "distance": "Light walking only"
    },
    {
      "day": 2,
      "title": "Cultural Exchange and Local Community",
      "description": "Experience meaningful cultural exchange through visits to local schools and communities, participating in joint activities that foster understanding and friendship.",
      "activities": [
        "Visit to local school with joint activities",
        "Traditional crafts workshop with local artisans",
        "Shared lunch with school students",
        "Community service project (water system, garden, etc.)",
        "Evening cultural performance and exchange"
      ],
      "meals": ["breakfast", "lunch", "dinner"],
      "accommodation": "Education Center Dormitories",
      "distance": "3-4 km walking between activities"
    },
    {
      "day": 3,
      "title": "Adventure Learning and Departure",
      "description": "Engage in adventure-based learning activities that challenge students physically and mentally while reinforcing environmental and cultural lessons before departure.",
      "activities": [
        "Team challenge course activities",
        "Environmental treasure hunt",
        "Low-impact wilderness skills session",
        "Reflection ceremony and certificate presentation",
        "Departure and farewell"
      ],
      "meals": ["breakfast", "lunch"],
      "accommodation": "",
      "distance": "2-3 km of light hiking"
    }
  ]'::jsonb,
  '[
    {
      "question": "Is this tour suitable for all school age groups?",
      "answer": "This tour is most suitable for students aged 10-18 (grades 5-12). Activities are adapted to be age-appropriate based on your specific group. Special programs for younger children can be arranged with additional modifications."
    },
    {
      "question": "What is the required teacher to student ratio?",
      "answer": "We recommend a minimum ratio of 1 adult to 10 students. Our education guides complement but do not replace school chaperones and teachers."
    },
    {
      "question": "How are dietary restrictions handled?",
      "answer": "We can accommodate most common dietary restrictions including vegetarian, vegan, and most allergies with advance notice. All meals are prepared with attention to food safety and nutritional needs of growing students."
    },
    {
      "question": "What safety measures are in place?",
      "answer": "Our education centers maintain strict safety protocols including 24/7 security, staff trained in first aid and child protection, clear emergency procedures, and regular safety equipment checks. We maintain communication with emergency services at all times."
    }
  ]'::jsonb,
  ARRAY[
    'https://images.unsplash.com/photo-1526976668912-1a811878dd37?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    'https://images.unsplash.com/photo-1504173010664-32509aeebb62?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80',
    'https://images.unsplash.com/photo-1588075592446-265bad68d2b6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2072&q=80'
  ],
  false
);