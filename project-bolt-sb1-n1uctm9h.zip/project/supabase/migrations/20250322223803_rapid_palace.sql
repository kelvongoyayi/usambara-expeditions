/*
# Fix Infinite Recursion in Row Level Security Policies

1. Changes
   - Fix infinite recursion in profiles RLS policies
   - Update bookings table policies to use non-recursive checks
   - Drop problematic policies and recreate them with proper conditions

2. Security
   - Maintain proper access control without recursion
   - Ensure users can only access their own data
*/

-- First drop any problematic policies that might be causing recursion
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Users can read own profile" ON profiles;
DROP POLICY IF EXISTS "Users can read their own bookings" ON bookings;

-- Create fixed policies for profiles table
CREATE POLICY "Users can read own profile fixed"
ON profiles
FOR SELECT
TO authenticated
USING (auth.uid() = id);

CREATE POLICY "Users can update own profile fixed"
ON profiles
FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- Make sure bookings table exists and has proper structure
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'bookings'
  ) THEN
    CREATE TABLE IF NOT EXISTS bookings (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id UUID REFERENCES auth.users(id),
      booking_reference TEXT NOT NULL,
      booking_date TIMESTAMPTZ DEFAULT now(),
      travel_date TIMESTAMPTZ,
      customer_name TEXT NOT NULL,
      customer_email TEXT NOT NULL,
      tour_id UUID,
      event_id UUID,
      total_amount DECIMAL NOT NULL,
      status TEXT DEFAULT 'pending',
      payment_status TEXT DEFAULT 'pending',
      created_at TIMESTAMPTZ DEFAULT now(),
      updated_at TIMESTAMPTZ DEFAULT now()
    );
  END IF;
END $$;

-- Enable RLS on bookings if not already enabled
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Create fixed policy for bookings
CREATE POLICY "Users can read their own bookings fixed"
ON bookings
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- Allow admins to read all bookings
CREATE POLICY "Admins can read all bookings"
ON bookings
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.is_admin = true
  )
);

-- Add basic index to improve performance
CREATE INDEX IF NOT EXISTS idx_bookings_user_id ON bookings(user_id);