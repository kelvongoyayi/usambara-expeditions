/*
  # Update Storage Buckets Configuration

  1. Changes
    - Ensure all required storage buckets exist
    - Set all buckets to public for easier access
    - Add images bucket if it doesn't exist
    - Update RLS policies to allow access to all buckets
  
  2. Security
    - Maintain permissive policies for development
    - Ensure all buckets are accessible to authenticated users
*/

-- Create buckets if they don't exist
DO $$
BEGIN
  -- Create tours bucket if it doesn't exist
  BEGIN
    INSERT INTO storage.buckets (id, name, public)
    VALUES ('tours', 'tours', true);
  EXCEPTION
    WHEN unique_violation THEN
      -- Bucket already exists, update it to be public
      UPDATE storage.buckets SET public = true WHERE id = 'tours';
  END;

  -- Create events bucket if it doesn't exist
  BEGIN
    INSERT INTO storage.buckets (id, name, public)
    VALUES ('events', 'events', true);
  EXCEPTION
    WHEN unique_violation THEN
      -- Bucket already exists, update it to be public
      UPDATE storage.buckets SET public = true WHERE id = 'events';
  END;

  -- Create destinations bucket if it doesn't exist
  BEGIN
    INSERT INTO storage.buckets (id, name, public)
    VALUES ('destinations', 'destinations', true);
  EXCEPTION
    WHEN unique_violation THEN
      -- Bucket already exists, update it to be public
      UPDATE storage.buckets SET public = true WHERE id = 'destinations';
  END;

  -- Create profiles bucket if it doesn't exist
  BEGIN
    INSERT INTO storage.buckets (id, name, public)
    VALUES ('profiles', 'profiles', true);
  EXCEPTION
    WHEN unique_violation THEN
      -- Bucket already exists, update it to be public
      UPDATE storage.buckets SET public = true WHERE id = 'profiles';
  END;

  -- Create images bucket if it doesn't exist
  BEGIN
    INSERT INTO storage.buckets (id, name, public)
    VALUES ('images', 'images', true);
  EXCEPTION
    WHEN unique_violation THEN
      -- Bucket already exists, update it to be public
      UPDATE storage.buckets SET public = true WHERE id = 'images';
  END;
END $$;

-- Update all buckets to be public
UPDATE storage.buckets
SET public = true
WHERE id IN ('tours', 'events', 'destinations', 'profiles', 'images');

-- Enable RLS on storage.objects if not already enabled
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Allow public read access" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated users full access" ON storage.objects;

-- Create policy for public read access
CREATE POLICY "Allow public read access"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id IN ('tours', 'events', 'destinations', 'profiles', 'images'));

-- Create policy for all authenticated users to have full access
-- This is a permissive policy for development purposes
CREATE POLICY "Allow authenticated users full access"
ON storage.objects
FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);