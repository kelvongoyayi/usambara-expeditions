/*
  # Fix Profiles Table RLS Policies

  1. Changes
    - Drop existing RLS policies that are causing infinite recursion
    - Create new, properly scoped RLS policies for the profiles table
    - Add safe function to check admin status without recursion

  2. Security
    - Enable RLS on profiles table
    - Add policies for:
      - Users can read their own profile
      - Users can update their own profile
      - Users can insert their own profile
      - Admins can read all profiles
      - Admins can update all profiles
*/

-- First, disable RLS temporarily to fix policies
ALTER TABLE profiles DISABLE ROW LEVEL SECURITY;

-- Drop any existing policies
DROP POLICY IF EXISTS "Users can read own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Admins can read all profiles" ON profiles;
DROP POLICY IF EXISTS "Admins can update all profiles" ON profiles;
DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;

-- Drop existing admin check function if it exists
DROP FUNCTION IF EXISTS is_admin();

-- Create a function to check if a user is an admin that avoids recursion
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
DECLARE
  is_admin_user BOOLEAN;
BEGIN
  -- First check if user is authenticated
  IF auth.uid() IS NULL THEN
    RETURN FALSE;
  END IF;
  
  -- Check admin status directly without using RLS
  -- This avoids the recursion issue
  SELECT p.is_admin INTO is_admin_user
  FROM profiles p
  WHERE p.id = auth.uid();
  
  -- Return result (or false if no result)
  RETURN COALESCE(is_admin_user, FALSE);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Re-enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Create new policies with proper checks that avoid recursion
-- Allow any authenticated user to read their own profile
CREATE POLICY "Users can read own profile"
ON profiles
FOR SELECT
TO authenticated
USING (
  auth.uid() = id
);

-- Allow any authenticated user to update their own profile
CREATE POLICY "Users can update own profile"
ON profiles
FOR UPDATE
TO authenticated
USING (
  auth.uid() = id
)
WITH CHECK (
  auth.uid() = id
);

-- Allow any authenticated user to insert their own profile
-- This is needed for initial profile creation
CREATE POLICY "Users can insert own profile"
ON profiles
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = id
);

-- Allow admin to read all profiles
-- This uses the fixed is_admin() function to avoid recursion
CREATE POLICY "Admins can read all profiles"
ON profiles
FOR SELECT
TO authenticated
USING (
  is_admin()
);

-- Allow admin to update all profiles
-- This uses the fixed is_admin() function to avoid recursion
CREATE POLICY "Admins can update all profiles"
ON profiles
FOR UPDATE
TO authenticated
USING (
  is_admin()
)
WITH CHECK (
  is_admin()
);