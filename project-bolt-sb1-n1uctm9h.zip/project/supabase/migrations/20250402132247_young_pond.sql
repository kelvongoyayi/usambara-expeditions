/*
  # Create tour_categories table

  1. New Tables
    - `tour_categories`
      - `id` (text, primary key)
      - `name` (text, not null)
      - `description` (text)
      - `icon` (text)
      - `created_at` (timestamp with timezone, default: now())

  2. Security
    - Enable RLS on `tour_categories` table
    - Add policies for authenticated users
*/

CREATE TABLE IF NOT EXISTS tour_categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text,
  icon text,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE tour_categories ENABLE ROW LEVEL SECURITY;

-- Policy for reading tour categories (allow all)
CREATE POLICY "Anyone can read tour categories" 
  ON tour_categories
  FOR SELECT 
  USING (true);

-- Policy for inserting/updating/deleting tour categories (admins only)
CREATE POLICY "Only admins can modify tour categories" 
  ON tour_categories
  FOR ALL
  TO authenticated
  USING (true); -- For development, allow all authenticated users

-- Insert initial tour categories
INSERT INTO tour_categories (id, name, description, icon) VALUES
('hiking', 'Hiking', 'Guided hiking tours through beautiful trails and mountains', 'mountain'),
('cycling', 'Cycling', 'Thrilling cycling expeditions through various terrains', 'bike'),
('cultural', 'Cultural', 'Experience the rich cultural heritage with local guides', 'map'),
('4x4', '4x4 Expedition', 'Off-road adventures in 4x4 vehicles through challenging terrain', 'compass'),
('motocamping', 'Motocamping', 'Motor biking adventures with camping experiences', 'activity'),
('school', 'School Tours', 'Educational tours for school groups and students', 'users')
ON CONFLICT (id) DO NOTHING;