/*
  # Sample Events Data
  
  1. New Data
    - Adds sample events with complete details including descriptions, dates, images, and itineraries
    
  2. Purpose
    - Provides initial data for the events section of the website
    - Includes various event types with comprehensive details
*/

-- Insert sample events
INSERT INTO events (
  id, title, event_type, description, start_date, end_date,
  location, image_url, price, rating, duration,
  min_attendees, max_attendees, highlights,
  included, excluded, 
  itinerary, faqs, gallery, featured
) VALUES (
  gen_random_uuid(),
  'Corporate Team Building Retreat',
  'corporate',
  'An immersive corporate retreat designed to strengthen team bonds through strategic challenges, outdoor activities, and guided reflection sessions in the beautiful setting of the Usambara Mountains.',
  '2025-06-15',
  '2025-06-18',
  'Lushoto Valley Resort',
  'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
  599,
  4.9,
  '3 days',
  10,
  50,
  ARRAY[
    'Customized team-building challenges',
    'Professional facilitation by business psychology experts',
    'Strategic planning sessions in inspiring settings',
    'Adventure activities to build trust and communication',
    'Luxury accommodation with business facilities'
  ],
  ARRAY[
    'All accommodation and meals',
    'Professional facilitation and materials',
    'Team building activities and equipment',
    'Meeting room and business facilities',
    'Welcome reception and gala dinner'
  ],
  ARRAY[
    'Transportation to venue',
    'Alcoholic beverages outside of planned functions',
    'Personal expenses',
    'Extended stays before or after the event'
  ],
  '[
    {
      "day": 1,
      "title": "Arrival and Team Assessment",
      "description": "Begin your corporate retreat with welcome activities, team assessments, and an evening networking reception that sets the tone for productive days ahead.",
      "activities": [
        "Morning arrival and welcome briefing",
        "Team assessment exercises and diagnostics",
        "Lunch with introduction from facilitators",
        "Afternoon team challenge: \"Bridge the Divide\"",
        "Evening networking reception and dinner"
      ],
      "meals": ["lunch", "dinner"],
      "accommodation": "Lushoto Valley Resort"
    },
    {
      "day": 2,
      "title": "Strategic Challenges and Outdoor Team Building",
      "description": "Engage in a mix of strategic business planning and outdoor team challenges designed to improve communication and reveal team dynamics.",
      "activities": [
        "Morning strategic planning session",
        "Outdoor team challenge: \"Navigation Challenge\"",
        "Facilitated problem-solving workshop",
        "Afternoon adventure activity (choose from hiking, cycling, or ropes course)",
        "Evening reflection session and themed dinner"
      ],
      "meals": ["breakfast", "lunch", "dinner"],
      "accommodation": "Lushoto Valley Resort"
    },
    {
      "day": 3,
      "title": "Implementation Planning and Departure",
      "description": "Consolidate learnings from the previous days and develop concrete action plans to implement back in the workplace, followed by a celebration of achievements.",
      "activities": [
        "Morning action planning workshop",
        "Cross-team challenge: \"Project Acceleration\"",
        "Implementation roadmapping session",
        "Farewell lunch and certificate presentation",
        "Departure"
      ],
      "meals": ["breakfast", "lunch"],
      "accommodation": ""
    }
  ]'::jsonb,
  '[
    {
      "question": "Can the retreat be customized to our company\"s specific challenges?",
      "answer": "Yes, we work closely with your leadership team before the event to understand your specific goals, challenges, and team dynamics. The program is then tailored to address your unique organizational needs."
    },
    {
      "question": "What facilities are available for business sessions?",
      "answer": "The resort offers fully equipped meeting rooms with high-speed internet, projection systems, whiteboards, and breakout areas. Outdoor meeting spaces are also available for inspiration."
    },
    {
      "question": "Is there reliable internet and phone connectivity?",
      "answer": "Yes, the resort has reliable high-speed internet throughout the property and good mobile coverage, allowing participants to stay connected if necessary."
    },
    {
      "question": "How are dietary restrictions accommodated?",
      "answer": "We accommodate all dietary requirements with advance notice. The resort\"s culinary team will prepare appropriate meals for any restrictions including vegetarian, vegan, gluten-free, and religious dietary needs."
    }
  ]'::jsonb,
  ARRAY[
    'https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    'https://images.unsplash.com/photo-1540317580384-e5d43867caa6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80',
    'https://images.unsplash.com/photo-1603208607184-11e98283d537?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2073&q=80'
  ],
  true
),
(
  gen_random_uuid(),
  'Mountain Cycling Championship',
  'adventure',
  'Challenge yourself in this thrilling mountain cycling competition through the scenic trails and challenging terrain of the Usambara Mountains. Open to amateur and semi-professional cyclists of various skill levels.',
  '2025-07-22',
  '2025-07-22',
  'Lushoto Valley',
  'https://images.unsplash.com/photo-1517649763962-0c623066013b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
  120,
  4.7,
  '1 day',
  50,
  200,
  ARRAY[
    'Professional race organization and timing',
    'Multiple route options for different skill levels',
    'Spectacular mountain scenery throughout the course',
    'Safety marshals and medical support',
    'Post-race celebration and awards ceremony'
  ],
  ARRAY[
    'Race entry and official number',
    'Course marshalling and safety support',
    'Medical assistance on the course',
    'Water and nutrition stations',
    'Finisher\"s medal and event t-shirt',
    'Post-race meal and refreshments'
  ],
  ARRAY[
    'Bicycle and equipment rental',
    'Transportation to event location',
    'Accommodation (available as add-on)',
    'Personal accident insurance',
    'Professional training services'
  ],
  '[
    {
      "day": 1,
      "title": "Race Day: Mountain Cycling Championship",
      "description": "Experience the thrill of the Usambara Mountain Cycling Championship with multiple race categories for different skill levels. The event follows established safety protocols with professional organization throughout.",
      "activities": [
        "Early morning registration and bike check",
        "Race briefing and safety instructions",
        "Staggered start times by category",
        "Race through marked mountain trails",
        "Rest and nutrition stations along the course",
        "Finish line celebrations and recovery zone",
        "Afternoon awards ceremony and closing party"
      ],
      "meals": ["lunch"],
      "accommodation": "",
      "distance": "Expert: 60km, Intermediate: 40km, Beginner: 20km",
      "elevation": "Expert: 1200m, Intermediate: 800m, Beginner: 400m"
    }
  ]'::jsonb,
  '[
    {
      "question": "What cycling skill level is required?",
      "answer": "The event offers three categories: Expert (advanced technical skills required), Intermediate (confident on single tracks and moderate technical sections), and Beginner (comfortable on dirt roads and gentle trails). Choose the category that matches your ability."
    },
    {
      "question": "What type of bike is recommended?",
      "answer": "A mountain bike with front suspension is minimum for all routes. For the Expert and Intermediate routes, a full-suspension mountain bike is recommended. E-bikes are permitted only in a separate category."
    },
    {
      "question": "Are there age restrictions?",
      "answer": "Participants must be at least 16 years old for the Beginner route, 18 years for Intermediate, and 18 years for Expert. Riders under 18 require parental consent."
    },
    {
      "question": "What safety measures are in place?",
      "answer": "The course is fully marshalled with medical stations, sweep riders, and emergency evacuation plans. Helmets are mandatory, and additional protective gear is strongly recommended."
    }
  ]'::jsonb,
  ARRAY[
    'https://images.unsplash.com/photo-1541625602330-2277a4c46b5b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    'https://images.unsplash.com/photo-1592184797830-0806c3f9af9f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    'https://images.unsplash.com/photo-1605913293672-5c7f4e766efc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
  ],
  true
),
(
  gen_random_uuid(),
  'Cultural Exchange Program',
  'education',
  'A transformative cultural immersion program designed for educational institutions and cultural enthusiasts. This program provides deep engagement with local communities, traditions, and ecological knowledge through facilitated exchanges and community-led workshops.',
  '2025-08-05',
  '2025-08-10',
  'Multiple Villages',
  'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2069&q=80',
  450,
  4.8,
  '6 days',
  10,
  25,
  ARRAY[
    'In-depth cultural immersion across multiple villages',
    'Facilitated discussions with community elders and leaders',
    'Participation in traditional ceremonies and practices',
    'Hands-on learning of indigenous skills and crafts',
    'Structured reflection and learning documentation'
  ],
  ARRAY[
    'All accommodation in homestays and guest houses',
    'All meals prepared in traditional methods',
    'Professional cultural facilitators and translators',
    'Transportation between program locations',
    'Learning materials and cultural workshops',
    'Community contribution fees'
  ],
  ARRAY[
    'International flights',
    'Personal travel insurance',
    'Personal items and souvenirs',
    'Optional activities outside the program'
  ],
  '[
    {
      "day": 1,
      "title": "Arrival and Cultural Orientation",
      "description": "Begin your cultural journey with a comprehensive orientation to local customs, etiquette, and basic language, followed by integration with your first host community.",
      "activities": [
        "Arrival and welcome at central meeting point",
        "Cultural orientation and sensitivity workshop",
        "Basic language instruction and practice",
        "Travel to first village and host family introductions",
        "Welcome ceremony and community dinner"
      ],
      "meals": ["lunch", "dinner"],
      "accommodation": "Family Homestay - First Village"
    },
    {
      "day": 2,
      "title": "Traditional Knowledge Systems",
      "description": "Explore indigenous knowledge systems through direct learning with community experts in agriculture, natural medicine, and sustainable resource management.",
      "activities": [
        "Traditional farming techniques workshop",
        "Medicinal plant walk with local healers",
        "Hands-on forest resource management demonstration",
        "Community roundtable on knowledge preservation",
        "Evening storytelling and oral history session"
      ],
      "meals": ["breakfast", "lunch", "dinner"],
      "accommodation": "Family Homestay - First Village"
    },
    {
      "day": 3,
      "title": "Artistic Traditions and Expression",
      "description": "Immerse in the artistic and creative expressions of the culture through music, dance, crafts, and visual arts guided by community artisans and performers.",
      "activities": [
        "Traditional music and instrument workshop",
        "Dance instruction with community performers",
        "Handicraft learning session with master artisans",
        "Visual arts and symbolic meaning discussion",
        "Evening cultural performance participation"
      ],
      "meals": ["breakfast", "lunch", "dinner"],
      "accommodation": "Family Homestay - Second Village"
    },
    {
      "day": 4,
      "title": "Community Development Initiatives",
      "description": "Engage with local development projects addressing education, conservation, economic empowerment, and community well-being through participatory activities.",
      "activities": [
        "Visit to community-led conservation project",
        "Participation in school education program",
        "Women\"s cooperative demonstration and discussion",
        "Community development challenges roundtable",
        "Collaborative problem-solving workshop"
      ],
      "meals": ["breakfast", "lunch", "dinner"],
      "accommodation": "Family Homestay - Second Village"
    },
    {
      "day": 5,
      "title": "Contemporary Culture and Transitions",
      "description": "Explore the intersection of tradition and modernity, examining how the community navigates cultural preservation while embracing change and innovation.",
      "activities": [
        "Youth perspectives forum and discussion",
        "Technology adoption observation and analysis",
        "Economic transition case studies examination",
        "Cultural adaptation workshop and dialogue",
        "Modern cultural expressions evening event"
      ],
      "meals": ["breakfast", "lunch", "dinner"],
      "accommodation": "Guest House - Central Location"
    },
    {
      "day": 6,
      "title": "Reflection and Departure",
      "description": "Consolidate your cultural learning experience through structured reflection, documentation of insights, and meaningful closing ceremonies before departure.",
      "activities": [
        "Morning reflection and journaling session",
        "Group sharing of key learnings and insights",
        "Documentation compilation and keepsake creation",
        "Farewell ceremony with community representatives",
        "Final lunch and departure"
      ],
      "meals": ["breakfast", "lunch"],
      "accommodation": ""
    }
  ]'::jsonb,
  '[
    {
      "question": "What level of cultural immersion should I expect?",
      "answer": "This is a deep immersion program where participants live with families, participate in daily activities, and engage intensively with community members. You should expect basic living conditions, traditional foods, and constant cultural interaction."
    },
    {
      "question": "Do I need previous knowledge of the culture or language?",
      "answer": "No prior knowledge is required. Our facilitators provide comprehensive orientation and ongoing support. Basic phrases in the local language will be taught, and translators are available throughout the program."
    },
    {
      "question": "How physically demanding is this program?",
      "answer": "The physical demands are moderate. Participants should be able to walk 3-5 km daily over varied terrain, sit on the ground for certain activities, and adapt to basic living conditions. Activities can be modified for different ability levels."
    },
    {
      "question": "How are ethical concerns around cultural tourism addressed?",
      "answer": "This program follows strict ethical guidelines developed with community partners. Communities have ownership in program design, receive fair compensation, and have established boundaries about what cultural elements are shared. Pre-program briefings address cultural respect and appropriate behavior."
    }
  ]'::jsonb,
  ARRAY[
    'https://images.unsplash.com/photo-1605192554106-d549b1b975ff?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    'https://images.unsplash.com/photo-1516426122078-c23e76319801?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    'https://images.unsplash.com/photo-1559628129-67cf63b72248?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2139&q=80'
  ],
  true
),
(
  gen_random_uuid(),
  'Luxury Wedding Package',
  'special',
  'Create the wedding of your dreams in the breathtaking setting of Tanzania\"s coastal paradise. Our comprehensive luxury wedding package combines pristine beaches, world-class accommodation, and meticulous planning to ensure your special day is perfect in every detail.',
  '2025-09-12',
  '2025-09-12',
  'Tanga Beach Resort',
  'https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2021&q=80',
  4999,
  4.8,
  '1 day',
  2,
  150,
  ARRAY[
    'Exclusive beach venue with stunning ocean backdrop',
    'Professional wedding planning and coordination',
    'Luxury accommodation for couple and option for guests',
    'Gourmet catering with customized menu options',
    'Professional photography and videography package'
  ],
  ARRAY[
    'Dedicated wedding planner',
    'Venue setup and decoration',
    'Ceremony officiant (symbolic or legal)',
    'Bridal bouquet and groom\"s boutonniere',
    'Wedding cake and champagne toast',
    'Reception dinner for up to 50 guests',
    'Sound system for ceremony and reception',
    'Photography package (6 hours coverage)'
  ],
  ARRAY[
    'Accommodation (available as add-on packages)',
    'Wedding attire',
    'Additional floral arrangements beyond standard package',
    'Live entertainment (available as add-on)',
    'Additional guests beyond 50 person package',
    'Marriage license and legal documentation fees'
  ],
  '[
    {
      "day": 1,
      "title": "Wedding Day",
      "description": "Your perfectly orchestrated wedding day flows seamlessly from preparation through ceremony, reception, and celebration, all in a stunning coastal setting with every detail attended to by our professional team.",
      "activities": [
        "Morning preparation with dedicated spaces for wedding party",
        "Pre-ceremony photography session in scenic locations",
        "Beachfront ceremony with customized decor and setup",
        "Post-ceremony cocktail hour with canapes",
        "Sunset reception dinner with personalized menu",
        "Evening celebration with entertainment options"
      ],
      "meals": ["breakfast", "lunch", "dinner"],
      "accommodation": "Honeymoon Suite - Tanga Beach Resort"
    }
  ]'::jsonb,
  '[
    {
      "question": "How far in advance should we book our wedding?",
      "answer": "We recommend booking at least 9-12 months in advance to secure your preferred date, especially for the high season (June-October). Some flexibility with dates may allow for shorter booking timeframes."
    },
    {
      "question": "Can we customize the wedding package?",
      "answer": "Absolutely! While we offer comprehensive packages as a starting point, every aspect can be customized to your preferences. Our wedding planners will work with you to create your perfect celebration."
    },
    {
      "question": "What accommodation options are available for our guests?",
      "answer": "The resort offers various accommodation categories from standard rooms to luxury villas. We can arrange special group rates for wedding guests, and there are also nearby hotels at different price points for additional options."
    },
    {
      "question": "Is the wedding legally binding?",
      "answer": "We offer both symbolic ceremonies and legally binding weddings. For legal weddings, additional documentation is required and processing fees apply. We recommend allowing at least 3 months for legal paperwork processing."
    }
  ]'::jsonb,
  ARRAY[
    'https://images.unsplash.com/photo-1550005809-91ad75fb315f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2069&q=80',
    'https://images.unsplash.com/photo-1532712938310-34cb3982ef74?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    'https://images.unsplash.com/photo-1519225421980-715cb0215aed?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
  ],
  false
);