/*
  # Fix Bookings Schema and Admin Stats Function

  1. Changes
    - Add missing customer_name and customer_email columns to bookings table
    - Update get_admin_stats function to properly handle customer information
    - Fix queries to use correct column references

  2. Security
    - Maintain existing RLS policies
    - Ensure proper data access controls
*/

-- Add missing columns to bookings table if they don't exist
DO $$ 
BEGIN
  -- Add customer_name column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'public' AND table_name = 'bookings' AND column_name = 'customer_name'
  ) THEN
    ALTER TABLE bookings ADD COLUMN customer_name TEXT;
  END IF;

  -- Add customer_email column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'public' AND table_name = 'bookings' AND column_name = 'customer_email'
  ) THEN
    ALTER TABLE bookings ADD COLUMN customer_email TEXT;
  END IF;
END $$;

-- Drop existing get_admin_stats function if it exists
DROP FUNCTION IF EXISTS get_admin_stats();

-- Create updated get_admin_stats function
CREATE OR REPLACE FUNCTION get_admin_stats()
RETURNS JSONB AS $$
DECLARE
  result JSONB;
BEGIN
  SELECT jsonb_build_object(
    'total_tours', (SELECT COUNT(*) FROM tours),
    'total_events', (SELECT COUNT(*) FROM events),
    'total_bookings', (SELECT COUNT(*) FROM bookings),
    'total_users', (SELECT COUNT(*) FROM profiles),
    'recent_bookings', (
      SELECT jsonb_agg(row_to_json(b))
      FROM (
        SELECT 
          b.id, 
          b.booking_reference, 
          b.booking_date, 
          b.travel_date,
          COALESCE(b.customer_name, p.first_name || ' ' || p.last_name) as customer_name,
          COALESCE(b.customer_email, p.email) as customer_email,
          b.tour_id, 
          b.event_id, 
          b.total_amount, 
          b.status, 
          b.payment_status,
          t.title as tour_title,
          e.title as event_title
        FROM bookings b
        LEFT JOIN profiles p ON b.user_id = p.id
        LEFT JOIN tours t ON b.tour_id = t.id
        LEFT JOIN events e ON b.event_id = e.id
        ORDER BY b.created_at DESC
        LIMIT 5
      ) b
    ),
    'popular_tours', (
      SELECT jsonb_agg(row_to_json(t))
      FROM (
        SELECT 
          t.id, 
          t.title, 
          t.image_url, 
          t.price, 
          t.rating,
          COUNT(b.id) as booking_count
        FROM tours t
        LEFT JOIN bookings b ON t.id = b.tour_id
        GROUP BY t.id, t.title, t.image_url, t.price, t.rating
        ORDER BY COUNT(b.id) DESC
        LIMIT 5
      ) t
    )
  ) INTO result;

  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update any existing bookings to set customer_name and customer_email from profiles
UPDATE bookings b
SET 
  customer_name = p.first_name || ' ' || p.last_name,
  customer_email = p.email
FROM profiles p
WHERE b.user_id = p.id
  AND (b.customer_name IS NULL OR b.customer_email IS NULL);