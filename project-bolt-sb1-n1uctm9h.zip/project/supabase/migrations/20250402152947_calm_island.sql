/*
  # Create Admin User Functions

  1. New Functions
    - `create_admin_user` - Creates a new admin user
    - `make_user_admin` - Converts an existing user to an admin
    - `check_admin_status` - Checks if a user is an admin

  2. Security
    - Functions are SECURITY DEFINER to run with elevated privileges
    - Proper validation and error handling
*/

-- Function to make an existing user an admin
CREATE OR REPLACE FUNCTION make_user_admin(user_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
  user_exists BOOLEAN;
BEGIN
  -- Check if the user exists
  SELECT EXISTS (
    SELECT 1 FROM auth.users WHERE id = user_id
  ) INTO user_exists;
  
  IF NOT user_exists THEN
    RETURN false;
  END IF;
  
  -- Update the user's profile to make them an admin
  UPDATE profiles
  SET 
    is_admin = true,
    updated_at = now()
  WHERE id = user_id;
  
  -- Log the action
  INSERT INTO admin_logs (
    user_id,
    action_type,
    table_name,
    record_id,
    details
  ) VALUES (
    auth.uid(),
    'update',
    'profiles',
    user_id::text,
    jsonb_build_object('is_admin', true)
  );
  
  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to check if a user is an admin
CREATE OR REPLACE FUNCTION check_admin_status(user_id UUID DEFAULT NULL)
RETURNS BOOLEAN AS $$
DECLARE
  target_user_id UUID;
BEGIN
  -- If no user_id is provided, use the current user
  target_user_id := COALESCE(user_id, auth.uid());
  
  -- Check if the user is an admin
  RETURN EXISTS (
    SELECT 1 FROM profiles
    WHERE id = target_user_id AND is_admin = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to log admin actions
CREATE OR REPLACE FUNCTION log_admin_action(
  action_type TEXT,
  table_name TEXT,
  record_id TEXT,
  details JSONB DEFAULT NULL
)
RETURNS VOID AS $$
BEGIN
  INSERT INTO admin_logs (
    user_id,
    action_type,
    table_name,
    record_id,
    details
  ) VALUES (
    auth.uid(),
    action_type,
    table_name,
    record_id,
    details
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;