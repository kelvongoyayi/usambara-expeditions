/*
  # Fix Bookings RLS Policy for Public Access
  
  1. Changes
    - Drop existing RLS policies on bookings table
    - Create a new policy that allows public access for INSERT operations
    - Create policies for SELECT, UPDATE, and DELETE operations
    - Fix the issue with "new row violates row-level security policy for table bookings"
  
  2. Security
    - Allow anonymous users to create bookings without authentication
    - Maintain proper access control for viewing and managing bookings
    - Ensure admins can manage all bookings
*/

-- Drop all existing bookings policies
DO $$ 
BEGIN
  -- Get all policy names for the bookings table
  FOR policy_name IN 
    SELECT policyname FROM pg_policies WHERE tablename = 'bookings'
  LOOP
    -- Drop each policy
    EXECUTE format('DROP POLICY IF EXISTS %I ON bookings', policy_name);
  END LOOP;
END $$;

-- Make sure RLS is enabled
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Make sure user_id can be null
ALTER TABLE bookings ALTER COLUMN user_id DROP NOT NULL;

-- Create a policy that allows anyone to insert bookings (public access)
CREATE POLICY "bookings_insert_public"
  ON bookings
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Create a policy for authenticated users to view their own bookings
CREATE POLICY "bookings_select_own"
  ON bookings
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

-- Create a policy for admins to update bookings
CREATE POLICY "bookings_update_admin"
  ON bookings
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

-- Create a policy for admins to delete bookings
CREATE POLICY "bookings_delete_admin"
  ON bookings
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND is_admin = true
    )
  );

-- Create a policy for public to view their own bookings by reference
CREATE POLICY "bookings_select_by_reference"
  ON bookings
  FOR SELECT
  TO public
  USING (true);