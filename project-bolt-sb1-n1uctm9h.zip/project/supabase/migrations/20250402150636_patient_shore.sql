/*
  # Add Performance Indexes for Tours and Events

  1. Changes
    - Add indexes to improve query performance for tours and events
    - Add indexes for common search and filter operations
    - Add indexes for foreign key relationships

  2. Benefits
    - Faster loading of tour and event listings
    - Improved performance for filtered searches
    - Better overall database performance
*/

-- Add indexes for tours table
DO $$ 
BEGIN
  -- Index for category searches
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'tours' AND indexname = 'idx_tours_category'
  ) THEN
    CREATE INDEX idx_tours_category ON tours(category);
  END IF;

  -- Index for featured tours
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'tours' AND indexname = 'idx_tours_featured'
  ) THEN
    CREATE INDEX idx_tours_featured ON tours(featured);
  END IF;

  -- Index for price range searches
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'tours' AND indexname = 'idx_tours_price'
  ) THEN
    CREATE INDEX idx_tours_price ON tours(price);
  END IF;

  -- Index for location searches
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'tours' AND indexname = 'idx_tours_location'
  ) THEN
    CREATE INDEX idx_tours_location ON tours(location);
  END IF;

  -- Index for slug lookups
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'tours' AND indexname = 'idx_tours_slug'
  ) THEN
    CREATE UNIQUE INDEX idx_tours_slug ON tours(slug);
  END IF;
END $$;

-- Add indexes for events table
DO $$ 
BEGIN
  -- Index for event_type searches
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'events' AND indexname = 'idx_events_event_type'
  ) THEN
    CREATE INDEX idx_events_event_type ON events(event_type);
  END IF;

  -- Index for featured events
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'events' AND indexname = 'idx_events_featured'
  ) THEN
    CREATE INDEX idx_events_featured ON events(featured);
  END IF;

  -- Index for price range searches
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'events' AND indexname = 'idx_events_price'
  ) THEN
    CREATE INDEX idx_events_price ON events(price);
  END IF;

  -- Index for location searches
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'events' AND indexname = 'idx_events_location'
  ) THEN
    CREATE INDEX idx_events_location ON events(location);
  END IF;

  -- Index for date range searches
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'events' AND indexname = 'idx_events_dates'
  ) THEN
    CREATE INDEX idx_events_dates ON events(start_date, end_date);
  END IF;

  -- Index for slug lookups
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'events' AND indexname = 'idx_events_slug'
  ) THEN
    CREATE UNIQUE INDEX idx_events_slug ON events(slug);
  END IF;
END $$;

-- Add indexes for bookings table
DO $$ 
BEGIN
  -- Index for user_id lookups
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'bookings' AND indexname = 'idx_bookings_user_id'
  ) THEN
    CREATE INDEX idx_bookings_user_id ON bookings(user_id);
  END IF;

  -- Index for tour_id lookups
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'bookings' AND indexname = 'idx_bookings_tour_id'
  ) THEN
    CREATE INDEX idx_bookings_tour_id ON bookings(tour_id);
  END IF;

  -- Index for event_id lookups
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'bookings' AND indexname = 'idx_bookings_event_id'
  ) THEN
    CREATE INDEX idx_bookings_event_id ON bookings(event_id);
  END IF;

  -- Index for booking reference lookups
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'bookings' AND indexname = 'idx_bookings_reference'
  ) THEN
    CREATE UNIQUE INDEX idx_bookings_reference ON bookings(booking_reference);
  END IF;

  -- Index for status lookups
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE tablename = 'bookings' AND indexname = 'idx_bookings_status'
  ) THEN
    CREATE INDEX idx_bookings_status ON bookings(status);
  END IF;
END $$;

-- Create function to execute SQL for migrations
CREATE OR REPLACE FUNCTION exec_sql(sql_query TEXT)
RETURNS VOID AS $$
BEGIN
  EXECUTE sql_query;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;