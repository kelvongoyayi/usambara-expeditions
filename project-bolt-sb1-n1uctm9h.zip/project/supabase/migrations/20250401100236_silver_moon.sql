/*
  # Fix tour categories functionality

  1. Changes
    - Add proper error handling for category creation
    - Add unique constraint on slug
    - Add trigger to auto-generate slug if not provided
    - Add function to sanitize slugs

  2. Details
    - Ensures categories have unique slugs
    - Automatically generates clean slugs from names
    - Adds proper error handling
*/

-- Function to generate clean slugs
CREATE OR REPLACE FUNCTION generate_clean_slug(input_text TEXT)
RETURNS TEXT AS $$
BEGIN
  RETURN LOWER(
    REGEXP_REPLACE(
      REGEXP_REPLACE(
        UNACCENT(input_text),
        '[^a-zA-Z0-9\s-]',
        '',
        'g'
      ),
      '\s+',
      '-',
      'g'
    )
  );
END;
$$ LANGUAGE plpgsql;

-- Add unique constraint on slug if not exists
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_constraint 
    WHERE conname = 'tour_categories_slug_key'
  ) THEN
    ALTER TABLE tour_categories ADD CONSTRAINT tour_categories_slug_key UNIQUE (slug);
  END IF;
END $$;

-- Create trigger function to generate slug
CREATE OR REPLACE FUNCTION generate_category_slug()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.slug IS NULL OR NEW.slug = '' THEN
    NEW.slug := generate_clean_slug(NEW.name);
  END IF;
  
  -- Ensure slug is unique by appending number if needed
  WHILE EXISTS (
    SELECT 1 FROM tour_categories WHERE slug = NEW.slug AND id != NEW.id
  ) LOOP
    NEW.slug := NEW.slug || '-' || floor(random() * 1000)::text;
  END LOOP;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger if not exists
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM pg_trigger 
    WHERE tgname = 'generate_category_slug_trigger'
  ) THEN
    CREATE TRIGGER generate_category_slug_trigger
    BEFORE INSERT OR UPDATE ON tour_categories
    FOR EACH ROW
    EXECUTE FUNCTION generate_category_slug();
  END IF;
END $$;