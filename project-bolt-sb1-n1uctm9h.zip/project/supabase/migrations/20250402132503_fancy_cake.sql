/*
  # Create event_types table

  1. New Tables
    - `event_types`
      - `id` (text, primary key)
      - `name` (text, not null)
      - `description` (text)
      - `icon` (text)
      - `created_at` (timestamp with timezone, default: now())

  2. Security
    - Enable RLS on `event_types` table
    - Add policies for authenticated users
*/

CREATE TABLE IF NOT EXISTS event_types (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text,
  icon text,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE event_types ENABLE ROW LEVEL SECURITY;

-- Policy for reading event types (allow all)
CREATE POLICY "Anyone can read event types" 
  ON event_types
  FOR SELECT 
  USING (true);

-- Policy for inserting/updating/deleting event types (admins only)
CREATE POLICY "Only admins can modify event types" 
  ON event_types
  FOR ALL
  TO authenticated
  USING (true); -- For development, allow all authenticated users

-- Insert initial event types
INSERT INTO event_types (id, name, description, icon) VALUES
('corporate', 'Corporate Event', 'Team building events and workshops for companies', 'briefcase'),
('adventure', 'Adventure Event', 'Outdoor adventure experiences and challenges', 'mountain'),
('education', 'Educational Program', 'Learning programs and educational tours', 'graduation-cap'),
('special', 'Special Occasion', 'Celebrations and special events', 'gift')
ON CONFLICT (id) DO NOTHING;