/*
  # Fix Profiles RLS Policy

  1. Changes
    - Drop existing RLS policies on profiles table
    - Create new, properly scoped RLS policies to avoid infinite recursion
    - Add separate policies for select, update, and delete operations
  
  2. Security
    - Maintains row-level security
    - Users can only access their own profile
    - Admins can access all profiles
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;

-- Create new policies with proper checks
CREATE POLICY "Enable read access for users to own profile"
ON profiles FOR SELECT
USING (
  auth.uid() = id 
  OR 
  EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND is_admin = true
  )
);

CREATE POLICY "Enable update access for users to own profile"
ON profiles FOR UPDATE
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

CREATE POLICY "Enable delete access for users to own profile"
ON profiles FOR DELETE
USING (auth.uid() = id);

-- Ensure RLS is enabled
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;