/*
  # Fix Admin User Creation

  1. Changes
    - Add function to safely make a user an admin
    - Add function to check if user is first signup
    - Update profile trigger to handle admin status
*/

-- Function to check if this is the first user
CREATE OR REPLACE FUNCTION public.is_first_user()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT NOT EXISTS (
    SELECT 1 FROM profiles
    WHERE id IS NOT NULL
    LIMIT 1
  );
$$;

-- Update handle_new_user trigger function
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (
    id,
    email,
    is_admin
  ) VALUES (
    new.id,
    new.email,
    is_first_user() -- First user is automatically an admin
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$;

-- Function to make a user an admin
CREATE OR REPLACE FUNCTION public.make_user_admin(user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Only allow if executing user is an admin
  IF EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid()
    AND is_admin = true
  ) OR is_first_user() THEN
    UPDATE profiles
    SET 
      is_admin = true,
      updated_at = now()
    WHERE id = user_id;
    RETURN true;
  END IF;
  RETURN false;
END;
$$;