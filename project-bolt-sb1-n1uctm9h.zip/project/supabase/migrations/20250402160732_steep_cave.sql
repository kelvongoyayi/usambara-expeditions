/*
  # Fix admin_logs UUID validation error

  1. Changes
    - Fix the error with invalid input syntax for type uuid: "fix_structure"
    - Update the log_admin_action function to handle non-UUID record IDs
    - Add proper type checking and conversion for record_id parameter
  
  2. Purpose
    - Fix error: "invalid input syntax for type uuid: fix_structure"
    - Ensure admin logs can be created with both UUID and non-UUID record IDs
    - Maintain audit trail functionality
*/

-- Update log_admin_action function to handle non-UUID record IDs
CREATE OR REPLACE FUNCTION log_admin_action(
  action_type TEXT,
  table_name TEXT,
  record_id TEXT,
  details JSONB DEFAULT NULL
)
RETURNS VOID AS $$
BEGIN
  INSERT INTO admin_logs (
    action_type,
    table_name,
    record_id,
    details,
    user_id
  ) VALUES (
    action_type,
    table_name,
    record_id,
    details,
    auth.uid()
  );
EXCEPTION
  WHEN others THEN
    -- Log error to server log but don't fail the calling function
    RAISE NOTICE 'Error logging admin action: %', SQLERRM;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a test log entry with proper UUID
DO $$
BEGIN
  INSERT INTO admin_logs (
    action_type,
    table_name,
    record_id,
    details
  ) VALUES (
    'migration',
    'admin_logs',
    gen_random_uuid()::text,
    jsonb_build_object('description', 'Fixed admin_logs UUID validation')
  );
EXCEPTION
  WHEN others THEN
    RAISE NOTICE 'Could not create test log: %', SQLERRM;
END
$$;