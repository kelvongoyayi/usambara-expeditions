/*
  # Fix tour_categories table

  1. Changes
    - Check if table exists first
    - Drop table if exists with incompatible structure
    - Create table with text primary key instead of UUID
    - Add policies with IF NOT EXISTS clause

  2. Security
    - Enable RLS on `tour_categories` table
    - Add policies for authenticated users
*/

-- Check if table exists with UUID primary key
DO $$ 
BEGIN
  -- Drop the existing table if it has the wrong structure
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tour_categories' 
    AND column_name = 'id' 
    AND data_type = 'uuid'
  ) THEN
    DROP TABLE tour_categories CASCADE;
  END IF;
END $$;

-- Create the table with text primary key
CREATE TABLE IF NOT EXISTS tour_categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text,
  icon text,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security if not already enabled
ALTER TABLE tour_categories ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they cause conflicts
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Anyone can read tour categories" ON tour_categories;
  DROP POLICY IF EXISTS "Only admins can modify tour categories" ON tour_categories;
EXCEPTION
  WHEN OTHERS THEN NULL;
END $$;

-- Create policies
CREATE POLICY "Anyone can read tour categories" 
  ON tour_categories
  FOR SELECT 
  USING (true);

CREATE POLICY "Only admins can modify tour categories" 
  ON tour_categories
  FOR ALL
  TO authenticated
  USING (true); -- For development, allow all authenticated users

-- Insert initial tour categories if the table is empty
INSERT INTO tour_categories (id, name, description, icon)
SELECT * FROM (
  VALUES 
    ('hiking', 'Hiking', 'Guided hiking tours through beautiful trails and mountains', 'mountain'),
    ('cycling', 'Cycling', 'Thrilling cycling expeditions through various terrains', 'bike'),
    ('cultural', 'Cultural', 'Experience the rich cultural heritage with local guides', 'map'),
    ('4x4', '4x4 Expedition', 'Off-road adventures in 4x4 vehicles through challenging terrain', 'compass'),
    ('motocamping', 'Motocamping', 'Motor biking adventures with camping experiences', 'activity'),
    ('school', 'School Tours', 'Educational tours for school groups and students', 'users')
) AS data(id, name, description, icon)
WHERE NOT EXISTS (SELECT 1 FROM tour_categories LIMIT 1)
ON CONFLICT (id) DO NOTHING;