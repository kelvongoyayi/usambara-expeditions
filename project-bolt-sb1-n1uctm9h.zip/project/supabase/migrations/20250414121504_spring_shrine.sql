/*
  # Add Sample Bookings Data
  
  1. New Data
    - Adds sample bookings with complete details
    - Includes bookings for both tours and events
    - Provides a variety of statuses and payment states
  
  2. Purpose
    - Provides initial data for the bookings management section
    - Demonstrates different booking scenarios
    - Helps test the admin bookings interface
*/

-- Insert sample bookings
INSERT INTO bookings (
  id,
  booking_reference,
  booking_date,
  travel_date,
  customer_name,
  customer_email,
  tour_id,
  event_id,
  total_amount,
  status,
  payment_status,
  adults,
  children,
  special_requests,
  created_at,
  updated_at
)
SELECT 
  gen_random_uuid(),
  'UE-' || LPAD(FLOOR(random() * 10000)::text, 4, '0'),
  now() - (random() * interval '30 days'),
  now() + (random() * interval '90 days'),
  'Customer ' || i,
  'customer' || i || '@example.com',
  CASE WHEN i % 2 = 0 THEN 
    (SELECT id FROM tours ORDER BY random() LIMIT 1)
  ELSE
    NULL
  END,
  CASE WHEN i % 2 = 1 THEN 
    (SELECT id FROM events ORDER BY random() LIMIT 1)
  ELSE
    NULL
  END,
  (100 + (random() * 400))::numeric(10,2),
  CASE 
    WHEN i % 4 = 0 THEN 'pending'
    WHEN i % 4 = 1 THEN 'confirmed'
    WHEN i % 4 = 2 THEN 'completed'
    ELSE 'cancelled'
  END,
  CASE 
    WHEN i % 3 = 0 THEN 'pending'
    WHEN i % 3 = 1 THEN 'paid'
    ELSE 'refunded'
  END,
  1 + (random() * 4)::integer,
  (random() * 3)::integer,
  CASE WHEN i % 3 = 0 THEN 'Please arrange airport pickup.' ELSE NULL END,
  now() - (random() * interval '30 days'),
  now() - (random() * interval '30 days')
FROM generate_series(1, 10) i
ON CONFLICT DO NOTHING;

-- Add a few more specific bookings
INSERT INTO bookings (
  id,
  booking_reference,
  booking_date,
  travel_date,
  customer_name,
  customer_email,
  tour_id,
  total_amount,
  status,
  payment_status,
  adults,
  children,
  special_requests,
  created_at,
  updated_at
)
VALUES
  (
    gen_random_uuid(),
    'UE-DEMO1',
    now() - interval '2 days',
    now() + interval '14 days',
    'John Smith',
    'john.smith@example.com',
    (SELECT id FROM tours WHERE title LIKE '%Hiking%' LIMIT 1),
    299.99,
    'confirmed',
    'paid',
    2,
    1,
    'We would like a vegetarian meal option.',
    now() - interval '2 days',
    now() - interval '2 days'
  ),
  (
    gen_random_uuid(),
    'UE-DEMO2',
    now() - interval '1 day',
    now() + interval '30 days',
    'Sarah Johnson',
    'sarah.johnson@example.com',
    (SELECT id FROM tours WHERE title LIKE '%Cycling%' LIMIT 1),
    189.50,
    'pending',
    'pending',
    4,
    0,
    'We need bicycle rentals for all participants.',
    now() - interval '1 day',
    now() - interval '1 day'
  )
ON CONFLICT DO NOTHING;

INSERT INTO bookings (
  id,
  booking_reference,
  booking_date,
  travel_date,
  customer_name,
  customer_email,
  event_id,
  total_amount,
  status,
  payment_status,
  adults,
  children,
  special_requests,
  created_at,
  updated_at
)
VALUES
  (
    gen_random_uuid(),
    'UE-DEMO3',
    now() - interval '5 days',
    now() + interval '45 days',
    'Michael Brown',
    'michael.brown@example.com',
    (SELECT id FROM events WHERE title LIKE '%Team Building%' LIMIT 1),
    1299.99,
    'confirmed',
    'paid',
    15,
    0,
    'Our company requires a detailed invoice for accounting.',
    now() - interval '5 days',
    now() - interval '5 days'
  ),
  (
    gen_random_uuid(),
    'UE-DEMO4',
    now() - interval '10 days',
    now() + interval '7 days',
    'Emily Davis',
    'emily.davis@example.com',
    (SELECT id FROM events WHERE title LIKE '%Cultural%' LIMIT 1),
    450.00,
    'confirmed',
    'paid',
    2,
    2,
    'We need child-friendly accommodations.',
    now() - interval '10 days',
    now() - interval '10 days'
  )
ON CONFLICT DO NOTHING;