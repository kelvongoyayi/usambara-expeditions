/*
  # Add Additional Columns to Events Table
  
  1. Changes
    - Add gallery column to store multiple images as text array
    - Add columns for itinerary, faqs, included/excluded items
    - Add min/max attendees columns
    - Add additional descriptive columns for rich event data
  
  2. Rationale
    - These columns are needed to support the rich event data model
    - Ensures events have the same comprehensive data structure as tours
*/

-- Add gallery column as text array to store multiple image URLs
ALTER TABLE IF EXISTS events
ADD COLUMN IF NOT EXISTS gallery TEXT[];

-- Add columns for attendee limits
ALTER TABLE IF EXISTS events
ADD COLUMN IF NOT EXISTS min_attendees INTEGER;

ALTER TABLE IF EXISTS events
ADD COLUMN IF NOT EXISTS max_attendees INTEGER;

-- Add columns for event highlights as text arrays
ALTER TABLE IF EXISTS events
ADD COLUMN IF NOT EXISTS highlights TEXT[];

-- Add columns for included/excluded items
ALTER TABLE IF EXISTS events
ADD COLUMN IF NOT EXISTS included TEXT[];

ALTER TABLE IF EXISTS events
ADD COLUMN IF NOT EXISTS excluded TEXT[];

-- Add column for itinerary as JSONB to store structured itinerary data
ALTER TABLE IF EXISTS events
ADD COLUMN IF NOT EXISTS itinerary JSONB;

-- Add column for FAQs as JSONB to store question/answer pairs
ALTER TABLE IF EXISTS events
ADD COLUMN IF NOT EXISTS faqs JSONB;