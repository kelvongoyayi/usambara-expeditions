/*
  # Fix Admin Log Function and Record ID Type

  1. Changes
    - Update log_admin_action function to handle non-UUID record IDs
    - Fix admin_logs table to use TEXT type for record_id instead of UUID
    - Add better error handling to prevent function failures
    
  2. Details
    - Modify the function to not fail when record_id is not a valid UUID
    - Update table structure if needed to ensure record_id is TEXT type
    - Ensure logging works for both UUID and string identifiers
*/

-- First check if admin_logs table exists and if record_id is UUID type
DO $$ 
BEGIN
  -- Check if admin_logs table exists
  IF EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_schema = 'public' AND table_name = 'admin_logs'
  ) THEN
    -- Check if record_id column is UUID type
    IF EXISTS (
      SELECT FROM information_schema.columns 
      WHERE table_schema = 'public' AND table_name = 'admin_logs' 
      AND column_name = 'record_id' AND data_type = 'uuid'
    ) THEN
      -- Alter the column type to TEXT
      ALTER TABLE admin_logs ALTER COLUMN record_id TYPE TEXT;
    END IF;
  END IF;
END $$;

-- Update log_admin_action function to be more robust
CREATE OR REPLACE FUNCTION log_admin_action(
  action_type TEXT,
  table_name TEXT,
  record_id TEXT,
  details JSONB DEFAULT NULL
)
RETURNS VOID AS $$
BEGIN
  -- Insert the log entry with record_id as TEXT
  INSERT INTO admin_logs (
    action_type,
    table_name,
    record_id,
    details,
    user_id
  ) VALUES (
    action_type,
    table_name,
    record_id,
    details,
    auth.uid()
  );
EXCEPTION
  WHEN others THEN
    -- Log error to server log but don't fail the calling function
    RAISE NOTICE 'Error logging admin action: %', SQLERRM;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a test log entry with a string ID to verify it works
DO $$
BEGIN
  PERFORM log_admin_action(
    'test',
    'admin_logs',
    'test_string_id',
    jsonb_build_object('description', 'Testing string IDs in admin logs')
  );
EXCEPTION
  WHEN others THEN
    RAISE NOTICE 'Could not create test log: %', SQLERRM;
END
$$;