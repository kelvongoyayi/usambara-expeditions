/*
  # Create tours table

  1. New Tables
    - `tours`
      - `id` (uuid, primary key)
      - `title` (text)
      - `slug` (text, unique)
      - `description` (text)
      - `category` (text)
      - `location` (text)
      - `duration` (text)
      - `price` (numeric)
      - `rating` (numeric)
      - `image_url` (text)
      - `featured` (boolean)
      - `difficulty` (text)
      - `min_group_size` (integer)
      - `max_group_size` (integer)
      - `highlights` (text array)
      - `requirements` (text array)
      - `included` (text array)
      - `excluded` (text array)
      - `gallery` (text array)
      - `itinerary` (jsonb)
      - `faqs` (jsonb)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
  2. Security
    - Enable RLS on `tours` table
    - Add policies for public read access
    - Add policies for admin write access
*/

-- Create tours table
CREATE TABLE IF NOT EXISTS tours (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL,
  location TEXT NOT NULL,
  duration TEXT NOT NULL,
  price NUMERIC NOT NULL,
  rating NUMERIC DEFAULT 4.5,
  image_url TEXT NOT NULL,
  featured BOOLEAN DEFAULT false,
  difficulty TEXT,
  min_group_size INTEGER,
  max_group_size INTEGER,
  highlights TEXT[],
  requirements TEXT[],
  included TEXT[],
  excluded TEXT[],
  gallery TEXT[],
  itinerary JSONB,
  faqs JSONB,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE tours ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Public read access for tours"
  ON tours
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Admin insert access for tours"
  ON tours
  FOR INSERT
  TO authenticated
  WITH CHECK (is_admin());

CREATE POLICY "Admin update access for tours"
  ON tours
  FOR UPDATE
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admin delete access for tours"
  ON tours
  FOR DELETE
  TO authenticated
  USING (is_admin());