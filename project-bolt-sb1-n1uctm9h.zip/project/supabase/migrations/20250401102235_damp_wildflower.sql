/*
  # Add Group Size Columns to Tours Table

  1. Changes
    - Add min_group_size column
    - Add max_group_size column
    
  2. Details
    - Both columns are integers
    - Can be null since not all tours may have group size limits
    - Add check constraints to ensure valid ranges
*/

-- Add group size columns
ALTER TABLE tours 
ADD COLUMN IF NOT EXISTS min_group_size integer,
ADD COLUMN IF NOT EXISTS max_group_size integer;

-- Add check constraints
ALTER TABLE tours
ADD CONSTRAINT min_group_size_check CHECK (min_group_size >= 0),
ADD CONSTRAINT max_group_size_check CHECK (max_group_size >= min_group_size);

-- Add comment for documentation
COMMENT ON COLUMN tours.min_group_size IS 'Minimum number of participants required for the tour';
COMMENT ON COLUMN tours.max_group_size IS 'Maximum number of participants allowed for the tour';