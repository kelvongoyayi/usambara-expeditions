/*
  # Initial Schema for Usambara Expeditions

  1. New Tables
    - `profiles` - User profiles with admin status
    - `tours` - Adventure tour packages
    - `events` - Organized events
    - `destinations` - Locations and points of interest
    - `bookings` - User bookings for tours and events
    - `testimonials` - Customer reviews and ratings
    - `gallery_images` - Images for the gallery section

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users and admins
    - Create public access policies for read-only data

  3. Relationships
    - Link bookings to users and tours/events
    - Link testimonials to users
    - Link gallery images to tours, events, destinations
*/

-- Create profiles table (extended user info)
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  first_name TEXT,
  last_name TEXT,
  phone TEXT,
  avatar_url TEXT,
  is_admin BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create destinations table
CREATE TABLE IF NOT EXISTS destinations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  location TEXT NOT NULL,
  latitude FLOAT,
  longitude FLOAT,
  image_url TEXT,
  highlights TEXT[] DEFAULT '{}',
  best_time TEXT,
  climate TEXT,
  tour_types TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  created_by UUID REFERENCES profiles(id)
);

-- Create tours table
CREATE TABLE IF NOT EXISTS tours (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  duration INTEGER NOT NULL, -- In days
  category TEXT NOT NULL,
  location TEXT NOT NULL,
  destination_id UUID REFERENCES destinations(id),
  image_url TEXT,
  difficulty TEXT CHECK (difficulty IN ('easy', 'moderate', 'challenging')),
  max_participants INTEGER NOT NULL DEFAULT 15,
  min_participants INTEGER NOT NULL DEFAULT 2,
  highlights TEXT[] DEFAULT '{}',
  included TEXT[] DEFAULT '{}',
  excluded TEXT[] DEFAULT '{}',
  requirements TEXT[] DEFAULT '{}',
  featured BOOLEAN DEFAULT false,
  rating DECIMAL(2, 1) DEFAULT 0.0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  created_by UUID REFERENCES profiles(id)
);

-- Create tour itinerary table
CREATE TABLE IF NOT EXISTS tour_itinerary (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tour_id UUID NOT NULL REFERENCES tours(id) ON DELETE CASCADE,
  day_number INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  activities TEXT[] DEFAULT '{}',
  meals TEXT[] DEFAULT '{}',
  accommodation TEXT,
  distance TEXT,
  elevation TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE (tour_id, day_number)
);

-- Create events table
CREATE TABLE IF NOT EXISTS events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  event_type TEXT NOT NULL,
  location TEXT NOT NULL,
  destination_id UUID REFERENCES destinations(id),
  image_url TEXT,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  duration INTEGER NOT NULL, -- In days
  max_participants INTEGER NOT NULL DEFAULT 100,
  min_participants INTEGER NOT NULL DEFAULT 10,
  highlights TEXT[] DEFAULT '{}',
  included TEXT[] DEFAULT '{}',
  featured BOOLEAN DEFAULT false,
  rating DECIMAL(2, 1) DEFAULT 0.0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  created_by UUID REFERENCES profiles(id)
);

-- Create event schedule table
CREATE TABLE IF NOT EXISTS event_schedule (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  day_number INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  activities TEXT[] DEFAULT '{}',
  meals TEXT[] DEFAULT '{}',
  accommodation TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE (event_id, day_number)
);

-- Create bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_reference TEXT NOT NULL UNIQUE,
  user_id UUID NOT NULL REFERENCES profiles(id),
  tour_id UUID REFERENCES tours(id),
  event_id UUID REFERENCES events(id),
  booking_date TIMESTAMPTZ DEFAULT now(),
  travel_date DATE NOT NULL,
  adults INTEGER NOT NULL CHECK (adults >= 1),
  children INTEGER NOT NULL DEFAULT 0,
  total_price DECIMAL(10, 2) NOT NULL,
  status TEXT CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')) NOT NULL DEFAULT 'pending',
  payment_status TEXT CHECK (payment_status IN ('pending', 'partial', 'paid', 'refunded')) NOT NULL DEFAULT 'pending',
  special_requests TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  CONSTRAINT booking_target_check CHECK (
    (tour_id IS NOT NULL AND event_id IS NULL) OR
    (tour_id IS NULL AND event_id IS NOT NULL)
  )
);

-- Create testimonials table
CREATE TABLE IF NOT EXISTS testimonials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id),
  name TEXT NOT NULL,
  location TEXT NOT NULL,
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT NOT NULL,
  tour_id UUID REFERENCES tours(id),
  event_id UUID REFERENCES events(id),
  image_url TEXT,
  is_approved BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create gallery_images table
CREATE TABLE IF NOT EXISTS gallery_images (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  description TEXT,
  image_url TEXT NOT NULL,
  tour_id UUID REFERENCES tours(id),
  event_id UUID REFERENCES events(id),
  destination_id UUID REFERENCES destinations(id),
  alt_text TEXT,
  is_featured BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  created_by UUID REFERENCES profiles(id)
);

-- Create frequently asked questions table
CREATE TABLE IF NOT EXISTS faqs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  tour_id UUID REFERENCES tours(id),
  event_id UUID REFERENCES events(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  created_by UUID REFERENCES profiles(id)
);

-- Enable Row Level Security (RLS)
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE tours ENABLE ROW LEVEL SECURITY;
ALTER TABLE tour_itinerary ENABLE ROW LEVEL SECURITY;
ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_schedule ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE testimonials ENABLE ROW LEVEL SECURITY;
ALTER TABLE gallery_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE faqs ENABLE ROW LEVEL SECURITY;

-- SECURITY POLICIES

-- Profiles Policies
CREATE POLICY "Users can view their own profiles"
  ON profiles
  FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profiles"
  ON profiles
  FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Admins can view all profiles"
  ON profiles
  FOR SELECT
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

-- Destinations Policies
CREATE POLICY "Anyone can view destinations"
  ON destinations
  FOR SELECT
  TO authenticated, anon
  USING (true);

CREATE POLICY "Admins can insert destinations"
  ON destinations
  FOR INSERT
  WITH CHECK (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

CREATE POLICY "Admins can update destinations"
  ON destinations
  FOR UPDATE
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

CREATE POLICY "Admins can delete destinations"
  ON destinations
  FOR DELETE
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

-- Tours Policies
CREATE POLICY "Anyone can view tours"
  ON tours
  FOR SELECT
  TO authenticated, anon
  USING (true);

CREATE POLICY "Admins can insert tours"
  ON tours
  FOR INSERT
  WITH CHECK (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

CREATE POLICY "Admins can update tours"
  ON tours
  FOR UPDATE
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

CREATE POLICY "Admins can delete tours"
  ON tours
  FOR DELETE
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

-- Tour Itinerary Policies
CREATE POLICY "Anyone can view tour itineraries"
  ON tour_itinerary
  FOR SELECT
  TO authenticated, anon
  USING (true);

CREATE POLICY "Admins can manage tour itineraries"
  ON tour_itinerary
  FOR ALL
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

-- Events Policies
CREATE POLICY "Anyone can view events"
  ON events
  FOR SELECT
  TO authenticated, anon
  USING (true);

CREATE POLICY "Admins can insert events"
  ON events
  FOR INSERT
  WITH CHECK (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

CREATE POLICY "Admins can update events"
  ON events
  FOR UPDATE
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

CREATE POLICY "Admins can delete events"
  ON events
  FOR DELETE
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

-- Event Schedule Policies
CREATE POLICY "Anyone can view event schedules"
  ON event_schedule
  FOR SELECT
  TO authenticated, anon
  USING (true);

CREATE POLICY "Admins can manage event schedules"
  ON event_schedule
  FOR ALL
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

-- Bookings Policies
CREATE POLICY "Users can view their own bookings"
  ON bookings
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own bookings"
  ON bookings
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own bookings"
  ON bookings
  FOR UPDATE
  USING (auth.uid() = user_id AND status = 'pending');

CREATE POLICY "Admins can view all bookings"
  ON bookings
  FOR SELECT
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

CREATE POLICY "Admins can update all bookings"
  ON bookings
  FOR UPDATE
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

-- Testimonials Policies
CREATE POLICY "Anyone can view approved testimonials"
  ON testimonials
  FOR SELECT
  TO authenticated, anon
  USING (is_approved = true);

CREATE POLICY "Users can insert testimonials"
  ON testimonials
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own testimonials"
  ON testimonials
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all testimonials"
  ON testimonials
  FOR ALL
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

-- Gallery Images Policies
CREATE POLICY "Anyone can view gallery images"
  ON gallery_images
  FOR SELECT
  TO authenticated, anon
  USING (true);

CREATE POLICY "Admins can manage gallery images"
  ON gallery_images
  FOR ALL
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

-- FAQs Policies
CREATE POLICY "Anyone can view FAQs"
  ON faqs
  FOR SELECT
  TO authenticated, anon
  USING (true);

CREATE POLICY "Admins can manage FAQs"
  ON faqs
  FOR ALL
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE is_admin = true
    )
  );

-- Create functions

-- Function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND is_admin = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to automatically create a profile after signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email)
  VALUES (NEW.id, NEW.email);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to create profile after signup
CREATE OR REPLACE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_tours_slug ON tours(slug);
CREATE INDEX IF NOT EXISTS idx_events_slug ON events(slug);
CREATE INDEX IF NOT EXISTS idx_tours_category ON tours(category);
CREATE INDEX IF NOT EXISTS idx_events_event_type ON events(event_type);
CREATE INDEX IF NOT EXISTS idx_bookings_user_id ON bookings(user_id);
CREATE INDEX IF NOT EXISTS idx_bookings_tour_id ON bookings(tour_id);
CREATE INDEX IF NOT EXISTS idx_bookings_event_id ON bookings(event_id);
CREATE INDEX IF NOT EXISTS idx_testimonials_user_id ON testimonials(user_id);
CREATE INDEX IF NOT EXISTS idx_gallery_images_tour_id ON gallery_images(tour_id);
CREATE INDEX IF NOT EXISTS idx_gallery_images_event_id ON gallery_images(event_id);
CREATE INDEX IF NOT EXISTS idx_gallery_images_destination_id ON gallery_images(destination_id);