/*
  # Fix Infinite Recursion in Profiles RLS Policies

  1. Changes
    - Drop existing RLS policies on profiles table that cause recursion
    - Create new non-recursive policies for profiles table
    - Fix admin check function to avoid recursion
    
  2. Security
    - Maintain proper access control without recursion
    - Ensure users can only access their own data
    - Allow admins to access all profiles
*/

-- First drop any problematic policies that might be causing recursion
DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Admins can view all profiles" ON profiles;
DROP POLICY IF EXISTS "Admins can update all profiles" ON profiles;
DROP POLICY IF EXISTS "Users can view own profile or admins can view all" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile or admins can update any" ON profiles;
DROP POLICY IF EXISTS "Enable read access for users to own profile" ON profiles;
DROP POLICY IF EXISTS "Enable update access for users to own profile" ON profiles;
DROP POLICY IF EXISTS "Enable delete access for users to own profile" ON profiles;
DROP POLICY IF EXISTS "Public profiles are viewable by everyone" ON profiles;

-- Make sure RLS is enabled
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Create a direct, non-recursive policy for users to view their own profile
CREATE POLICY "Users can view own profile direct"
ON profiles
FOR SELECT
TO authenticated
USING (auth.uid() = id);

-- Create a direct, non-recursive policy for users to update their own profile
CREATE POLICY "Users can update own profile direct"
ON profiles
FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- Create a direct, non-recursive policy for admins to view all profiles
-- This uses a subquery instead of calling a function to avoid recursion
CREATE POLICY "Admins can view all profiles direct"
ON profiles
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND is_admin = true
  )
);

-- Create a direct, non-recursive policy for admins to update all profiles
CREATE POLICY "Admins can update all profiles direct"
ON profiles
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND is_admin = true
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND is_admin = true
  )
);

-- Create a direct, non-recursive policy for admins to delete profiles
CREATE POLICY "Admins can delete profiles direct"
ON profiles
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND is_admin = true
  )
);

-- Create a safe is_admin function that avoids recursion
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
DECLARE
  is_admin_user BOOLEAN;
BEGIN
  -- Direct query to avoid recursion
  SELECT p.is_admin INTO is_admin_user
  FROM profiles p
  WHERE p.id = auth.uid();
  
  -- Return result (or false if no result)
  RETURN COALESCE(is_admin_user, FALSE);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a function to check database connection
CREATE OR REPLACE FUNCTION check_database_connection()
RETURNS JSONB AS $$
DECLARE
  result JSONB;
BEGIN
  SELECT jsonb_build_object(
    'connected', true,
    'timestamp', now(),
    'database_version', current_setting('server_version')
  ) INTO result;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;