/*
  # Fix event_types table

  1. Changes
    - Check if table exists first
    - Drop table if exists with incompatible structure
    - Create table with text primary key instead of UUID
    - Add policies with IF NOT EXISTS clause

  2. Security
    - Enable RLS on `event_types` table
    - Add policies for authenticated users
*/

-- Check if table exists with UUID primary key
DO $$ 
BEGIN
  -- Drop the existing table if it has the wrong structure
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'event_types' 
    AND column_name = 'id' 
    AND data_type = 'uuid'
  ) THEN
    DROP TABLE event_types CASCADE;
  END IF;
END $$;

-- Create the table with text primary key
CREATE TABLE IF NOT EXISTS event_types (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text,
  icon text,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security if not already enabled
ALTER TABLE event_types ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they cause conflicts
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Anyone can read event types" ON event_types;
  DROP POLICY IF EXISTS "Only admins can modify event types" ON event_types;
EXCEPTION
  WHEN OTHERS THEN NULL;
END $$;

-- Create policies
CREATE POLICY "Anyone can read event types" 
  ON event_types
  FOR SELECT 
  USING (true);

CREATE POLICY "Only admins can modify event types" 
  ON event_types
  FOR ALL
  TO authenticated
  USING (true); -- For development, allow all authenticated users

-- Insert initial event types if the table is empty
INSERT INTO event_types (id, name, description, icon)
SELECT * FROM (
  VALUES 
    ('corporate', 'Corporate Event', 'Team building events and workshops for companies', 'briefcase'),
    ('adventure', 'Adventure Event', 'Outdoor adventure experiences and challenges', 'mountain'),
    ('education', 'Educational Program', 'Learning programs and educational tours', 'graduation-cap'),
    ('special', 'Special Occasion', 'Celebrations and special events', 'gift')
) AS data(id, name, description, icon)
WHERE NOT EXISTS (SELECT 1 FROM event_types LIMIT 1)
ON CONFLICT (id) DO NOTHING;