/*
  # Create destinations table

  1. New Tables
    - `destinations`
      - `id` (uuid, primary key)
      - `name` (text)
      - `slug` (text, unique)
      - `description` (text)
      - `image_url` (text)
      - `latitude` (numeric)
      - `longitude` (numeric)
      - `tour_types` (text array)
      - `highlights` (text array)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
  2. Security
    - Enable RLS on `destinations` table
    - Add policies for public read access
    - Add policies for admin write access
*/

-- Create destinations table
CREATE TABLE IF NOT EXISTS destinations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT NOT NULL,
  image_url TEXT NOT NULL,
  latitude NUMERIC NOT NULL,
  longitude NUMERIC NOT NULL,
  tour_types TEXT[],
  highlights TEXT[],
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE destinations ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Public read access for destinations"
  ON destinations
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Admin insert access for destinations"
  ON destinations
  FOR INSERT
  TO authenticated
  WITH CHECK (is_admin());

CREATE POLICY "Admin update access for destinations"
  ON destinations
  FOR UPDATE
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admin delete access for destinations"
  ON destinations
  FOR DELETE
  TO authenticated
  USING (is_admin());