/*
  # Create tour categories table and update tours schema

  1. New Tables
    - `tour_categories` - Stores tour category information
      - `id` (uuid, primary key)
      - `name` (text, not null) - Display name for the category
      - `slug` (text, not null, unique) - URL-friendly identifier
      - `description` (text) - Optional description
      - `icon` (text) - Optional icon name
      - `created_at` (timestamptz, default now())
  
  2. Changes
    - Update `tours` table to reference categories by ID
    - Add foreign key constraint from tours to categories
    - Add RLS policies for tour_categories
*/

-- Create tour categories table
CREATE TABLE IF NOT EXISTS tour_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  icon TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE tour_categories ENABLE ROW LEVEL SECURITY;

-- Default categories
INSERT INTO tour_categories (name, slug, description, icon) 
VALUES 
  ('Hiking', 'hiking', 'Guided hiking and trekking experiences through Tanzania\'s diverse landscapes', 'mountain'),
  ('Cycling', 'cycling', 'Cycling tours for all experience levels through scenic routes', 'bike'),
  ('Cultural', 'cultural', 'Immersive cultural experiences with local communities', 'users'),
  ('4x4 Expedition', '4x4', 'Off-road adventures through remote and scenic landscapes', 'truck'),
  ('Motocamping', 'motocamping', 'Motorcycle touring with camping experiences', 'tent'),
  ('School Tours', 'school', 'Educational trips for schools and learning institutions', 'school')
ON CONFLICT (slug) DO NOTHING;

-- Create foreign key in tours table if it doesn't exist already
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'tours' AND column_name = 'category_id'
  ) THEN
    -- Add category_id column to tours
    ALTER TABLE tours ADD COLUMN category_id UUID;
    
    -- Set default values for existing tours based on category string
    UPDATE tours t
    SET category_id = (SELECT id FROM tour_categories c WHERE c.slug = t.category)
    WHERE t.category IS NOT NULL;
    
    -- Add foreign key constraint
    ALTER TABLE tours ADD CONSTRAINT fk_tour_category 
    FOREIGN KEY (category_id) REFERENCES tour_categories(id);
  END IF;
END $$;

-- Create RLS policies for tour_categories
CREATE POLICY "Public can view tour_categories" ON tour_categories
  FOR SELECT USING (true);

CREATE POLICY "Admins can insert tour_categories" ON tour_categories
  FOR INSERT WITH CHECK (
    (SELECT is_admin FROM profiles WHERE id = auth.uid())
  );

CREATE POLICY "Admins can update tour_categories" ON tour_categories
  FOR UPDATE USING (
    (SELECT is_admin FROM profiles WHERE id = auth.uid())
  );

CREATE POLICY "Admins can delete tour_categories" ON tour_categories
  FOR DELETE USING (
    (SELECT is_admin FROM profiles WHERE id = auth.uid())
  );