/*
  # Admin Profiles Setup and Security

  1. Changes
    - Add is_admin field to profiles table
    - Create functions for admin checks
    - Fix profile policies for admin access
    - Enable proper admin authorization

  2. Security
    - Enable admin access to protected resources
    - Ensure proper data isolation
    - Add policies for admin management
*/

-- First, check if is_admin column exists in profiles, add if not
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'is_admin'
  ) THEN
    ALTER TABLE profiles ADD COLUMN is_admin BOOLEAN DEFAULT FALSE;
  END IF;
END $$;

-- Create admin check function
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() AND is_admin = TRUE
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to make a user an admin
CREATE OR REPLACE FUNCTION make_admin(target_user_id uuid)
RETURNS BOOLEAN AS $$
BEGIN
  -- Check if the current user is an admin
  IF NOT is_admin() THEN
    RETURN false;
  END IF;

  -- Update user to make them an admin
  UPDATE profiles
  SET is_admin = TRUE,
      updated_at = now()
  WHERE id = target_user_id;

  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to create first admin
CREATE OR REPLACE FUNCTION create_first_admin(admin_email text)
RETURNS BOOLEAN AS $$
DECLARE
  admin_user_id uuid;
BEGIN
  -- Check if any admins exist
  IF EXISTS (SELECT 1 FROM profiles WHERE is_admin = TRUE) THEN
    RETURN false;
  END IF;

  -- Get user id from auth.users
  SELECT id INTO admin_user_id
  FROM auth.users
  WHERE email = admin_email;

  IF admin_user_id IS NULL THEN
    RETURN false;
  END IF;

  -- Make user an admin
  UPDATE profiles
  SET is_admin = TRUE,
      updated_at = now()
  WHERE id = admin_user_id;

  RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update profiles policies
DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;

-- Allow users to view their own profile or admins to view all profiles
CREATE POLICY "Users can view own profile or admins can view all"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = id OR is_admin()
  );

-- Allow users to update their own profile or admins to update any profile
CREATE POLICY "Users can update own profile or admins can update any"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = id OR is_admin()
  );

-- Add RLS policies for admin-only tables (tours, events, bookings)
DO $$ 
BEGIN
  -- Tours table
  IF EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'tours') THEN
    DROP POLICY IF EXISTS "Admins can manage tours" ON tours;
    CREATE POLICY "Admins can manage tours"
      ON tours
      USING (is_admin());
  END IF;

  -- Events table
  IF EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'events') THEN
    DROP POLICY IF EXISTS "Admins can manage events" ON events;
    CREATE POLICY "Admins can manage events"
      ON events
      USING (is_admin());
  END IF;

  -- Bookings table
  IF EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'bookings') THEN
    DROP POLICY IF EXISTS "Admins can manage all bookings" ON bookings;
    CREATE POLICY "Admins can manage all bookings"
      ON bookings
      USING (is_admin());
      
    DROP POLICY IF EXISTS "Users can view own bookings" ON bookings;
    CREATE POLICY "Users can view own bookings"
      ON bookings
      FOR SELECT
      TO authenticated
      USING (
        user_id = auth.uid() OR is_admin()
      );
  END IF;
END $$;