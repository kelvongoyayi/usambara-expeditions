/*
  # Create bookings table

  1. New Tables
    - `bookings`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles.id)
      - `booking_reference` (text, unique)
      - `booking_date` (timestamptz)
      - `travel_date` (timestamptz)
      - `customer_name` (text)
      - `customer_email` (text)
      - `tour_id` (uuid, references tours.id)
      - `event_id` (uuid, references events.id)
      - `total_amount` (numeric)
      - `status` (text)
      - `payment_status` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
  2. Security
    - Enable RLS on `bookings` table
    - Add policies for users to read their own bookings
    - Add policies for admins to read all bookings
*/

-- Create bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id),
  booking_reference TEXT UNIQUE NOT NULL,
  booking_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  travel_date TIMESTAMPTZ,
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  tour_id UUID REFERENCES tours(id),
  event_id UUID REFERENCES events(id),
  total_amount NUMERIC NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  payment_status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  -- Either tour_id or event_id must be provided, but not both
  CONSTRAINT tour_or_event_check CHECK (
    (tour_id IS NOT NULL AND event_id IS NULL) OR
    (tour_id IS NULL AND event_id IS NOT NULL)
  )
);

-- Enable Row Level Security
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own bookings"
  ON bookings
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own bookings"
  ON bookings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can read all bookings"
  ON bookings
  FOR SELECT
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admins can update all bookings"
  ON bookings
  FOR UPDATE
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admins can delete bookings"
  ON bookings
  FOR DELETE
  TO authenticated
  USING (is_admin());