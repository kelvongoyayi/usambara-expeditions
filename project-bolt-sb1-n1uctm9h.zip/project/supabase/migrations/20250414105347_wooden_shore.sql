/*
  # Fix Policy Conflicts and Update Bookings Policies
  
  1. Changes
    - Check for existing policies before attempting to create new ones
    - Update policies to properly handle anonymous bookings
    - Fix the error with duplicate policy names
  
  2. Security
    - Maintain proper access control
    - Allow public insertion of bookings
    - Ensure admins can see all bookings
*/

-- Drop all existing bookings policies to ensure clean slate
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Allow public booking creation" ON bookings;
  DROP POLICY IF EXISTS "Users can view their own bookings" ON bookings;
  DROP POLICY IF EXISTS "Admins can manage all bookings" ON bookings;
  DROP POLICY IF EXISTS "Users can create their own bookings" ON bookings;
  DROP POLICY IF EXISTS "Users can insert own bookings" ON bookings;
  DROP POLICY IF EXISTS "Authenticated users can create bookings" ON bookings;
END $$;

-- First check if user_id is required and make it optional if so
DO $$ 
BEGIN
  -- Check if the column is not null
  IF EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'bookings' 
    AND column_name = 'user_id' 
    AND is_nullable = 'NO'
  ) THEN
    -- Alter column to allow NULL values
    ALTER TABLE bookings ALTER COLUMN user_id DROP NOT NULL;
  END IF;
END $$;

-- Enable RLS on bookings table
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Create policies with unique names to avoid conflicts
CREATE POLICY "bookings_insert_public_20250414"
  ON bookings
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "bookings_select_authenticated_20250414"
  ON bookings
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    auth.uid() IN (SELECT id FROM profiles WHERE is_admin = true)
  );

CREATE POLICY "bookings_admin_access_20250414"
  ON bookings
  FOR ALL
  TO authenticated
  USING (
    auth.uid() IN (SELECT id FROM profiles WHERE is_admin = true)
  );

-- Log that this migration was executed
INSERT INTO admin_logs (
  action_type,
  table_name,
  record_id,
  details
) VALUES (
  'migration',
  'bookings',
  'fix_policy_conflicts',
  jsonb_build_object(
    'description', 'Fixed policy conflicts for bookings table',
    'timestamp', now()
  )
);