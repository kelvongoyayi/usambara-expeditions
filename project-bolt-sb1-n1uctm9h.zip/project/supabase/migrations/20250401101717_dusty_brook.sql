/*
  # Fix admin stats function JSON aggregation

  1. Changes
    - Drop existing get_admin_stats function
    - Recreate function with correct JSON aggregation syntax
    - Fix ORDER BY and LIMIT usage in subqueries
  
  2. Details
    - Uses subquery for proper ordering and limiting before json_agg
    - Maintains existing security and permissions
    - Preserves all existing functionality
*/

-- First drop the existing function
DROP FUNCTION IF EXISTS get_admin_stats();

-- Recreate the function with correct JSON aggregation syntax
CREATE OR REPLACE FUNCTION get_admin_stats()
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    result json;
BEGIN
    WITH booking_stats AS (
        SELECT 
            COUNT(*) as total_bookings,
            COALESCE(SUM(CASE WHEN b.status = 'confirmed' AND b.payment_status = 'paid' THEN b.total_amount ELSE 0 END), 0) as total_revenue,
            (
                SELECT json_agg(t)
                FROM (
                    SELECT 
                        b2.id,
                        b2.booking_reference,
                        p.first_name || ' ' || p.last_name as customer_name,
                        p.email as customer_email,
                        b2.total_amount,
                        b2.status,
                        b2.created_at
                    FROM bookings b2
                    LEFT JOIN auth.users u ON b2.user_id = u.id
                    LEFT JOIN profiles p ON u.id = p.id
                    ORDER BY b2.created_at DESC
                    LIMIT 5
                ) t
            ) as recent_bookings
        FROM bookings b
        LEFT JOIN auth.users u ON b.user_id = u.id
        LEFT JOIN profiles p ON u.id = p.id
    ),
    tour_stats AS (
        SELECT 
            COUNT(*) as total_tours,
            (
                SELECT json_agg(t)
                FROM (
                    SELECT 
                        t2.id,
                        t2.title,
                        (
                            SELECT COUNT(*) 
                            FROM bookings b 
                            WHERE b.tour_id = t2.id
                        ) as bookings_count
                    FROM tours t2
                    ORDER BY t2.created_at DESC
                    LIMIT 5
                ) t
            ) as popular_tours
        FROM tours t
    ),
    event_stats AS (
        SELECT COUNT(*) as total_events
        FROM events
    ),
    user_stats AS (
        SELECT COUNT(*) as total_users
        FROM auth.users
    )
    SELECT 
        json_build_object(
            'total_bookings', bs.total_bookings,
            'total_revenue', bs.total_revenue,
            'total_tours', ts.total_tours,
            'total_events', es.total_events,
            'total_users', us.total_users,
            'recent_bookings', COALESCE(bs.recent_bookings, '[]'::json),
            'popular_tours', COALESCE(ts.popular_tours, '[]'::json)
        ) INTO result
    FROM booking_stats bs
    CROSS JOIN tour_stats ts
    CROSS JOIN event_stats es
    CROSS JOIN user_stats us;

    RETURN result;
END;
$$;