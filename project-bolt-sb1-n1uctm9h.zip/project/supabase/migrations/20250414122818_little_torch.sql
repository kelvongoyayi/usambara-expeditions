/*
  # Fix Bookings Column Name Mismatch
  
  1. Changes
    - Rename total_amount to total_price in bookings table if needed
    - Ensure total_price column exists and is not null
    - Update existing bookings with null total_price
  
  2. Purpose
    - Fix the error: "column "total_amount" of relation "bookings" does not exist"
    - Ensure consistent column naming across the application
    - Prevent future errors with bookings creation
*/

-- Check if total_amount exists but total_price doesn't
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'bookings' AND column_name = 'total_amount'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'bookings' AND column_name = 'total_price'
  ) THEN
    -- Rename total_amount to total_price
    ALTER TABLE bookings RENAME COLUMN total_amount TO total_price;
  END IF;
END $$;

-- Check if total_price exists but total_amount doesn't
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'bookings' AND column_name = 'total_price'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'bookings' AND column_name = 'total_amount'
  ) THEN
    -- Make sure total_price is not null
    UPDATE bookings SET total_price = 0 WHERE total_price IS NULL;
    
    -- Add not null constraint if it doesn't exist
    ALTER TABLE bookings ALTER COLUMN total_price SET NOT NULL;
  END IF;
END $$;

-- If both columns exist, consolidate them
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'bookings' AND column_name = 'total_amount'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'bookings' AND column_name = 'total_price'
  ) THEN
    -- Update total_price with total_amount where total_price is null
    UPDATE bookings 
    SET total_price = total_amount 
    WHERE total_price IS NULL AND total_amount IS NOT NULL;
    
    -- Update total_amount with total_price where total_amount is null
    UPDATE bookings 
    SET total_amount = total_price 
    WHERE total_amount IS NULL AND total_price IS NOT NULL;
    
    -- Drop total_amount column
    ALTER TABLE bookings DROP COLUMN total_amount;
    
    -- Make sure total_price is not null
    UPDATE bookings SET total_price = 0 WHERE total_price IS NULL;
    ALTER TABLE bookings ALTER COLUMN total_price SET NOT NULL;
  END IF;
END $$;

-- If neither column exists, create total_price
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'bookings' AND column_name = 'total_amount'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'bookings' AND column_name = 'total_price'
  ) THEN
    -- Add total_price column
    ALTER TABLE bookings ADD COLUMN total_price DECIMAL(10,2) NOT NULL DEFAULT 0;
  END IF;
END $$;