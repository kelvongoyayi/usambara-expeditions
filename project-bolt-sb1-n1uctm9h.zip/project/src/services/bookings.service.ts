import { supabase } from '../lib/supabase';


// IMPLEMENTATION STATUS: PARTIAL
// This service currently uses mock data but has the right interfaces.
// It's actively used in the UI components but will need to be updated
// to use Supabase queries when connecting to the backend.
export interface BookingDetails {
  id: string;
  user_id?: string;
  booking_reference: string;
  booking_date: string;
  travel_date?: string;
  customer_name: string;
  customer_email: string;
  tour_id?: string;
  event_id?: string;
  total_price: number;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  payment_status: 'pending' | 'paid' | 'refunded' | 'failed';
  adults?: number;
  children?: number;
  special_requests?: string;
  created_at: string;
  updated_at: string;
  tourTitle?: string;
  eventTitle?: string;
}

export const bookingsService = {
  async getBookings(): Promise<{ data: BookingDetails[] | null, error: any }> {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(`
          *,
          tours(title),
          events(title)
        `)
        .order('booking_date', { ascending: false });
      
      if (error) {
        console.error('Error fetching bookings:', error);
        return { data: null, error };
      }
      
      // Transform the data to match our BookingDetails interface
      const transformedData = (data || []).map(booking => ({
        ...booking,
        tourTitle: booking.tours?.title,
        eventTitle: booking.events?.title
      }));
      
      return { data: transformedData, error: null };
    } catch (error) {
      console.error('Error fetching bookings:', error);
      return { data: null, error };
    }
  },

  async getBookingById(id: string): Promise<BookingDetails | null> {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(`
          *,
          tours(title),
          events(title)
        `)
        .eq('id', id)
        .single();
      
      if (error) throw error;
      
      return {
        ...data,
        tourTitle: data.tours?.title,
        eventTitle: data.events?.title
      };
    } catch (error) {
      console.error(`Error fetching booking with id ${id}:`, error);
      return null;
    }
  },

  async getUserBookings(userId: string): Promise<BookingDetails[]> {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(`
          *,
          tours(title),
          events(title)
        `)
        .eq('user_id', userId)
        .order('booking_date', { ascending: false });
      
      if (error) throw error;
      
      return (data || []).map(booking => ({
        ...booking,
        tourTitle: booking.tours?.title,
        eventTitle: booking.events?.title
      }));
    } catch (error) {
      console.error(`Error fetching bookings for user ${userId}:`, error);
      return [];
    }
  },

  async createBooking(booking: Omit<BookingDetails, 'id' | 'created_at' | 'updated_at'>): Promise<BookingDetails | null> {
    try {
      // Generate a booking reference if not provided
      const bookingReference = booking.booking_reference || 
        `UE-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;
      
      // Add timestamps to the booking data
      const bookingData = {
        ...booking,
        booking_reference: bookingReference,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      // Remove user_id if it's undefined to avoid RLS issues
      if (bookingData.user_id === undefined) {
        delete bookingData.user_id;
      }
      
      const { data, error } = await supabase
        .from('bookings')
        .insert([bookingData])
        .select()
        .single();
      
      if (error) {
        console.error('Error creating booking:', error);
        // If there's an error but we have a booking reference, return a minimal booking object
        if (bookingReference) {
          return {
            id: 'pending',
            booking_reference: bookingReference,
            booking_date: new Date().toISOString(),
            customer_name: booking.customer_name,
            customer_email: booking.customer_email,
            total_price: booking.total_price,
            status: 'pending',
            payment_status: 'pending',
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString()
          };
        }
        throw error;
      }
      
      return data;
    } catch (error) {
      console.error('Error creating booking:', error);
      throw error;
    }
  },

  async updateBooking(
    id: string, 
    booking: Partial<Omit<BookingDetails, 'id' | 'created_at' | 'updated_at'>>
  ): Promise<BookingDetails | null> {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .update({ ...booking, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error(`Error updating booking with id ${id}:`, error);
      return null;
    }
  },

  async updateBookingStatus(id: string, status: BookingDetails['status']): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ 
          status, 
          updated_at: new Date().toISOString() 
        })
        .eq('id', id);
      
      if (error) throw error;
      return true;
    } catch (error) {
      console.error(`Error updating status for booking ${id}:`, error);
      return false;
    }
  },

  async updatePaymentStatus(id: string, paymentStatus: BookingDetails['payment_status']): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ 
          payment_status: paymentStatus, 
          updated_at: new Date().toISOString() 
        })
        .eq('id', id);
      
      if (error) throw error;
      return true;
    } catch (error) {
      console.error(`Error updating payment status for booking ${id}:`, error);
      return false;
    }
  },

  async deleteBooking(id: string): Promise<boolean> {
    try {
      const { error } = await supabase.from('bookings').delete().eq('id', id);
      
      if (error) throw error;
      return true;
    } catch (error) {
      console.error(`Error deleting booking with id ${id}:`, error);
      return false;
    }
  },

  calculateTotalRevenue(bookings: BookingDetails[]): number {
    return bookings.reduce((sum, booking) => {
      // Only count confirmed or completed bookings with paid status
      if (
        (booking.status === 'confirmed' || booking.status === 'completed') &&
        booking.payment_status === 'paid'
      ) {
        return sum + Number(booking.total_price);
      }
      return sum;
    }, 0);
  }
};