import { supabase } from '../lib/supabase';
import type { FeaturedItem, DayItinerary, FAQ } from '../types/tours';


// IMPLEMENTATION STATUS: PARTIAL
// This service currently uses mock data but has the right interfaces.
// It's actively used in the UI components but will need to be updated
// to use Supabase queries when connecting to the backend.
export interface Tour {
  id: string;
  title: string;
  slug: string;
  duration: string;
  price: number;
  location: string;
  image_url: string;
  rating: number;
  description: string;
  category: string;
  created_at: string;
  updated_at: string;
  featured: boolean;
  difficulty?: string;
  min_group_size?: number;
  max_group_size?: number;
  start_location?: string;
  end_location?: string;
  highlights?: string[];
  requirements?: string[];
  included?: string[];
  excluded?: string[];
  gallery?: string[];
  itinerary?: DayItinerary[];
  faqs?: FAQ[];
}

export const toursService = {
  async getTours(): Promise<Tour[]> {
    try {
      const { data, error } = await supabase
        .from('tours')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      return data || [];
    } catch (error) {
      console.error('Error fetching tours:', error);
      return [];
    }
  },

  async getTourById(id: string): Promise<Tour | null> {
    try {
      const { data, error } = await supabase
        .from('tours')
        .select('*')
        .eq('id', id)
        .single();
      
      if (error) throw error;
      
      return data;
    } catch (error) {
      console.error(`Error fetching tour with id ${id}:`, error);
      return null;
    }
  },

  async getToursByCategory(category: string): Promise<Tour[]> {
    try {
      let query = supabase
        .from('tours')
        .select('*');
      
      if (category && category !== 'all') {
        query = query.eq('category', category);
      }
      
      const { data, error } = await query.order('created_at', { ascending: false });
      
      if (error) throw error;
      
      return data || [];
    } catch (error) {
      console.error(`Error fetching tours in category ${category}:`, error);
      return [];
    }
  },

  async getFeaturedTours(): Promise<Tour[]> {
    try {
      const { data, error } = await supabase
        .from('tours')
        .select('*')
        .eq('featured', true)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      return data || [];
    } catch (error) {
      console.error('Error fetching featured tours:', error);
      return [];
    }
  },

  async createTour(tour: Omit<Tour, 'id' | 'created_at' | 'updated_at'>): Promise<Tour | null> {
    try {
      const now = new Date().toISOString();
      
      // Convert price to numeric if it's a string
      const tourData = {
        ...tour,
        price: typeof tour.price === 'string' ? parseFloat(tour.price) : tour.price,
        rating: typeof tour.rating === 'string' ? parseFloat(tour.rating) : tour.rating,
        min_group_size: tour.min_group_size ? Number(tour.min_group_size) : undefined,
        max_group_size: tour.max_group_size ? Number(tour.max_group_size) : undefined
      };
      
      const { data, error } = await supabase
        .from('tours')
        .insert([{
          ...tourData,
          created_at: now,
          updated_at: now
        }])
        .select()
        .single();
      
      if (error) throw error;
      
      return data;
    } catch (error) {
      console.error('Error creating tour:', error);
      return null;
    }
  },

  async updateTour(id: string, tour: Partial<Omit<Tour, 'id' | 'created_at' | 'updated_at'>>): Promise<Tour | null> {
    try {
      // Convert price to numeric if it's a string
      const tourData = {
        ...tour,
        price: typeof tour.price === 'string' ? parseFloat(tour.price) : tour.price,
        rating: typeof tour.rating === 'string' ? parseFloat(tour.rating) : tour.rating,
        min_group_size: tour.min_group_size ? Number(tour.min_group_size) : undefined,
        max_group_size: tour.max_group_size ? Number(tour.max_group_size) : undefined
      };
      
      const { data, error } = await supabase
        .from('tours')
        .update({
          ...tourData,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      
      return data;
    } catch (error) {
      console.error(`Error updating tour with id ${id}:`, error);
      return null;
    }
  },

  async deleteTour(id: string): Promise<boolean> {
    try {
      const { error } = await supabase.from('tours').delete().eq('id', id);
      
      if (error) throw error;
      
      return true;
    } catch (error) {
      console.error(`Error deleting tour with id ${id}:`, error);
      return false;
    }
  },
  
  async getTourCategories(): Promise<{id: string; name: string}[]> {
    try {
      const { data, error } = await supabase
        .from('tour_categories')
        .select('id, name')
        .order('name', { ascending: true });
      
      if (error) throw error;
      
      return data || [];
    } catch (error) {
      console.error('Error fetching tour categories:', error);
      // Return default categories if API call fails
      return [
        { id: 'hiking', name: 'Hiking' },
        { id: 'cycling', name: 'Cycling' },
        { id: 'cultural', name: 'Cultural' },
        { id: '4x4', name: '4x4 Expedition' },
        { id: 'motocamping', name: 'Motocamping' },
        { id: 'school', name: 'School Tours' }
      ];
    }
  },

  // Convert database Tour to FeaturedItem format
  toFeaturedItem(tour: Tour): FeaturedItem {
    return {
      id: tour.id,
      title: tour.title,
      duration: tour.duration,
      price: tour.price,
      location: tour.location,
      image: tour.image_url,
      rating: tour.rating,
      description: tour.description,
      category: tour.category as any,
      featured: tour.featured,
      type: 'tour',
      difficulty: tour.difficulty as any,
      groupSize: tour.min_group_size && tour.max_group_size ? 
        { min: tour.min_group_size, max: tour.max_group_size } : undefined,
      startLocation: tour.start_location,
      endLocation: tour.end_location,
      highlights: tour.highlights,
      requirements: tour.requirements,
      gallery: tour.gallery,
      included: tour.included,
      excluded: tour.excluded,
      itinerary: tour.itinerary,
      faqs: tour.faqs
    };
  }
};