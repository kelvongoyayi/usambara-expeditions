import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Plus, Search, Filter, Grid, List, Loader, Calendar, Users, MapPin, Eye, Edit, Trash, Check, X,
  Clock, DollarSign, Star, ChevronRight, ChevronLeft
} from 'lucide-react';
import AdminLayout from '../../../components/admin/AdminLayout';
import { useAuth } from '../../../contexts/AuthContext';
import EventList from '../../../components/admin/Events/EventList';
import { eventsService, Event } from '../../../services/events.service';
import toast from 'react-hot-toast';

const AdminEvents: React.FC = () => {
  const { isAdmin } = useAuth();
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [viewMode, setViewMode] = useState<'card' | 'table'>('card');
  const [scrollContainerRef, setScrollContainerRef] = useState<HTMLDivElement | null>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  useEffect(() => {
    const fetchEvents = async () => {
      setLoading(true);
      setError(null);
      
      try {
        const eventsData = await eventsService.getEvents();
        setEvents(eventsData);
      } catch (err) {
        console.error('Error fetching events:', err);
        setError('Failed to load events. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchEvents();
  }, []);

  // Update scroll indicators
  const checkScrollable = () => {
    if (scrollContainerRef) {
      setCanScrollLeft(scrollContainerRef.scrollLeft > 0);
      setCanScrollRight(
        scrollContainerRef.scrollLeft < (scrollContainerRef.scrollWidth - scrollContainerRef.clientWidth - 10)
      );
    }
  };

  // Filter events based on search and filter type
  const filteredEvents = events.filter(event => {
    const matchesSearch = event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          event.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          event.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = filterType === 'all' || event.event_type === filterType;
    
    return matchesSearch && matchesType;
  });

  // Extract unique event types for filter dropdown
  const eventTypes = ['all', ...new Set(events.map(event => event.event_type))];

  // Handle event deletion
  const handleDeleteEvent = async (id: string, title: string) => {
    if (!window.confirm(`Are you sure you want to delete the event "${title}"? This action cannot be undone.`)) {
      return;
    }
    
    try {
      setLoading(true);
      const success = await eventsService.deleteEvent(id);
      
      if (success) {
        // Remove the deleted event from the state
        setEvents(prevEvents => prevEvents.filter(event => event.id !== id));
        toast.success('Event successfully deleted');
      } else {
        throw new Error('Failed to delete event');
      }
    } catch (err) {
      console.error('Error deleting event:', err);
      toast.error('Failed to delete event. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Scroll the events list horizontally
  const scrollEvents = (direction: 'left' | 'right') => {
    if (scrollContainerRef) {
      const scrollAmount = direction === 'left' ? -300 : 300;
      scrollContainerRef.scrollBy({
        left: scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  // Set the ref and add scroll listener
  const setRefAndCheckScroll = (ref: HTMLDivElement | null) => {
    if (ref) {
      setScrollContainerRef(ref);
      ref.addEventListener('scroll', checkScrollable);
      
      // Initial check
      checkScrollable();
      
      // Check on window resize too
      window.addEventListener('resize', checkScrollable);
      
      return () => {
        ref.removeEventListener('scroll', checkScrollable);
        window.removeEventListener('resize', checkScrollable);
      };
    }
  };

  // Format date for display
  const formatDate = (startDate: string, endDate: string): string => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    // If same date
    if (start.toDateString() === end.toDateString()) {
      return new Date(startDate).toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
      });
    }
    
    // If same month and year
    if (start.getMonth() === end.getMonth() && start.getFullYear() === end.getFullYear()) {
      return `${start.toLocaleDateString('en-US', { month: 'short' })} ${start.getDate()}-${end.getDate()}, ${end.getFullYear()}`;
    }
    
    // Different months
    return `${start.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${end.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;
  };

  return (
    <AdminLayout>
      <div className="mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Events Management</h1>
            <p className="text-sm text-gray-500 mt-1">
              Manage all your upcoming and past events
            </p>
          </div>
          
          <div className="flex space-x-3">
            <Link 
              to="/admin/events/create" 
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-accent-500 hover:bg-accent-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-500"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add New Event
            </Link>
            <Link
              to="/admin/events/types"
              className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-500"
            >
              Manage Event Types
            </Link>
          </div>
        </div>
      </div>

      {/* Search, Filter, and View Toggle */}
      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 mb-6">
        <div className="flex flex-col md:flex-row md:items-center space-y-4 md:space-y-0 md:space-x-4">
          {/* Search */}
          <div className="flex-1 min-w-0 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search events by name, location or description..."
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-accent-500 focus:border-accent-500 sm:text-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          {/* Event Type Filter */}
          <div className="w-full md:w-48 flex-shrink-0">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter className="h-5 w-5 text-gray-400" />
              </div>
              <select
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white focus:outline-none focus:ring-accent-500 focus:border-accent-500 sm:text-sm"
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
              >
                {eventTypes.map(type => (
                  <option key={type} value={type}>
                    {type === 'all' ? 'All Event Types' : type.charAt(0).toUpperCase() + type.slice(1)}
                  </option>
                ))}
              </select>
            </div>
          </div>
          
          {/* Event Count */}
          <div className="flex-shrink-0 md:ml-4 text-sm text-gray-600">
            {loading ? (
              <div className="flex items-center">
                <Loader className="w-4 h-4 mr-2 animate-spin" />
                Loading...
              </div>
            ) : (
              <span>
                {filteredEvents.length} event{filteredEvents.length !== 1 ? 's' : ''}
              </span>
            )}
          </div>
          
          {/* View Toggles */}
          <div className="flex">
            <button
              type="button"
              onClick={() => setViewMode('card')}
              className={`p-2 rounded-l-md border ${
                viewMode === 'card' 
                  ? 'bg-accent-50 border-accent-500 text-accent-700' 
                  : 'border-gray-300 text-gray-500 hover:bg-gray-50'
              }`}
              title="Card View"
            >
              <Grid className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`p-2 rounded-r-md border-t border-r border-b ${
                viewMode === 'table' 
                  ? 'bg-accent-50 border-accent-500 text-accent-700' 
                  : 'border-gray-300 text-gray-500 hover:bg-gray-50'
              }`}
              title="Table View"
            >
              <List className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 text-red-800 p-4 rounded-md mb-6">
          {error}
        </div>
      )}

      {/* Event Cards View */}
      {viewMode === 'card' && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden mb-8">
          <div className="p-6 relative">
            {/* Scroll Indicators */}
            {canScrollLeft && (
              <button
                onClick={() => scrollEvents('left')}
                className="absolute left-0 top-1/2 transform -translate-y-1/2 bg-white rounded-full p-2 shadow-lg z-10 border border-gray-200"
                aria-label="Scroll left"
              >
                <ChevronLeft className="w-5 h-5 text-gray-600" />
              </button>
            )}
            
            {canScrollRight && (
              <button
                onClick={() => scrollEvents('right')}
                className="absolute right-0 top-1/2 transform -translate-y-1/2 bg-white rounded-full p-2 shadow-lg z-10 border border-gray-200"
                aria-label="Scroll right"
              >
                <ChevronRight className="w-5 h-5 text-gray-600" />
              </button>
            )}
            
            {loading && filteredEvents.length === 0 ? (
              <div className="flex items-center justify-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-accent-600 mb-4"></div>
              </div>
            ) : filteredEvents.length > 0 ? (
              <div 
                className="flex overflow-x-auto gap-4 pb-4 scrollbar-hide"
                style={{ scrollbarWidth: 'none' }}
                ref={setRefAndCheckScroll}
              >
                {filteredEvents.map(event => (
                  <div 
                    key={event.id} 
                    className="min-w-[320px] max-w-[320px] bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden flex flex-col hover:shadow-md transition-all duration-200"
                  >
                    <div className="h-48 overflow-hidden relative">
                      <img
                        src={event.image_url || 'https://via.placeholder.com/300x150?text=No+Image'}
                        alt={event.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-0 right-0 m-2">
                        <span className="px-2.5 py-1 text-xs font-medium rounded-full bg-accent-100 text-accent-800">
                          {event.event_type.charAt(0).toUpperCase() + event.event_type.slice(1)}
                        </span>
                      </div>
                      {event.featured && (
                        <div className="absolute top-0 left-0 m-2">
                          <span className="px-2.5 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">
                            Featured
                          </span>
                        </div>
                      )}
                    </div>

                    <div className="p-4 flex-grow flex flex-col">
                      <h3 className="font-bold text-lg text-gray-900 line-clamp-1">{event.title}</h3>
                      
                      <div className="mt-3 space-y-1.5">
                        <div className="flex items-center text-sm text-gray-600">
                          <Calendar className="w-4 h-4 mr-1.5 text-accent-500 flex-shrink-0" />
                          <span>{formatDate(event.start_date, event.end_date)}</span>
                        </div>
                        
                        <div className="flex items-center text-sm text-gray-600">
                          <MapPin className="w-4 h-4 mr-1.5 text-accent-500 flex-shrink-0" />
                          <span className="truncate">{event.location}</span>
                        </div>
                        
                        <div className="flex items-center text-sm text-gray-600">
                          <Clock className="w-4 h-4 mr-1.5 text-accent-500 flex-shrink-0" />
                          <span>{event.duration}</span>
                        </div>
                        
                        <div className="flex items-center text-sm text-gray-600">
                          <DollarSign className="w-4 h-4 mr-1.5 text-accent-500 flex-shrink-0" />
                          <span>${Number(event.price).toFixed(2)}</span>
                        </div>
                        
                        {event.min_attendees && event.max_attendees && (
                          <div className="flex items-center text-sm text-gray-600">
                            <Users className="w-4 h-4 mr-1.5 text-accent-500 flex-shrink-0" />
                            <span>{event.min_attendees}-{event.max_attendees} attendees</span>
                          </div>
                        )}
                      </div>
                      
                      <div className="mt-4 flex justify-between items-center pt-3 border-t border-gray-100">
                        <div className="flex space-x-1">
                          <Link 
                            to={`/event/${event.id}`} 
                            className="text-indigo-600 hover:text-indigo-900 p-1.5 rounded-full hover:bg-indigo-50 transition-colors"
                            title="View"
                            target="_blank"
                          >
                            <Eye className="w-4 h-4" />
                          </Link>
                          <Link 
                            to={`/admin/events/edit/${event.id}`} 
                            className="text-yellow-600 hover:text-yellow-900 p-1.5 rounded-full hover:bg-yellow-50 transition-colors"
                            title="Edit"
                          >
                            <Edit className="w-4 h-4" />
                          </Link>
                          <button 
                            className="text-red-600 hover:text-red-900 p-1.5 rounded-full hover:bg-red-50 transition-colors"
                            title="Delete"
                            onClick={() => handleDeleteEvent(event.id, event.title)}
                          >
                            <Trash className="w-4 h-4" />
                          </button>
                        </div>
                        
                        <div className="text-xs py-1 px-2 bg-gray-100 rounded-full text-gray-800 flex items-center">
                          <Star className="w-3 h-3 text-yellow-500 mr-1 fill-yellow-500" /> 
                          {event.rating}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12">
                <Calendar className="w-16 h-16 text-gray-300 mb-4" />
                <h3 className="text-xl font-bold text-gray-800 mb-2">No Events Found</h3>
                <p className="text-gray-500 text-center max-w-md">
                  {searchTerm || filterType !== 'all' ? (
                    <>No events match your current search criteria. Try adjusting your filters.</>
                  ) : (
                    <>You haven't added any events yet. Click "Add New Event" to get started.</>
                  )}
                </p>
                {(searchTerm || filterType !== 'all') && (
                  <button
                    onClick={() => {
                      setSearchTerm('');
                      setFilterType('all');
                    }}
                    className="mt-4 text-accent-600 hover:text-accent-700 font-medium"
                  >
                    Clear filters
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Event List Table View */}
      {viewMode === 'table' && (
        <EventList 
          events={filteredEvents}
          isLoading={loading}
          onDelete={handleDeleteEvent}
        />
      )}
    </AdminLayout>
  );
};

export default AdminEvents;