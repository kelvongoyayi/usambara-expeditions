import React from 'react';
import { Check } from 'lucide-react';

interface Step {
  id: string;
  label: string;
  completed?: boolean;
}

interface StepperProps {
  steps: Step[];
  currentStep: string;
  className?: string;
}

const Stepper: React.FC<StepperProps> = ({
  steps,
  currentStep,
  className = ''
}) => {
  const currentStepIndex = steps.findIndex(step => step.id === currentStep);
  
  return (
    <div className={`w-full ${className}`}>
      <div className="flex items-center justify-between">
        {steps.map((step, index) => {
          const isActive = step.id === currentStep;
          const isCompleted = step.completed || index < currentStepIndex;
          
          return (
            <React.Fragment key={step.id}>
              {/* Step Circle */}
              <div className="relative flex flex-col items-center">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                    isCompleted 
                      ? 'bg-accent-500 text-white' 
                      : isActive 
                        ? 'bg-brand-600 text-white' 
                        : 'bg-gray-200 text-gray-600'
                  }`}
                >
                  {isCompleted ? (
                    <Check className="w-5 h-5" />
                  ) : (
                    <span className="text-sm font-medium">{index + 1}</span>
                  )}
                </div>
                <span className={`absolute -bottom-6 text-xs font-medium text-center w-max ${
                  isActive ? 'text-brand-600' : isCompleted ? 'text-accent-500' : 'text-gray-500'
                }`}>
                  {step.label}
                </span>
              </div>
              
              {/* Connector Line */}
              {index < steps.length - 1 && (
                <div className="flex-1 mx-2">
                  <div className={`h-1 ${
                    index < currentStepIndex 
                      ? 'bg-accent-500' 
                      : 'bg-gray-200'
                  }`}></div>
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>
      
      {/* Spacer for labels */}
      <div className="h-6"></div>
    </div>
  );
};

export default Stepper;