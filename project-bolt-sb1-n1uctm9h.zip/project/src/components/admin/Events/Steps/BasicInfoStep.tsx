import React from 'react';
import { DollarSign, MapPin, Clock, Star, Users, Globe, Calendar } from 'lucide-react';
import DetailsPanelLayout from '../../shared/DetailsPanelLayout';
import { Event } from '../../../../services/events.service';

interface BasicInfoStepProps {
  formData: Partial<Event>;
  handleChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => void;
  errors: Record<string, string>;
  eventTypes: {id: string; name: string}[];
  loadingEventTypes: boolean;
  setFieldValue?: (name: string, value: any) => void;
}

const BasicInfoStep: React.FC<BasicInfoStepProps> = ({ 
  formData, 
  handleChange, 
  errors,
  eventTypes,
  loadingEventTypes,
  setFieldValue
}) => {
  return (
    <DetailsPanelLayout title="Basic Information" description="Add essential event details">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1.5">
            Event Title <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            id="title"
            name="title"
            value={formData.title || ''}
            onChange={handleChange}
            required
            className={`block w-full rounded-lg shadow-sm sm:text-sm ${
              errors.title ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-accent-500 focus:ring-accent-500'
            }`}
            placeholder="e.g. Corporate Team Building Retreat"
          />
          {errors.title && (
            <p className="mt-1.5 text-sm text-red-600">{errors.title}</p>
          )}
        </div>
        
        <div>
          <label htmlFor="slug" className="block text-sm font-medium text-gray-700 mb-1.5">
            Slug <span className="text-gray-400 text-xs font-normal ml-1">(Optional - will be auto-generated)</span>
          </label>
          <div className="relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Globe className="h-4 w-4 text-gray-400" />
            </div>
            <input
              type="text"
              id="slug"
              name="slug"
              value={formData.slug || ''}
              onChange={handleChange}
              placeholder="event-slug-for-url"
              className={`pl-10 block w-full rounded-lg shadow-sm sm:text-sm ${
                errors.slug ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-accent-500 focus:ring-accent-500'
              }`}
            />
          </div>
          {errors.slug ? (
            <p className="mt-1.5 text-sm text-red-600">{errors.slug}</p>
          ) : (
            <p className="mt-1.5 text-xs text-gray-500">
              Used in URLs. Leave empty for automatic generation from title.
            </p>
          )}
        </div>
        
        <div>
          <label htmlFor="event_type" className="block text-sm font-medium text-gray-700 mb-1.5">
            Event Type <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            {loadingEventTypes ? (
              <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2.5">
                <div className="animate-pulse bg-gray-200 h-5 w-24 rounded"></div>
              </div>
            ) : (
              <select
                id="event_type"
                name="event_type"
                value={formData.event_type || ''}
                onChange={handleChange}
                required
                className={`block w-full rounded-lg shadow-sm sm:text-sm ${
                  errors.event_type ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-accent-500 focus:ring-accent-500'
                }`}
              >
                <option value="">Select an event type</option>
                {eventTypes.map(type => (
                  <option key={type.id} value={type.id}>{type.name}</option>
                ))}
              </select>
            )}
          </div>
          {errors.event_type && (
            <p className="mt-1.5 text-sm text-red-600">{errors.event_type}</p>
          )}
        </div>
        
        <div className="lg:col-span-2">
          <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1.5">
            Description <span className="text-red-500">*</span>
          </label>
          <textarea
            id="description"
            name="description"
            rows={4}
            value={formData.description || ''}
            onChange={handleChange}
            required
            className={`block w-full rounded-lg shadow-sm sm:text-sm ${
              errors.description ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-accent-500 focus:ring-accent-500'
            }`}
            placeholder="Detailed description of the event"
          />
          {errors.description && (
            <p className="mt-1.5 text-sm text-red-600">{errors.description}</p>
          )}
        </div>
        
        <div>
          <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1.5">
            Location <span className="text-red-500">*</span>
          </label>
          <div className="relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <MapPin className="h-4 w-4 text-gray-400" />
            </div>
            <input
              type="text"
              id="location"
              name="location"
              value={formData.location || ''}
              onChange={handleChange}
              required
              placeholder="e.g. Lushoto Valley Resort"
              className={`pl-10 block w-full rounded-lg shadow-sm sm:text-sm ${
                errors.location ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-accent-500 focus:ring-accent-500'
              }`}
            />
          </div>
          {errors.location && (
            <p className="mt-1.5 text-sm text-red-600">{errors.location}</p>
          )}
        </div>
        
        <div>
          <label htmlFor="price" className="block text-sm font-medium text-gray-700 mb-1.5">
            Price <span className="text-red-500">*</span>
          </label>
          <div className="relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <DollarSign className="h-4 w-4 text-gray-400" />
            </div>
            <input
              type="number"
              id="price"
              name="price"
              min="0"
              step="0.01"
              value={formData.price || ''}
              onChange={handleChange}
              required
              className={`pl-10 block w-full rounded-lg shadow-sm sm:text-sm ${
                errors.price ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-accent-500 focus:ring-accent-500'
              }`}
              placeholder="0.00"
            />
          </div>
          <p className="mt-1.5 text-xs text-gray-500">
            Price per participant in USD
          </p>
          {errors.price && (
            <p className="mt-1.5 text-sm text-red-600">{errors.price}</p>
          )}
        </div>
        
        <div className="lg:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1.5">
            Event Dates <span className="text-red-500">*</span>
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="start_date" className="block text-xs font-medium text-gray-600 mb-1.5">
                Start Date
              </label>
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Calendar className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type="date"
                  id="start_date"
                  name="start_date"
                  min={new Date().toISOString().split('T')[0]}
                  value={formData.start_date?.split('T')[0] || ''}
                  onChange={handleChange}
                  required
                  className={`pl-10 block w-full rounded-lg shadow-sm sm:text-sm ${
                    errors.start_date ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-accent-500 focus:ring-accent-500'
                  }`}
                />
              </div>
              {errors.start_date && (
                <p className="mt-1.5 text-sm text-red-600">{errors.start_date}</p>
              )}
            </div>
            
            <div>
              <label htmlFor="end_date" className="block text-xs font-medium text-gray-600 mb-1.5">
                End Date
              </label>
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Calendar className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type="date"
                  id="end_date"
                  name="end_date"
                  min={formData.start_date?.split('T')[0] || new Date().toISOString().split('T')[0]}
                  value={formData.end_date?.split('T')[0] || ''}
                  onChange={handleChange}
                  required
                  className={`pl-10 block w-full rounded-lg shadow-sm sm:text-sm ${
                    errors.end_date ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 focus:border-accent-500 focus:ring-accent-500'
                  }`}
                />
              </div>
              {errors.end_date && (
                <p className="mt-1.5 text-sm text-red-600">{errors.end_date}</p>
              )}
            </div>
          </div>
        </div>
        
        <div>
          <label htmlFor="rating" className="block text-sm font-medium text-gray-700 mb-1.5">
            Rating <span className="text-gray-400 text-xs font-normal ml-1">(Optional)</span>
          </label>
          <div className="relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Star className="h-4 w-4 text-gray-400" />
            </div>
            <input
              type="number"
              id="rating"
              name="rating"
              min="1"
              max="5"
              step="0.1"
              value={formData.rating || ''}
              onChange={handleChange}
              className="pl-10 block w-full rounded-lg border-gray-300 shadow-sm focus:border-accent-500 focus:ring-accent-500 sm:text-sm"
            />
          </div>
          <p className="mt-1.5 text-xs text-gray-500">
            Event rating from 1.0 to 5.0
          </p>
        </div>
        
        <div className="bg-gray-50 p-4 rounded-xl border border-gray-200">
          <div className="flex items-center">
            <input
              id="featured"
              name="featured"
              type="checkbox"
              checked={formData.featured || false}
              onChange={e => {
                const target = e.target as HTMLInputElement;
                handleChange({
                  target: {
                    name: 'featured',
                    value: target.checked,
                    type: 'checkbox',
                    checked: target.checked
                  }
                } as React.ChangeEvent<HTMLInputElement>);
              }}
              className="h-4 w-4 text-accent-600 focus:ring-accent-500 border-gray-300 rounded"
            />
            <label htmlFor="featured" className="ml-2 block text-sm text-gray-900">
              Feature this event on the website
            </label>
          </div>
          <p className="mt-2 text-xs text-gray-500 ml-6">
            Featured events will be highlighted on the homepage and may appear at the top of search results.
          </p>
        </div>
        
        <div className="lg:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-3">
            Attendee Capacity
          </label>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="min_attendees" className="block text-xs font-medium text-gray-600 mb-1.5">
                Minimum Attendees
              </label>
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Users className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type="number"
                  id="min_attendees"
                  name="min_attendees"
                  min="1"
                  value={formData.min_attendees || ''}
                  onChange={handleChange}
                  className="pl-10 block w-full rounded-lg border-gray-300 shadow-sm focus:border-accent-500 focus:ring-accent-500 sm:text-sm"
                  placeholder="10"
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="max_attendees" className="block text-xs font-medium text-gray-600 mb-1.5">
                Maximum Attendees
              </label>
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Users className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type="number"
                  id="max_attendees"
                  name="max_attendees"
                  min={formData.min_attendees || 1}
                  value={formData.max_attendees || ''}
                  onChange={handleChange}
                  className="pl-10 block w-full rounded-lg border-gray-300 shadow-sm focus:border-accent-500 focus:ring-accent-500 sm:text-sm"
                  placeholder="100"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </DetailsPanelLayout>
  );
};

export default BasicInfoStep;