import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { 
  Edit, Trash2, Eye, Search, Filter, ArrowUp, ArrowDown, 
  Grid, List, Loader, Tag, ChevronDown, Check, X, Camera,
  Clock
} from 'lucide-react';
import { Tour } from '../../../services/tours.service';
import LoadingImage from '../../ui/LoadingImage';

interface EnhancedTourListProps {
  tours: Tour[];
  isLoading: boolean;
  onDelete: (id: string, title: string) => void;
  viewMode: 'card' | 'table';
  onViewModeChange: (mode: 'card' | 'table') => void;
  onSortChange?: (field: keyof Tour, direction: 'asc' | 'desc') => void;
  onFilterChange?: (category: string) => void;
  filterCategory: string;
  categories: { id: string; name: string }[];
  searchTerm: string;
  onSearchChange: (term: string) => void;
}

const EnhancedTourList: React.FC<EnhancedTourListProps> = ({
  tours,
  isLoading,
  onDelete,
  viewMode,
  onViewModeChange,
  onSortChange,
  onFilterChange,
  filterCategory,
  categories,
  searchTerm,
  onSearchChange
}) => {
  const [sortField, setSortField] = useState<keyof Tour>('created_at');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [expandedTour, setExpandedTour] = useState<string | null>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  // Check if container has scrollable content
  useEffect(() => {
    const checkScrollable = () => {
      if (scrollContainerRef.current) {
        const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
        setCanScrollLeft(scrollLeft > 0);
        setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
      }
    };

    const container = scrollContainerRef.current;
    if (container) {
      container.addEventListener('scroll', checkScrollable);
      checkScrollable();
      
      // Also check on resize
      window.addEventListener('resize', checkScrollable);
      
      return () => {
        container.removeEventListener('scroll', checkScrollable);
        window.removeEventListener('resize', checkScrollable);
      };
    }
  }, [tours]);

  // Handle sort
  const handleSort = (field: keyof Tour) => {
    const newDirection = sortField === field && sortDirection === 'asc' ? 'desc' : 'asc';
    setSortField(field);
    setSortDirection(newDirection);
    
    if (onSortChange) {
      onSortChange(field, newDirection);
    }
  };

  // Render sort indicator
  const renderSortIndicator = (field: keyof Tour) => {
    if (sortField !== field) return null;
    
    return sortDirection === 'asc' ? 
      <ArrowUp className="w-4 h-4 ml-1" /> : 
      <ArrowDown className="w-4 h-4 ml-1" />;
  };

  // Handle delete confirmation
  const handleDeleteClick = (id: string, title: string) => {
    setDeleteConfirm(id);
  };

  // Confirm delete
  const confirmDelete = (id: string, title: string) => {
    onDelete(id, title);
    setDeleteConfirm(null);
  };

  // Cancel delete
  const cancelDelete = () => {
    setDeleteConfirm(null);
  };

  // Scroll tours horizontally
  const scrollTours = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = direction === 'left' ? -300 : 300;
      scrollContainerRef.current.scrollBy({
        left: scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  // Toggle expanded tour details
  const toggleExpandTour = (tourId: string) => {
    setExpandedTour(expandedTour === tourId ? null : tourId);
  };

  // Render the tour cards view
  const renderCardsView = () => {
    return (
      <div className="relative px-1">
        {/* Scroll indicators */}
        {canScrollLeft && (
          <button
            onClick={() => scrollTours('left')}
            aria-label="Scroll left"
            className="absolute left-0 top-1/2 transform -translate-y-1/2 z-10 bg-white rounded-full p-2 shadow-md border border-gray-200 text-gray-700 hover:bg-gray-50"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
        )}
        
        {canScrollRight && (
          <button
            onClick={() => scrollTours('right')}
            aria-label="Scroll right"
            className="absolute right-0 top-1/2 transform -translate-y-1/2 z-10 bg-white rounded-full p-2 shadow-md border border-gray-200 text-gray-700 hover:bg-gray-50"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        )}

        <div 
          ref={scrollContainerRef}
          className="flex overflow-x-auto gap-5 pb-4 pt-2 px-2 scrollbar-hide"
          style={{ scrollbarWidth: 'none' }}
        >
          {tours.map(tour => (
            <div 
              key={tour.id} 
              className="min-w-[300px] max-w-[300px] bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden flex flex-col transition-all hover:-translate-y-1 hover:shadow-md duration-200"
            >
              <div className="h-40 overflow-hidden relative">
                <LoadingImage
                  src={tour.image_url || '/placeholder-tour.jpg'}
                  alt={tour.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-0 right-0 m-2">
                  <span className="px-2 py-1 text-xs font-medium rounded-full bg-brand-100 text-brand-800">
                    {tour.category}
                  </span>
                </div>
                {tour.featured && (
                  <div className="absolute top-0 left-0 m-2">
                    <span className="px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">
                      Featured
                    </span>
                  </div>
                )}
              </div>

              <div className="p-4 flex-grow flex flex-col">
                <h3 className="font-bold text-lg text-gray-900 line-clamp-1 mb-2">{tour.title}</h3>
                
                <div className="flex items-center justify-between mb-3">
                  <span className="inline-flex items-center text-gray-700 text-sm">
                    <Clock className="w-4 h-4 mr-1 text-gray-500" />
                    {tour.duration}
                  </span>
                  <span className="font-bold text-brand-600">${Number(tour.price).toFixed(2)}</span>
                </div>
                
                <p className="text-gray-600 text-sm line-clamp-3 mb-4">
                  {tour.description}
                </p>
                
                <div className="mt-auto flex justify-between items-center pt-3 border-t border-gray-100">
                  <div className="flex space-x-2">
                    <Link 
                      to={`/tour/${tour.id}`} 
                      className="text-indigo-600 hover:text-indigo-900 p-1.5 rounded-full hover:bg-indigo-50 transition-colors"
                      title="View"
                      target="_blank"
                    >
                      <Eye className="w-4 h-4" />
                    </Link>
                    <Link 
                      to={`/admin/tours/edit/${tour.id}`} 
                      className="text-yellow-600 hover:text-yellow-900 p-1.5 rounded-full hover:bg-yellow-50 transition-colors"
                      title="Edit"
                    >
                      <Edit className="w-4 h-4" />
                    </Link>
                    {deleteConfirm === tour.id ? (
                      <div className="flex items-center space-x-1 bg-red-50 rounded-lg px-2">
                        <button
                          onClick={() => confirmDelete(tour.id, tour.title)}
                          className="text-red-600 hover:text-red-900 p-1"
                          title="Confirm Delete"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                        <button
                          onClick={cancelDelete}
                          className="text-gray-600 hover:text-gray-900 p-1"
                          title="Cancel"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <button 
                        className="text-red-600 hover:text-red-900 p-1.5 rounded-full hover:bg-red-50 transition-colors"
                        title="Delete"
                        onClick={() => handleDeleteClick(tour.id, tour.title)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                  
                  <div className="text-xs py-1 px-2 bg-gray-100 rounded-full text-gray-800">
                    Rating: {tour.rating}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // Render the tour table view
  const renderTableView = () => {
    return (
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('title')}
              >
                <div className="flex items-center">
                  Tour Name
                  {renderSortIndicator('title')}
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('category')}
              >
                <div className="flex items-center">
                  Category
                  {renderSortIndicator('category')}
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('location')}
              >
                <div className="flex items-center">
                  Location
                  {renderSortIndicator('location')}
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('price')}
              >
                <div className="flex items-center">
                  Price
                  {renderSortIndicator('price')}
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('featured')}
              >
                <div className="flex items-center">
                  Featured
                  {renderSortIndicator('featured')}
                </div>
              </th>
              <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {tours.map(tour => (
              <React.Fragment key={tour.id}>
                <tr 
                  className={`hover:bg-gray-50 ${expandedTour === tour.id ? 'bg-gray-50' : ''}`}
                  onClick={() => toggleExpandTour(tour.id)}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 rounded overflow-hidden">
                        <img
                          src={tour.image_url || '/placeholder-tour.jpg'}
                          alt={tour.title}
                          className="h-10 w-10 object-cover"
                        />
                      </div>
                      <div className="ml-4 flex flex-col">
                        <div className="text-sm font-medium text-gray-900 flex items-center">
                          {tour.title}
                          <button 
                            onClick={(e) => { e.stopPropagation(); toggleExpandTour(tour.id); }}
                            className="ml-2 text-gray-500 hover:text-gray-700"
                          >
                            <ChevronDown className={`w-4 h-4 transition-transform ${expandedTour === tour.id ? 'rotate-180' : ''}`} />
                          </button>
                        </div>
                        <div className="text-sm text-gray-500">{tour.duration}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2.5 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-brand-100 text-brand-800">
                      {tour.category}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {tour.location}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${Number(tour.price).toFixed(2)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {tour.featured ? (
                      <span className="px-2.5 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                        Yes
                      </span>
                    ) : (
                      <span className="px-2.5 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                        No
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm font-medium">
                    <div className="flex justify-center space-x-2">
                      <Link 
                        to={`/tour/${tour.id}`} 
                        className="text-indigo-600 hover:text-indigo-900"
                        title="View"
                        target="_blank"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Eye className="w-5 h-5" />
                      </Link>
                      <Link 
                        to={`/admin/tours/edit/${tour.id}`} 
                        className="text-yellow-600 hover:text-yellow-900"
                        title="Edit"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <Edit className="w-5 h-5" />
                      </Link>
                      {deleteConfirm === tour.id ? (
                        <div className="flex items-center space-x-1 bg-red-50 px-2 rounded-lg">
                          <button
                            onClick={(e) => { 
                              e.stopPropagation(); 
                              confirmDelete(tour.id, tour.title); 
                            }}
                            className="text-red-600 hover:text-red-900"
                            title="Confirm Delete"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button
                            onClick={(e) => { 
                              e.stopPropagation(); 
                              cancelDelete(); 
                            }}
                            className="text-gray-600 hover:text-gray-900"
                            title="Cancel"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <button 
                          className="text-red-600 hover:text-red-900"
                          title="Delete"
                          onClick={(e) => { 
                            e.stopPropagation(); 
                            handleDeleteClick(tour.id, tour.title); 
                          }}
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
                {expandedTour === tour.id && (
                  <tr className="bg-gray-50">
                    <td colSpan={6} className="px-6 py-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <h4 className="font-medium text-gray-700 mb-2">Description</h4>
                          <p className="text-sm text-gray-600">{tour.description}</p>
                          
                          {tour.highlights && tour.highlights.length > 0 && (
                            <div className="mt-3">
                              <h4 className="font-medium text-gray-700 mb-1">Highlights</h4>
                              <ul className="text-sm text-gray-600 ml-4 list-disc">
                                {tour.highlights.slice(0, 3).map((highlight, idx) => (
                                  <li key={idx}>{highlight}</li>
                                ))}
                                {tour.highlights.length > 3 && (
                                  <li>+{tour.highlights.length - 3} more...</li>
                                )}
                              </ul>
                            </div>
                          )}
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-700 mb-2">Tour Details</h4>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            {tour.difficulty && (
                              <div>
                                <span className="font-medium text-gray-700">Difficulty:</span> {tour.difficulty}
                              </div>
                            )}
                            {tour.min_group_size && (
                              <div>
                                <span className="font-medium text-gray-700">Min Group:</span> {tour.min_group_size}
                              </div>
                            )}
                            {tour.max_group_size && (
                              <div>
                                <span className="font-medium text-gray-700">Max Group:</span> {tour.max_group_size}
                              </div>
                            )}
                            {tour.rating && (
                              <div>
                                <span className="font-medium text-gray-700">Rating:</span> {tour.rating}
                              </div>
                            )}
                          </div>
                          
                          {tour.gallery && tour.gallery.length > 0 && (
                            <div className="mt-3">
                              <h4 className="font-medium text-gray-700 mb-1">Gallery</h4>
                              <div className="flex space-x-2 mt-1">
                                {tour.gallery.slice(0, 3).map((img, idx) => (
                                  <div key={idx} className="h-12 w-12 rounded overflow-hidden">
                                    <img src={img} alt={`Gallery ${idx + 1}`} className="h-full w-full object-cover" />
                                  </div>
                                ))}
                                {tour.gallery.length > 3 && (
                                  <div className="h-12 w-12 rounded bg-gray-100 flex items-center justify-center">
                                    <span className="text-xs text-gray-500">+{tour.gallery.length - 3}</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="mt-3 pt-3 border-t border-gray-200 flex justify-end">
                        <Link 
                          to={`/admin/tours/edit/${tour.id}`}
                          className="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500"
                        >
                          Edit Tour Details
                        </Link>
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
        <div className="flex items-center">
          <h3 className="text-lg font-medium text-gray-900">Tours</h3>
          <div className="ml-4 bg-gray-100 rounded-full px-3 py-1">
            <span className="text-sm text-gray-600">{tours.length} tours</span>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={() => onViewModeChange('card')}
            className={`p-2 ${viewMode === 'card' 
              ? 'bg-brand-50 text-brand-600' 
              : 'text-gray-500 hover:bg-gray-100 hover:text-gray-700'
            } rounded-md transition-colors`}
            aria-label="Card view"
          >
            <Grid className="w-5 h-5" />
          </button>
          <button
            onClick={() => onViewModeChange('table')}
            className={`p-2 ${viewMode === 'table' 
              ? 'bg-brand-50 text-brand-600' 
              : 'text-gray-500 hover:bg-gray-100 hover:text-gray-700'
            } rounded-md transition-colors`}
            aria-label="Table view"
          >
            <List className="w-5 h-5" />
          </button>
        </div>
      </div>
      
      {/* Search and Filter Bar */}
      <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
        <div className="sm:flex sm:items-center sm:justify-between">
          <div className="flex-1 min-w-0 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search tours by name, location, or description..."
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              className="pl-10 block w-full rounded-md border-gray-300 shadow-sm sm:text-sm focus:ring-brand-500 focus:border-brand-500"
            />
          </div>
          
          <div className="mt-3 sm:mt-0 sm:ml-4">
            <select
              value={filterCategory}
              onChange={(e) => onFilterChange && onFilterChange(e.target.value)}
              className="pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-brand-500 focus:border-brand-500 sm:text-sm rounded-md"
              aria-label="Filter by category"
            >
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Tour Lists */}
      {isLoading ? (
        <div className="flex items-center justify-center p-12">
          <Loader className="w-8 h-8 text-brand-600 animate-spin" />
          <span className="ml-3 text-lg text-gray-600">Loading tours...</span>
        </div>
      ) : tours.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-12">
          <div className="bg-gray-100 rounded-full p-4 mb-4">
            <Camera className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-xl font-medium text-gray-900 mb-2">No tours found</h3>
          <p className="text-gray-500 text-center max-w-md mb-6">
            {searchTerm || filterCategory !== 'all' 
              ? `No tours match your current search criteria. Try adjusting your filters.`
              : `You haven't added any tours yet. Get started by creating your first tour.`
            }
          </p>
          {searchTerm || filterCategory !== 'all' ? (
            <button
              onClick={() => {
                onSearchChange('');
                if (onFilterChange) onFilterChange('all');
              }}
              className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
            >
              Clear filters
            </button>
          ) : (
            <Link
              to="/admin/tours/create"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-brand-600 hover:bg-brand-700 focus:outline-none"
            >
              Add your first tour
            </Link>
          )}
        </div>
      ) : (
        <div>
          {viewMode === 'card' ? renderCardsView() : renderTableView()}
          
          {/* Footer with Stats */}
          <div className="px-6 py-3 bg-gray-50 border-t border-gray-200 flex flex-wrap justify-between items-center text-sm text-gray-500">
            <div>
              Showing <span className="font-medium text-gray-900">{tours.length}</span> tours
            </div>
            
            <div className="flex items-center space-x-4">
              <div>
                <span className="font-medium text-gray-700 mr-1">Featured:</span>
                <span className="text-gray-900">{tours.filter(t => t.featured).length}</span>
              </div>
              
              {tours.length > 0 && (
                <div>
                  <span className="font-medium text-gray-700 mr-1">Avg. Price:</span>
                  <span className="text-gray-900">
                    ${(tours.reduce((sum, tour) => sum + Number(tour.price), 0) / tours.length).toFixed(2)}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EnhancedTourList;