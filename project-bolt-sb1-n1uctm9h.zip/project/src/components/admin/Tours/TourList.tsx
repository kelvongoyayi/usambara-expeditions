import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Edit, Trash2, Eye, Plus, Search, Filter, ArrowUp, ArrowDown, ChevronLeft, ChevronRight } from 'lucide-react';
import { Tour } from '../../../services/tours.service';

interface TourListProps {
  tours: Tour[];
  isLoading: boolean;
  onDelete: (id: string) => void;
}

const TourList: React.FC<TourListProps> = ({ tours, isLoading, onDelete }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<keyof Tour>('created_at');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [filterCategory, setFilterCategory] = useState('all');
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Get unique categories from tours
  const categories = ['all', ...new Set(tours.map(tour => tour.category))];

  // Handle sort
  const handleSort = (field: keyof Tour) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // Filter and sort tours
  const filteredTours = tours
    .filter(tour => 
      (filterCategory === 'all' || tour.category === filterCategory) &&
      (tour.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
       tour.location.toLowerCase().includes(searchTerm.toLowerCase()))
    )
    .sort((a, b) => {
      const aValue = a[sortField];
      const bValue = b[sortField];
      
      if (aValue === bValue) return 0;
      
      if (sortDirection === 'asc') {
        return aValue < bValue ? -1 : 1;
      } else {
        return aValue > bValue ? -1 : 1;
      }
    });

  // Render sort indicator
  const renderSortIndicator = (field: keyof Tour) => {
    if (sortField !== field) return null;
    
    return sortDirection === 'asc' ? 
      <ArrowUp className="w-4 h-4 ml-1" /> : 
      <ArrowDown className="w-4 h-4 ml-1" />;
  };

  // Scroll the tours list horizontally
  const scrollTours = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = direction === 'left' ? -300 : 300;
      scrollContainerRef.current.scrollBy({
        left: scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  // Check if there's more content to scroll to
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  // Update scroll indicators
  const checkScrollable = () => {
    if (scrollContainerRef.current) {
      const container = scrollContainerRef.current;
      setCanScrollLeft(container.scrollLeft > 0);
      setCanScrollRight(container.scrollLeft < (container.scrollWidth - container.clientWidth - 10));
    }
  };

  // Attach scroll event listener
  useEffect(() => {
    const container = scrollContainerRef.current;
    if (container) {
      container.addEventListener('scroll', checkScrollable);
      // Initial check
      checkScrollable();
      
      // Check on window resize too
      window.addEventListener('resize', checkScrollable);
      
      return () => {
        container.removeEventListener('scroll', checkScrollable);
        window.removeEventListener('resize', checkScrollable);
      };
    }
  }, [tours]);
  
  // Check scrollable again when filtered tours change
  useEffect(() => {
    // Wait for the DOM to update
    setTimeout(checkScrollable, 100);
  }, [filteredTours]);

  // Handle delete confirmation
  const handleDeleteClick = (id: string, title: string) => {
    if (window.confirm(`Are you sure you want to delete the tour "${title}"? This action cannot be undone.`)) {
      onDelete(id);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="px-4 sm:px-6 py-4 border-b border-gray-200 bg-gray-50">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-3 sm:space-y-0">
          <h3 className="text-lg font-medium text-gray-900">Tours Management</h3>
          <Link 
            to="/admin/tours/create" 
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-brand-600 hover:bg-brand-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add New Tour
          </Link>
        </div>
      </div>
      
      {/* Search and Filters */}
      <div className="px-4 sm:px-6 py-4 border-b border-gray-200 bg-gray-50">
        <div className="flex flex-col md:flex-row md:items-center space-y-3 md:space-y-0 md:space-x-4">
          <div className="flex-1 min-w-0">
            <div className="relative rounded-md shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                className="focus:ring-brand-500 focus:border-brand-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                placeholder="Search tours by name or location"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <div className="flex flex-row space-x-4">
            <div className="w-full md:w-auto">
              <label htmlFor="category-filter" className="sr-only">
                Filter by Category
              </label>
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Filter className="h-5 w-5 text-gray-400" />
                </div>
                <select
                  id="category-filter"
                  className="focus:ring-brand-500 focus:border-brand-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                >
                  {categories.map((category) => (
                    <option key={category} value={category}>
                      {category === 'all' 
                        ? 'All Categories' 
                        : category.charAt(0).toUpperCase() + category.slice(1)}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tour Cards for Scrollable View */}
      <div className="p-6 relative">
        {/* Scroll Indicators */}
        {canScrollLeft && (
          <button
            onClick={() => scrollTours('left')}
            className="absolute left-0 top-1/2 transform -translate-y-1/2 bg-white rounded-full p-2 shadow-lg z-10 border border-gray-200"
            aria-label="Scroll left"
          >
            <ChevronLeft className="w-5 h-5 text-gray-600" />
          </button>
        )}
        
        {canScrollRight && (
          <button
            onClick={() => scrollTours('right')}
            className="absolute right-0 top-1/2 transform -translate-y-1/2 bg-white rounded-full p-2 shadow-lg z-10 border border-gray-200"
            aria-label="Scroll right"
          >
            <ChevronRight className="w-5 h-5 text-gray-600" />
          </button>
        )}
        
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-600"></div>
          </div>
        ) : filteredTours.length > 0 ? (
          <div 
            ref={scrollContainerRef}
            className="flex overflow-x-auto gap-4 pb-4 scrollbar-hide"
            style={{ scrollbarWidth: 'none' }}
          >
            {filteredTours.map((tour) => (
              <div 
                key={tour.id} 
                className="min-w-[300px] max-w-[300px] bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden flex flex-col transition-all hover:-translate-y-1 hover:shadow-md duration-200"
              >
                <div className="h-40 overflow-hidden relative">
                  <img
                    src={tour.image_url || 'https://via.placeholder.com/300x150?text=No+Image'}
                    alt={tour.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-0 right-0 m-2">
                    <span className="px-2 py-1 text-xs font-medium rounded-full bg-brand-100 text-brand-800">
                      {tour.category}
                    </span>
                  </div>
                  {tour.featured && (
                    <div className="absolute top-0 left-0 m-2">
                      <span className="px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">
                        Featured
                      </span>
                    </div>
                  )}
                </div>

                <div className="p-4 flex-grow flex flex-col">
                  <h3 className="font-bold text-lg text-gray-900 line-clamp-1">{tour.title}</h3>
                  
                  <div className="flex items-center mt-2 text-sm text-gray-600">
                    <span className="font-medium">Duration:</span>
                    <span className="ml-1">{tour.duration}</span>
                  </div>
                  
                  <div className="flex items-center mt-1 text-sm text-gray-600">
                    <span className="font-medium">Location:</span>
                    <span className="ml-1 truncate">{tour.location}</span>
                  </div>
                  
                  <div className="flex items-center mt-1 text-sm text-gray-600">
                    <span className="font-medium">Price:</span>
                    <span className="ml-1">${Number(tour.price).toFixed(2)}</span>
                  </div>
                  
                  <p className="mt-3 text-sm text-gray-500 line-clamp-3">
                    {tour.description}
                  </p>
                  
                  <div className="mt-4 flex justify-between items-center pt-3 border-t border-gray-100">
                    <div className="flex space-x-2">
                      <Link 
                        to={`/tour/${tour.id}`} 
                        className="text-indigo-600 hover:text-indigo-900 p-1.5 rounded-full hover:bg-indigo-50 transition-colors"
                        title="View"
                        target="_blank"
                      >
                        <Eye className="w-4 h-4" />
                      </Link>
                      <Link 
                        to={`/admin/tours/edit/${tour.id}`} 
                        className="text-yellow-600 hover:text-yellow-900 p-1.5 rounded-full hover:bg-yellow-50 transition-colors"
                        title="Edit"
                      >
                        <Edit className="w-4 h-4" />
                      </Link>
                      <button 
                        className="text-red-600 hover:text-red-900 p-1.5 rounded-full hover:bg-red-50 transition-colors"
                        title="Delete"
                        onClick={() => handleDeleteClick(tour.id, tour.title)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    
                    <div className="text-xs py-1 px-2 bg-gray-100 rounded-full text-gray-800">
                      Rating: {tour.rating}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-12 text-center">
            <p className="text-gray-500">No tours found matching your search criteria.</p>
          </div>
        )}
      </div>

      {/* Tours Table (Alternative View) */}
      <div className="overflow-x-auto border-t border-gray-200">
        <div className="py-4 px-6 bg-gray-50 flex justify-between items-center">
          <h3 className="text-sm font-medium text-gray-700">Table View</h3>
          <div className="text-xs text-gray-500">{filteredTours.length} Tours</div>
        </div>
        
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-600"></div>
          </div>
        ) : filteredTours.length > 0 ? (
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('title')}
                >
                  <div className="flex items-center">
                    Tour Name
                    {renderSortIndicator('title')}
                  </div>
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('category')}
                >
                  <div className="flex items-center">
                    Category
                    {renderSortIndicator('category')}
                  </div>
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('location')}
                >
                  <div className="flex items-center">
                    Location
                    {renderSortIndicator('location')}
                  </div>
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('price')}
                >
                  <div className="flex items-center">
                    Price
                    {renderSortIndicator('price')}
                  </div>
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => handleSort('featured')}
                >
                  <div className="flex items-center">
                    Featured
                    {renderSortIndicator('featured')}
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredTours.map((tour) => (
                <tr key={tour.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 rounded overflow-hidden">
                        <img
                          src={tour.image_url || 'https://via.placeholder.com/40'}
                          alt={tour.title}
                          className="h-10 w-10 object-cover"
                        />
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">{tour.title}</div>
                        <div className="text-sm text-gray-500">{tour.duration}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-brand-100 text-brand-800">
                      {tour.category}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {tour.location}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${Number(tour.price).toFixed(2)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {tour.featured ? (
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                        Yes
                      </span>
                    ) : (
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                        No
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm font-medium">
                    <div className="flex justify-center space-x-2">
                      <Link 
                        to={`/tour/${tour.id}`} 
                        className="text-indigo-600 hover:text-indigo-900"
                        title="View"
                        target="_blank"
                      >
                        <Eye className="w-5 h-5" />
                      </Link>
                      <Link 
                        to={`/admin/tours/edit/${tour.id}`} 
                        className="text-yellow-600 hover:text-yellow-900"
                        title="Edit"
                      >
                        <Edit className="w-5 h-5" />
                      </Link>
                      <button 
                        className="text-red-600 hover:text-red-900"
                        title="Delete"
                        onClick={() => handleDeleteClick(tour.id, tour.title)}
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="py-12 text-center">
            <p className="text-gray-500">No tours found matching your search criteria.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default TourList;