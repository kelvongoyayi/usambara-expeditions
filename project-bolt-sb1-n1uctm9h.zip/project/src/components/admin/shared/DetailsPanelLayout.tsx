import React, { ReactNode } from 'react';

interface DetailsPanelLayoutProps {
  title: string;
  description?: string;
  children: ReactNode;
  className?: string;
}

const DetailsPanelLayout: React.FC<DetailsPanelLayoutProps> = ({
  title,
  description,
  children,
  className = ''
}) => {
  return (
    <div className={`p-6 border-b border-gray-200 ${className}`}>
      <h2 className="text-xl font-bold text-gray-900 mb-2">{title}</h2>
      {description && (
        <p className="text-sm text-gray-600 mb-6 max-w-3xl">{description}</p>
      )}
      {children}
    </div>
  );
};

export default DetailsPanelLayout;