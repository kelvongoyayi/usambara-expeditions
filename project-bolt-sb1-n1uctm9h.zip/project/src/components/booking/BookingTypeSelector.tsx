import React from 'react';
import { FeaturedItem } from '../../types/tours';
import LoadingImage from '../ui/LoadingImage';
import { Clock, MapPin, Calendar, Check } from 'lucide-react';

interface BookingTypeSelectorProps {
  formData: {
    bookingType: 'tour' | 'event' | '';
    itemId: string;
  };
  availableTours: FeaturedItem[];
  availableEvents: FeaturedItem[];
  loading: boolean;
  onBookingTypeSelect: (type: 'tour' | 'event') => void;
  onItemSelect: (itemId: string) => void;
}

const BookingTypeSelector: React.FC<BookingTypeSelectorProps> = ({
  formData,
  availableTours,
  availableEvents,
  loading,
  onBookingTypeSelect,
  onItemSelect
}) => {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-dark-800 mb-2">Select Booking Type</h2>
        <p className="text-dark-600 mb-6">Choose whether you want to book a tour or an event</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div 
            className={`relative rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${
              formData.bookingType === 'tour' 
                ? 'border-brand-600 shadow-lg transform -translate-y-1' 
                : 'border-gray-200 hover:border-brand-300'
            }`}
            onClick={() => onBookingTypeSelect('tour')}
          >
            <div className="h-48 relative">
              <img 
                src="https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" 
                alt="Tours"
                className="w-full h-full object-cover"
              />
              {formData.bookingType === 'tour' && (
                <div className="absolute top-3 right-3 bg-brand-600 text-white p-1 rounded-full">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
              <div className="absolute bottom-4 left-4">
                <h3 className="text-xl font-bold text-white">Adventure Tours</h3>
                <p className="text-white/80 text-sm">Guided experiences in nature</p>
              </div>
            </div>
            <div className="p-4">
              <p className="text-dark-600">
                Book a guided tour to explore Tanzania's breathtaking landscapes, from mountain treks to cultural experiences.
              </p>
            </div>
          </div>
          
          <div 
            className={`relative rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${
              formData.bookingType === 'event' 
                ? 'border-accent-500 shadow-lg transform -translate-y-1' 
                : 'border-gray-200 hover:border-accent-300'
            }`}
            onClick={() => onBookingTypeSelect('event')}
          >
            <div className="h-48 relative">
              <img 
                src="https://images.unsplash.com/photo-1511578314322-379afb476865?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2069&q=80" 
                alt="Events"
                className="w-full h-full object-cover"
              />
              {formData.bookingType === 'event' && (
                <div className="absolute top-3 right-3 bg-accent-500 text-white p-1 rounded-full">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
              <div className="absolute bottom-4 left-4">
                <h3 className="text-xl font-bold text-white">Special Events</h3>
                <p className="text-white/80 text-sm">Organized activities and celebrations</p>
              </div>
            </div>
            <div className="p-4">
              <p className="text-dark-600">
                Register for special events including corporate retreats, adventure competitions, and cultural festivals.
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Show available items based on selected type */}
      {formData.bookingType && (
        <div>
          <h2 className="text-2xl font-bold text-dark-800 mb-2">
            Select {formData.bookingType === 'tour' ? 'Tour' : 'Event'}
          </h2>
          <p className="text-dark-600 mb-6">
            Choose from our available {formData.bookingType === 'tour' ? 'tours' : 'events'}
          </p>
          
          {loading ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-brand-600"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {(formData.bookingType === 'tour' ? availableTours : availableEvents).map((item) => (
                <div 
                  key={item.id} 
                  className={`bg-white rounded-xl shadow-sm border overflow-hidden transition-all hover:-translate-y-1 hover:shadow-md cursor-pointer ${
                    formData.itemId === item.id ? 'ring-2 ring-offset-2 ring-brand-600' : ''
                  }`}
                  onClick={() => onItemSelect(item.id)}
                >
                  <div className="h-40 relative">
                    <LoadingImage 
                      src={item.image} 
                      alt={item.title}
                      className="w-full h-full object-cover"
                    />
                    {formData.itemId === item.id && (
                      <div className="absolute top-3 right-3 bg-brand-600 text-white p-1.5 rounded-full shadow-md">
                        <Check className="w-4 h-4" />
                      </div>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-lg text-dark-800 mb-2 line-clamp-1">{item.title}</h3>
                    <div className="flex flex-wrap gap-2 mb-3 text-sm text-dark-500">
                      <div className="flex items-center">
                        <MapPin className="w-3.5 h-3.5 mr-1 text-brand-500" />
                        <span className="truncate max-w-[100px]">{item.location}</span>
                      </div>
                      <div className="flex items-center">
                        <Clock className="w-3.5 h-3.5 mr-1 text-brand-500" />
                        <span>{item.duration}</span>
                      </div>
                      {item.date && (
                        <div className="flex items-center">
                          <Calendar className="w-3.5 h-3.5 mr-1 text-brand-500" />
                          <span>{item.date}</span>
                        </div>
                      )}
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-dark-600">From</span>
                      <span className="font-bold text-lg text-brand-700">${item.price}</span>
                    </div>
                  </div>
                </div>
              ))}
              
              {(formData.bookingType === 'tour' ? availableTours.length === 0 : availableEvents.length === 0) && (
                <div className="col-span-full py-8 text-center">
                  <p className="text-gray-500">
                    No {formData.bookingType === 'tour' ? 'tours' : 'events'} available at the moment.
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default BookingTypeSelector;