import React from 'react';
import { Link } from 'react-router-dom';
import { Check } from 'lucide-react';
import { Button, Alert } from '../ui';
import { FeaturedItem } from '../../types/tours';

interface BookingConfirmationProps {
  bookingReference: string;
  formData: {
    bookingType: 'tour' | 'event' | '';
    date: string;
    adults: number;
    children: number;
    firstName: string;
    lastName: string;
    email: string;
  };
  selectedItem: FeaturedItem | null;
  totalPrice: number;
}

const BookingConfirmation: React.FC<BookingConfirmationProps> = ({
  bookingReference,
  formData,
  selectedItem,
  totalPrice
}) => {
  return (
    <div className="text-center py-8">
      <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
        <Check className="w-10 h-10 text-green-600" />
      </div>
      
      <h2 className="text-3xl font-bold text-dark-800 mb-4">Booking Confirmed!</h2>
      <p className="text-lg text-dark-600 mb-6 max-w-md mx-auto">
        Thank you for your booking. We've sent a confirmation email to {formData.email}.
      </p>
      
      <Alert 
        variant="success" 
        title="Booking Successfully Completed"
        className="max-w-lg mx-auto mb-6 text-left"
      >
        Your booking reference is: <span className="font-bold">{bookingReference}</span>
      </Alert>
      
      <div className="bg-gray-50 rounded-lg p-6 max-w-lg mx-auto mb-8">
        <h3 className="font-bold text-xl text-dark-800 mb-4 text-left">Booking Summary</h3>
        <div className="space-y-3 text-left">
          <div className="flex justify-between">
            <span className="text-dark-600">{formData.bookingType === 'tour' ? 'Tour' : 'Event'}:</span>
            <span className="font-medium text-dark-800">{selectedItem?.title}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-dark-600">Destination:</span>
            <span className="font-medium text-dark-800">{selectedItem?.location}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-dark-600">Date:</span>
            <span className="font-medium text-dark-800">{new Date(formData.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-dark-600">Travelers:</span>
            <span className="font-medium text-dark-800">{formData.adults} Adults, {formData.children} Children</span>
          </div>
          <div className="flex justify-between pt-3 border-t border-gray-200">
            <span className="text-dark-700 font-medium">Total Amount:</span>
            <span className="font-bold text-brand-700">${totalPrice?.toFixed(2) || '0.00'}</span>
          </div>
        </div>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <Button 
          as="a" 
          href="/" 
          variant="primary"
        >
          Return to Home
        </Button>
        <Button 
          type="button" 
          variant="secondary"
          onClick={() => window.print()}
        >
          Print Confirmation
        </Button>
      </div>
    </div>
  );
};

export default BookingConfirmation;