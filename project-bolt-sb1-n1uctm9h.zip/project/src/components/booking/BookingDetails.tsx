import React from 'react';
import { 
  MapPin, Calendar, Users
} from 'lucide-react';
import { 
  InputField, 
  SelectField, 
  QuantityField
} from '../ui';
import { FeaturedItem } from '../../types/tours';
import LoadingImage from '../ui/LoadingImage';

interface BookingDetailsProps {
  formData: {
    bookingType: 'tour' | 'event' | '';
    itemId: string;
    destination: string;
    date: string;
    adults: number;
    children: number;
  };
  selectedItem: FeaturedItem | null;
  destinations: { value: string; label: string }[];
  onInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => void;
  onSelectChange: (name: string, value: string) => void;
  onNumberChange: (field: 'adults' | 'children', value: number) => void;
}

const BookingDetails: React.FC<BookingDetailsProps> = ({
  formData,
  selectedItem,
  destinations,
  onInputChange,
  onSelectChange,
  onNumberChange
}) => {
  // Get minimum date (today)
  const today = new Date().toISOString().split('T')[0];
  
  // Get maximum date (1 year from now)
  const maxDate = new Date();
  maxDate.setFullYear(maxDate.getFullYear() + 1);
  const maxDateString = maxDate.toISOString().split('T')[0];
  
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-dark-800 mb-2">Trip Details</h2>
        <p className="text-dark-600 mb-6">
          Select your travel date and number of travelers
        </p>
        
        {selectedItem && (
          <div className="bg-gray-50 rounded-xl p-4 mb-6 flex flex-col md:flex-row gap-4">
            <div className="w-full md:w-1/4">
              <div className="aspect-w-16 aspect-h-9 rounded-lg overflow-hidden">
                <LoadingImage 
                  src={selectedItem.image} 
                  alt={selectedItem.title}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-lg text-dark-800 mb-2">{selectedItem.title}</h3>
              <div className="flex flex-wrap gap-3 mb-3">
                <div className="flex items-center text-dark-600 text-sm">
                  <MapPin className="w-4 h-4 mr-1 text-brand-600" />
                  {selectedItem.location}
                </div>
                <div className="flex items-center text-dark-600 text-sm">
                  <Calendar className="w-4 h-4 mr-1 text-brand-600" />
                  {selectedItem.date || selectedItem.duration}
                </div>
              </div>
              <p className="text-dark-600 line-clamp-2 mb-2">{selectedItem.description}</p>
              <div className="text-brand-700 font-bold">
                ${selectedItem.price} <span className="text-sm font-normal text-dark-500">per person</span>
              </div>
            </div>
          </div>
        )}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <SelectField
            label="Destination"
            name="destination"
            options={destinations}
            value={formData.destination}
            onChange={(value) => onSelectChange('destination', value)}
            icon={<MapPin className="w-5 h-5" />}
          />
          
          <InputField
            label="Travel Date"
            type="date"
            name="date"
            value={formData.date}
            onChange={onInputChange}
            required
            min={today}
            max={maxDateString}
            icon={<Calendar className="w-5 h-5" />}
          />
          
          <QuantityField
            label="Adults (18+)"
            value={formData.adults}
            onChange={(value) => onNumberChange('adults', value)}
            min={1}
            max={20}
          />
          
          <QuantityField
            label="Children (0-17)"
            value={formData.children}
            onChange={(value) => onNumberChange('children', value)}
            min={0}
            max={10}
          />
        </div>
      </div>
    </div>
  );
};

export default BookingDetails;