import React from 'react';
import { 
  Mail, Phone, User, AlertCircle
} from 'lucide-react';
import { 
  InputField, 
  TextareaField,
  CheckboxField,
  Alert
} from '../ui';

interface PersonalInfoFormProps {
  formData: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    specialRequests: string;
    agreeToTerms: boolean;
  };
  onInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => void;
  bookingError: string | null;
}

const PersonalInfoForm: React.FC<PersonalInfoFormProps> = ({
  formData,
  onInputChange,
  bookingError
}) => {
  return (
    <div>
      <h2 className="text-2xl font-bold text-dark-800 mb-2">Personal Information</h2>
      <p className="text-dark-600 mb-6">Please provide your contact details for the booking</p>
      
      {bookingError && (
        <Alert 
          variant="error" 
          title="Booking Error"
          className="mb-6"
          icon={<AlertCircle className="w-5 h-5" />}
        >
          {bookingError}
        </Alert>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <InputField
          label="First Name"
          type="text"
          name="firstName"
          value={formData.firstName}
          onChange={onInputChange}
          required
          icon={<User className="w-5 h-5" />}
        />
        
        <InputField
          label="Last Name"
          type="text"
          name="lastName"
          value={formData.lastName}
          onChange={onInputChange}
          required
          icon={<User className="w-5 h-5" />}
        />
        
        <InputField
          label="Email Address"
          type="email"
          name="email"
          value={formData.email}
          onChange={onInputChange}
          required
          icon={<Mail className="w-5 h-5" />}
        />
        
        <InputField
          label="Phone Number"
          type="tel"
          name="phone"
          value={formData.phone}
          onChange={onInputChange}
          icon={<Phone className="w-5 h-5" />}
        />
        
        <div className="md:col-span-2">
          <TextareaField
            label="Special Requests or Requirements"
            name="specialRequests"
            value={formData.specialRequests}
            onChange={onInputChange}
            rows={4}
            placeholder="Let us know if you have any special requirements or requests..."
          />
        </div>
        
        <div className="md:col-span-2">
          <CheckboxField
            name="agreeToTerms"
            checked={formData.agreeToTerms}
            onChange={onInputChange}
            label={
              <span>
                I agree to the <a href="#" className="text-brand-600 hover:underline">Terms and Conditions</a> and <a href="#" className="text-brand-600 hover:underline">Privacy Policy</a>. I understand that my personal information will be processed as described in the Privacy Policy.
              </span>
            }
            required
          />
        </div>
      </div>
    </div>
  );
};

export default PersonalInfoForm;